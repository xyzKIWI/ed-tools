(() => {
  "use strict";

  // 1. 路徑守衛
  const validRoutes = ["", "ER_Main", "Form", "OPD_Main", "ERLDM", "MRR", "HIRR", "OPDRevise", "Note"];
  const pathname = location.pathname.replace(/\/$/, "");
  const isMatch = validRoutes.some((route) => pathname === "/WEB/ipdNote" + (route ? "/" + route : ""));
  if (window.top !== window || !isMatch) return;

  const STORAGE_KEY = "kmuh_er_renew_trigger_min";
  const DEFAULT_TRIGGER_MIN = 20;
  const VALID_MINS = [29, 25, 20, 15, 10, 5];

  let currentTriggerMin = DEFAULT_TRIGGER_MIN;

  // 讀取設定 (優先 chrome.storage，降級至 localStorage)
  function loadSetting(cb) {
    if (chrome?.storage?.local) {
      chrome.storage.local.get([STORAGE_KEY], (res) => {
        const val = parseInt(res?.[STORAGE_KEY], 10);
        currentTriggerMin = VALID_MINS.includes(val) ? val : DEFAULT_TRIGGER_MIN;
        if (cb) cb();
      });
    } else {
      const saved = parseInt(localStorage.getItem(STORAGE_KEY), 10);
      currentTriggerMin = VALID_MINS.includes(saved) ? saved : DEFAULT_TRIGGER_MIN;
      if (cb) cb();
    }
  }

  let attemptedAt = null;
  let renewals = 0;
  let retryCount = 0;
  const MAX_RETRIES = 3;

  // 2. 狀態 UI：低調融合原生頂欄，無突兀色彩，選單統一收進右上角擴充套件
  function renderUI() {
    const countdown = document.getElementById("countdown");
    if (!countdown) return null;

    let label = document.getElementById("er-session-status");
    if (!label) {
      label = document.createElement("small");
      label.id = "er-session-status";
      label.style.cssText =
        "margin-left: 8px; font-size: 11px; opacity: 0.8; color: #cfd8dc; cursor: pointer; user-select: none; transition: opacity 0.2s;";
      label.title = "自動延長常駐中。頻率請至瀏覽器右上角外掛圖示調整；點擊此處亦可立即手動延長。";
      label.onmouseenter = () => { label.style.opacity = "1"; };
      label.onmouseleave = () => { label.style.opacity = "0.8"; };
      label.onclick = () => {
        retryCount = 0;
        attemptedAt = null;
        triggerRenew();
      };
      countdown.after(label);
    }
    return label;
  }

  function setStatus(text, isAlert = false) {
    const label = renderUI();
    if (!label) return;
    label.style.color = isAlert ? "#ffab91" : "#cfd8dc"; // 平時低調淺灰藍，警示時柔和粉橘
    label.textContent = `持續延長 v0.4.3：${text}（成功 ${renewals} 次）`;
  }

  // 3. 解析倒數秒數 (MM:SS)
  function secondsRemaining() {
    const text = document.getElementById("countdown")?.textContent?.trim();
    const match = /^(\d{1,2}):([0-5]\d)$/.exec(text || "");
    return match ? Number(match[1]) * 60 + Number(match[2]) : null;
  }

  // 4. 尋找延長按鈕
  function findRefreshButton() {
    return (
      document.querySelector('button.topbar-refresh[onclick*="ReloadTime"]') ||
      document.querySelector('button.topbar-refresh[title*="延長時間"]') ||
      document.querySelector('button[onclick*="ReloadTime"]') ||
      document.querySelector('button[title*="延長時間"]')
    );
  }

  // 5. 觸發延長按鈕
  function triggerRenew() {
    const button = findRefreshButton();
    if (!button || button.disabled || button.getClientRects().length === 0) {
      setStatus("找不到延長按鈕", true);
      return false;
    }
    attemptedAt = Date.now();
    setStatus("延長中...");
    button.click();
    return true;
  }

  // 6. 核心排程檢查
  function check() {
    if (document.getElementById("lockScreen")) {
      attemptedAt = null;
      setStatus("已鎖定，請正常解鎖", true);
      return;
    }

    const remaining = secondsRemaining();
    if (remaining === null) {
      setStatus("無法辨識倒數");
      return;
    }

    const now = Date.now();
    const triggerThresholdSec = currentTriggerMin * 60;

    // 處理延長後的確認
    if (attemptedAt !== null) {
      const elapsed = (now - attemptedAt) / 1000;
      if (remaining >= 1770) {
        attemptedAt = null;
        renewals++;
        retryCount = 0;
        setStatus("已確認成功");
        return;
      }

      if (elapsed > 12) {
        if (retryCount < MAX_RETRIES) {
          retryCount++;
          console.warn(`[急診延長] 逾時未確認，第 ${retryCount} 次重試...`);
          triggerRenew();
        } else {
          attemptedAt = null;
          setStatus("未確認成功，點此重試", true);
        }
        return;
      }
      return;
    }

    // 自我修復：如果時間尚充裕，維持待命
    if (remaining > triggerThresholdSec) {
      retryCount = 0;
      setStatus(`待命中 (剩${currentTriggerMin}分延長)`);
      return;
    }

    // 接近鎖定警示
    if (remaining <= 15) {
      setStatus("接近鎖定，請注意存檔", true);
      return;
    }

    // 達到門檻，觸發延長
    triggerRenew();
  }

  // 7. 防休眠心跳引擎 (Worker + CSP 降級)
  try {
    const workerBlob = new Blob(
      [`setInterval(() => { postMessage('tick'); }, 5000);`],
      { type: "application/javascript" }
    );
    const workerUrl = URL.createObjectURL(workerBlob);
    const ticker = new Worker(workerUrl);
    ticker.onmessage = () => check();
  } catch (e) {
    console.warn("[急診延長] Worker 受阻，降級為原生 setInterval", e);
    setInterval(check, 5000);
  }

  // 8. 喚醒機制與外掛事件監聽
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") check();
  });
  window.addEventListener("focus", check);

  // 監聽右上角 Popup 面板指令與設定同步
  if (chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg?.action === "FORCE_RENEW") {
        retryCount = 0;
        attemptedAt = null;
        triggerRenew();
        sendResponse({ ok: true });
      }
    });
  }

  if (chrome?.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[STORAGE_KEY]) {
        currentTriggerMin = changes[STORAGE_KEY].newValue;
        check();
      }
    });
  }

  // 載入設定即刻檢測
  loadSetting(() => {
    check();
  });
})();
