document.addEventListener("DOMContentLoaded", () => {
  const STORAGE_KEY = "kmuh_er_renew_trigger_min";
  const select = document.getElementById("intervalSelect");
  const savedTip = document.getElementById("savedTip");
  const manualBtn = document.getElementById("manualTriggerBtn");

  // 讀取既有設定 (預設 20)
  chrome.storage.local.get([STORAGE_KEY], (res) => {
    const val = res[STORAGE_KEY] || 20;
    select.value = val;
  });

  // 變更設定
  select.addEventListener("change", () => {
    const min = parseInt(select.value, 10);
    chrome.storage.local.set({ [STORAGE_KEY]: min }, () => {
      savedTip.style.display = "block";
      setTimeout(() => {
        savedTip.style.display = "none";
      }, 1500);
    });
  });

  // 手動延長按鈕：發送訊息至當前分頁
  manualBtn.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    try {
      await chrome.tabs.sendMessage(tab.id, { action: "FORCE_RENEW" });
      manualBtn.textContent = "✓ 已送出延長請求";
      setTimeout(() => {
        manualBtn.textContent = "立即手動延長目前分頁";
      }, 1500);
    } catch (err) {
      manualBtn.textContent = "當前分頁非病摘頁面";
      setTimeout(() => {
        manualBtn.textContent = "立即手動延長目前分頁";
      }, 2000);
    }
  });
});
