(() => {
  // src/monitor-core.mjs
  var SETTINGS_VERSION = 2;
  var OBSERVATION2_NUMBERS = Object.freeze([33, 34, 35, 36, 37, 38]);
  var DEFAULT_SETTINGS = Object.freeze({
    settingsVersion: SETTINGS_VERSION,
    // Known base: M01-10 (10), P15-16 (2), T19-22 (4), O23-32 (10).
    // C/R and available corridor capacity must be included by the operator.
    capacity: 26,
    observation2Open: false,
    threshold: 4,
    pollSeconds: 300,
    notificationsEnabled: true,
    repeatMinutes: 15,
    excludedBedNumbers: Object.freeze([]),
    capacityConfirmed: false,
    paused: false
  });
  function integerInRange(value, minimum, maximum) {
    if (typeof value !== "number" && typeof value !== "string") return null;
    if (typeof value === "string" && value.trim() === "") return null;
    const number = Number(value);
    return Number.isInteger(number) && number >= minimum && number <= maximum ? number : null;
  }
  function normalizeSettings(input = {}) {
    const source = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    const capacity = integerInRange(source.capacity, 1, 1e3);
    const threshold = integerInRange(source.threshold, 1, 1e3);
    const excludedInput = Array.isArray(source.excludedBedNumbers) ? source.excludedBedNumbers : [];
    const excludedNumbers = excludedInput.map((value) => integerInRange(value, 1, 38));
    const invalidCalculationSetting = source.capacity !== void 0 && capacity === null || source.threshold !== void 0 && threshold === null || source.excludedBedNumbers !== void 0 && !Array.isArray(source.excludedBedNumbers) || excludedNumbers.some((value) => value === null) || source.observation2Open !== void 0 && typeof source.observation2Open !== "boolean";
    return {
      settingsVersion: SETTINGS_VERSION,
      capacity: capacity ?? DEFAULT_SETTINGS.capacity,
      observation2Open: source.observation2Open === true,
      threshold: threshold ?? DEFAULT_SETTINGS.threshold,
      // Migrate the old short polling intervals without changing clinical settings.
      pollSeconds: integerInRange(source.pollSeconds, 600, 600) ?? DEFAULT_SETTINGS.pollSeconds,
      notificationsEnabled: typeof source.notificationsEnabled === "boolean" ? source.notificationsEnabled : DEFAULT_SETTINGS.notificationsEnabled,
      repeatMinutes: integerInRange(source.repeatMinutes, 0, 1440) ?? DEFAULT_SETTINGS.repeatMinutes,
      excludedBedNumbers: [...new Set(excludedNumbers.filter((value) => value !== null))].sort((a, b) => a - b),
      capacityConfirmed: source.capacityConfirmed === true && !invalidCalculationSetting,
      paused: source.paused === true
    };
  }
  var COUNT_FIELDS = [
    "inputRows",
    "identifiedPatients",
    "stretcherPatients",
    "standardPatients",
    "cPatients",
    "rPatients",
    "corridorPatients",
    "isolationPatients",
    "nonStretcherPatients",
    "unknownPositionPatients",
    "occupiedPhysicalBeds"
  ];
  var QUALITY_COUNT_FIELDS = [
    "invalidRecordRows",
    "missingEncounterRows",
    "duplicateEncounterRows",
    "conflictingEncounters",
    "duplicatePhysicalBeds"
  ];
  var isCount = (value) => Number.isSafeInteger(value) && value >= 0;
  function validSummaryShape(summary) {
    if (!summary || typeof summary !== "object" || Array.isArray(summary)) return false;
    if (!COUNT_FIELDS.every((key) => isCount(summary[key]))) return false;
    const quality = summary.quality;
    if (!quality || !QUALITY_COUNT_FIELDS.every((key) => isCount(quality[key])) || typeof quality.classifiedCountReliable !== "boolean" || typeof quality.bedOccupancyReliable !== "boolean") return false;
    const byNumber = summary.standardPatientsByNumber;
    if (!byNumber || typeof byNumber !== "object" || Array.isArray(byNumber)) return false;
    const entries = Object.entries(byNumber);
    if (!entries.every(([key, count]) => /^(?:[1-9]|[12]\d|3[0-8])$/.test(key) && isCount(count))) return false;
    if (entries.reduce((total, [, count]) => total + count, 0) !== summary.standardPatients) {
      return false;
    }
    if (summary.standardPatients + summary.cPatients + summary.rPatients + summary.corridorPatients + summary.isolationPatients !== summary.stretcherPatients) return false;
    if (summary.stretcherPatients + summary.nonStretcherPatients + summary.unknownPositionPatients + quality.conflictingEncounters !== summary.identifiedPatients) return false;
    return summary.occupiedPhysicalBeds <= summary.stretcherPatients;
  }
  function assessSnapshot(summary, inputSettings = {}, context = {}) {
    const settings = normalizeSettings(inputSettings);
    const source = context && typeof context === "object" ? context : {};
    const reasons = [];
    const shapeValid = validSummaryShape(summary);
    const observation2Patients = shapeValid ? OBSERVATION2_NUMBERS.reduce((total, number) => total + (summary.standardPatientsByNumber[number] ?? 0), 0) : null;
    const pediatricSmallBedPatients = shapeValid ? summary.standardPatientsByNumber[17] ?? 0 : null;
    const observation2Capacity = settings.observation2Open ? OBSERVATION2_NUMBERS.filter((number) => !settings.excludedBedNumbers.includes(number)).length : 0;
    const capacity = settings.capacity + observation2Capacity;
    if (!summary) reasons.push("missing_summary");
    else if (!shapeValid) reasons.push("invalid_summary");
    if (source.fresh !== true) reasons.push("stale");
    if (source.scopeValid !== true) reasons.push("scope_invalid");
    if (source.parseErrors !== void 0 && (!isCount(source.parseErrors) || source.parseErrors !== 0)) reasons.push("parse_errors");
    if (source.loggedIn === false) reasons.push("login_required");
    if (source.complete === false) reasons.push("incomplete");
    if (shapeValid) {
      const quality = summary.quality;
      if (quality.invalidRecordRows > 0) reasons.push("invalid_records");
      if (quality.missingEncounterRows > 0) reasons.push("missing_identifiers");
      if (quality.conflictingEncounters > 0) reasons.push("encounter_conflicts");
      if (quality.duplicatePhysicalBeds > 0) reasons.push("duplicate_beds");
      if (summary.unknownPositionPatients > 0) reasons.push("unknown_positions");
      if (!settings.observation2Open && observation2Patients > 0) {
        reasons.push("observation2_closed_occupied");
      }
      if ((!quality.classifiedCountReliable || !quality.bedOccupancyReliable) && reasons.length === 0) {
        reasons.push("invalid_summary");
      }
    }
    const dataValid = reasons.length === 0;
    const excludedNumbers = [.../* @__PURE__ */ new Set([17, ...settings.excludedBedNumbers])];
    const excludedPatients = shapeValid ? summary.isolationPatients + excludedNumbers.reduce((total, number) => total + (summary.standardPatientsByNumber[number] ?? 0), 0) : null;
    const includedPatients = shapeValid ? summary.stretcherPatients - excludedPatients : null;
    const estimatedFreeBeds = dataValid ? capacity - includedPatients : null;
    const thresholdReached = dataValid && estimatedFreeBeds < settings.threshold;
    if (!settings.capacityConfirmed) reasons.push("unconfirmed_capacity");
    if (settings.paused) reasons.push("paused");
    const state = settings.paused ? "paused" : !dataValid ? "invalid" : !settings.capacityConfirmed ? "trial" : thresholdReached ? "threshold" : "normal";
    return {
      state,
      dataValid,
      capacityConfirmed: settings.capacityConfirmed,
      thresholdReached,
      shouldNotify: dataValid && settings.capacityConfirmed && !settings.paused && settings.notificationsEnabled && thresholdReached,
      totalStretcherPatients: shapeValid ? summary.stretcherPatients : null,
      excludedPatients,
      includedPatients,
      estimatedFreeBeds,
      capacity,
      baseCapacity: settings.capacity,
      observation2Capacity,
      observation2Patients,
      pediatricSmallBedPatients,
      isolationPatients: shapeValid ? summary.isolationPatients : null,
      threshold: settings.threshold,
      reasons
    };
  }

  // src/bed-rules.mjs
  var STATUS_KEYS = ["在院中", "在院", "發落", "other"];
  function normalizeStatus(value) {
    if (typeof value !== "string") return "other";
    const status = value.trim();
    return STATUS_KEYS.includes(status) ? status : "other";
  }
  function classifyBed(value) {
    const text2 = String(value ?? "").normalize("NFKC").trim().toUpperCase();
    const match = /^([A-Z]+)\s*(\d{1,3})$/.exec(text2);
    const unknown = { kind: "unknown", zone: "unknown", physicalBedKey: null };
    if (!match) return unknown;
    const prefix = match[1];
    const number = Number(match[2]);
    const result = (kind, zone, physicalBedKey = null) => ({ prefix, number, kind, zone, physicalBedKey });
    if (prefix === "M" && number >= 97 && number <= 99) {
      return result("stretcher", "corridor_observation", "M-" + number);
    }
    if (["M", "P", "T", "O"].includes(prefix) && number >= 1 && number <= 38) {
      return result("stretcher", "standard", "standard-" + number);
    }
    const nonStretcherStart = { M: 40, T: 70, P: 80 }[prefix];
    if (nonStretcherStart !== void 0 && number >= nonStretcherStart) {
      return result("non_stretcher", "non_bedded");
    }
    if (["C", "R"].includes(prefix) && number > 0) {
      return result(
        "stretcher",
        prefix === "C" ? "resuscitation_area" : "resuscitation_room",
        prefix + "-" + number
      );
    }
    if (prefix === "A" && number > 0) {
      return result("stretcher", "isolation", "A-" + number);
    }
    return result("unknown", "unknown");
  }
  function summarizeStretcherPatients(records) {
    const rows = Array.isArray(records) ? records : [];
    const encounters = /* @__PURE__ */ new Map();
    let invalidRecordRows = Array.isArray(records) ? 0 : 1;
    let missingEncounterRows = 0;
    for (const record of rows) {
      if (!record || typeof record !== "object" || Array.isArray(record)) {
        invalidRecordRows++;
        continue;
      }
      const rawId = record.encounterId;
      const id = typeof rawId === "string" || typeof rawId === "number" && Number.isFinite(rawId) ? String(rawId).trim() : "";
      if (!id) {
        missingEncounterRows++;
        continue;
      }
      const bed = classifyBed(record.bed);
      const normalizedCode = String(record.bed ?? "").normalize("NFKC").trim().toUpperCase();
      const signature = bed.physicalBedKey ?? [bed.kind, bed.prefix ?? "", bed.number ?? "", normalizedCode].join(":");
      const status = normalizeStatus(record.status);
      const existing = encounters.get(id);
      if (existing) {
        existing.rows++;
        if (existing.signature !== signature || existing.status !== status) {
          existing.conflict = true;
        }
      } else {
        encounters.set(id, { bed, signature, status, rows: 1, conflict: false });
      }
    }
    const byZone = {
      standard: 0,
      resuscitation_area: 0,
      resuscitation_room: 0,
      isolation: 0,
      corridor_observation: 0,
      non_bedded: 0,
      unknown: 0
    };
    const byStatus = Object.fromEntries(
      STATUS_KEYS.map((status) => [status, { patients: 0, stretcherPatients: 0 }])
    );
    const standardPatientsByNumber = {};
    const occupied = /* @__PURE__ */ new Map();
    const counts = { stretcher: 0, non_stretcher: 0, unknown: 0 };
    let conflictingEncounters = 0;
    let duplicateEncounterRows = 0;
    for (const entry of encounters.values()) {
      duplicateEncounterRows += entry.rows - 1;
      if (entry.conflict) {
        conflictingEncounters++;
        continue;
      }
      const { bed, status } = entry;
      counts[bed.kind]++;
      byZone[bed.zone]++;
      byStatus[status].patients++;
      if (bed.kind !== "stretcher") continue;
      byStatus[status].stretcherPatients++;
      if (bed.zone === "standard") {
        standardPatientsByNumber[bed.number] = (standardPatientsByNumber[bed.number] ?? 0) + 1;
      }
      occupied.set(bed.physicalBedKey, (occupied.get(bed.physicalBedKey) ?? 0) + 1);
    }
    const duplicatePhysicalBeds = [...occupied.values()].filter((count) => count > 1).length;
    const classifiedCountReliable = invalidRecordRows === 0 && missingEncounterRows === 0 && conflictingEncounters === 0;
    return {
      inputRows: rows.length,
      identifiedPatients: encounters.size,
      stretcherPatients: counts.stretcher,
      standardPatients: byZone.standard,
      cPatients: byZone.resuscitation_area,
      rPatients: byZone.resuscitation_room,
      isolationPatients: byZone.isolation,
      corridorPatients: byZone.corridor_observation,
      nonStretcherPatients: counts.non_stretcher,
      unknownPositionPatients: counts.unknown,
      occupiedPhysicalBeds: occupied.size,
      standardPatientsByNumber,
      byZone,
      byStatus,
      quality: {
        invalidRecordRows,
        missingEncounterRows,
        duplicateEncounterRows,
        conflictingEncounters,
        duplicatePhysicalBeds,
        classifiedCountReliable,
        bedOccupancyReliable: classifiedCountReliable && duplicatePhysicalBeds === 0 && counts.unknown === 0
      }
    };
  }

  // src/popup.js
  var elements = Object.fromEntries(
    Array.from(document.querySelectorAll("[id]"), (element) => [element.id, element])
  );
  var params = new URLSearchParams(location.search);
  var previewEnabled = params.get("preview") === "1";
  var extensionAvailable = Boolean(globalThis.chrome?.runtime?.id && globalThis.chrome?.runtime?.sendMessage);
  var defaults = DEFAULT_SETTINGS;
  var connectionText = {
    checking: "正在更新病摘頁資料…",
    ok: "病摘頁已連線 · 全區清單",
    login_required: "所有可用病摘分頁皆需登入",
    no_tab: "尚未開啟病摘頁",
    refresh_required: "請重新整理病摘頁後再更新",
    network_error: "讀取失敗，請檢查院內網路",
    invalid: "資料完整性待確認",
    paused: "監控已暫停",
    stale: "資料已過期，請重新更新"
  };
  var currentState = null;
  var settingsDirty = false;
  var actionInProgress = false;
  var pollingInProgress = false;
  var messageTimer;
  var previewScenario = ["normal", "trial", "threshold", "login", "unknown", "observation2_closed_occupied"].includes(params.get("scenario")) ? params.get("scenario") : "normal";
  var previewState = previewEnabled ? createPreviewState(previewScenario) : null;
  function numeric(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
  }
  function displayCount(value) {
    const number = numeric(value);
    return number === null ? "—" : String(number);
  }
  function text(id, value) {
    elements[id].textContent = value;
  }
  function timestamp(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : 0;
    const parsed = Date.parse(value || "");
    return Number.isFinite(parsed) ? parsed : 0;
  }
  function formatTime(value) {
    const date = timestamp(value);
    return date ? new Intl.DateTimeFormat("zh-TW", {
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).format(date) : "尚未取得";
  }
  function pollSecondsForDisplay(value) {
    return Number(value) === 600 ? 600 : 300;
  }
  function formatNextPoll(value) {
    const date = timestamp(value);
    return date ? new Intl.DateTimeFormat("zh-TW", {
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23"
    }).format(date) : "—";
  }
  function render(state) {
    if (!state || typeof state !== "object") throw new Error("尚未取得監控狀態，請重新開啟套件。");
    currentState = state;
    const settings = { ...defaults, ...state.settings };
    const assessment = state.assessment || {};
    const summary = state.lastSnapshot?.summary;
    const connection = state.connection || { status: "no_tab" };
    const paused = settings.paused || assessment.state === "paused";
    const connectionInvalid = ["login_required", "no_tab", "refresh_required", "network_error", "invalid", "stale"].includes(connection.status);
    const hasUnknown = numeric(summary?.unknownPositionPatients) > 0;
    const observation2Conflict = Array.isArray(assessment.reasons) && assessment.reasons.includes("observation2_closed_occupied");
    const observation2Open = Boolean(settings.observation2Open);
    const observation2Patients = numeric(assessment.observation2Patients);
    const valid = Boolean(summary && assessment.dataValid && !connectionInvalid && !hasUnknown);
    const freeBeds = valid && !hasUnknown ? numeric(assessment.estimatedFreeBeds) : null;
    const confirmed = Boolean(settings.capacityConfirmed && assessment.capacityConfirmed);
    const reached = Boolean(valid && assessment.thresholdReached);
    const tone = paused ? "neutral" : !valid ? "warning" : !confirmed ? "warning" : reached ? "danger" : "good";
    const status = paused ? "已暫停" : !summary ? "等待資料" : !valid ? "資料待確認" : !confirmed ? "試算模式" : reached ? "達提醒門檻" : "監控中";
    text("monitor-status", status);
    elements["monitor-status"].dataset.tone = tone;
    elements["capacity-card"].dataset.tone = tone;
    text("calculation-mode", paused ? "上次資料" : !valid ? "資料待確認" : confirmed ? "基準已核對" : "尚未核對 · 不通知");
    text("free-beds", displayCount(freeBeds));
    text("stretcher-patients", displayCount(summary?.stretcherPatients));
    text("all-patients", displayCount(summary?.identifiedPatients));
    let headline = "尚未達空床不足提醒門檻";
    if (paused) headline = "監控已暫停";
    else if (connection.status === "login_required") headline = "請在病摘分頁重新登入";
    else if (connection.status === "stale") headline = "資料過期，等待更新";
    else if (!summary) headline = "開啟病摘頁後開始讀取";
    else if (observation2Conflict) headline = "留觀2有患者，請確認開放狀態";
    else if (!valid || hasUnknown) headline = "資料待核對，暫不判定";
    else if (!confirmed) headline = reached ? "試算低於門檻，請核對基準" : "請核對基準及排除範圍";
    else if (reached) headline = `空床小於 ${settings.threshold} 床，請現場確認`;
    text("assessment-message", headline);
    const included = numeric(assessment.includedPatients);
    const excluded = numeric(assessment.excludedPatients) || 0;
    const effectiveCapacity = numeric(assessment.capacity);
    const baseCapacity = numeric(assessment.baseCapacity);
    const observation2Capacity = numeric(assessment.observation2Capacity);
    const isolationPatients = numeric(assessment.isolationPatients) || 0;
    const pediatricSmallBedPatients = numeric(assessment.pediatricSmallBedPatients) || 0;
    const manualExcludedPatients = Math.max(0, excluded - isolationPatients - pediatricSmallBedPatients);
    const exclusionParts = [
      isolationPatients > 0 ? `A ${isolationPatients}` : "",
      pediatricSmallBedPatients > 0 ? `小床 ${pediatricSmallBedPatients}` : "",
      manualExcludedPatients > 0 ? `手動 ${manualExcludedPatients}` : ""
    ].filter(Boolean);
    const formula = freeBeds !== null && included !== null && effectiveCapacity !== null ? `有效容量 ${effectiveCapacity} − 計入推床 ${included} ＝ ${freeBeds} 床` : summary ? "顯示上次取得的彙總；資料確認前不計算空床。" : "基準與排除範圍核對後，才會啟用提醒。";
    text("calculation-detail", formula);
    const capacityDetail = baseCapacity !== null && observation2Capacity !== null ? `基本 ${baseCapacity}＋留觀2 ${observation2Capacity} 床${excluded > 0 ? ` · 排除 ${excluded} 人（${exclusionParts.join("、")}）` : ""}` : "";
    text("capacity-detail", capacityDetail);
    elements["capacity-detail"].hidden = !capacityDetail;
    text("data-time-label", paused || !valid ? "最後資料" : "資料時間");
    text("observed-at", formatTime(state.lastSnapshot?.observedAt));
    if (timestamp(state.lastSnapshot?.observedAt)) elements["observed-at"].dateTime = new Date(timestamp(state.lastSnapshot.observedAt)).toISOString();
    else elements["observed-at"].removeAttribute("datetime");
    text("connection-message", connectionText[connection.status] || "等待病摘頁連線");
    elements["connection-line"].dataset.tone = connection.status === "ok" ? "good" : connectionInvalid ? "warning" : "neutral";
    elements["connection-line"].title = typeof connection.message === "string" ? connection.message : "";
    text("next-poll-at", paused ? "自動更新已暫停" : `下次自動更新 ${formatNextPoll(state.nextPollAt)}`);
    let qualityMessage = "";
    if (observation2Conflict) qualityMessage = `留觀2未開放，但清單有 ${displayCount(observation2Patients)} 人。請核對開放狀態或床號；確認前暫停空床判定與提醒。`;
    else if (hasUnknown) qualityMessage = `有 ${summary.unknownPositionPatients} 人的位置尚未分類，請核對床號後再更新。`;
    else if (summary && !assessment.dataValid && !connectionInvalid) qualityMessage = "清單或床位資料待確認，暫停空床判定與提醒。";
    text("quality-message", qualityMessage);
    elements["quality-message"].hidden = !qualityMessage;
    for (const [id, key] of [
      ["standard-patients", "standardPatients"],
      ["c-patients", "cPatients"],
      ["r-patients", "rPatients"],
      ["corridor-patients", "corridorPatients"],
      ["isolation-patients", "isolationPatients"],
      ["non-stretcher-patients", "nonStretcherPatients"],
      ["unknown-patients", "unknownPositionPatients"]
    ]) text(id, displayCount(summary?.[key]));
    elements["unknown-row"].classList.toggle("has-unknown", hasUnknown);
    text("pediatric-small-bed-patients", displayCount(assessment.pediatricSmallBedPatients));
    text("observation2-patients", displayCount(observation2Patients));
    text("observation2-state", observation2Open ? `已開放${observation2Capacity !== null ? ` · ＋${observation2Capacity} 床` : ""}` : observation2Conflict ? "未開放 · 占床待核對" : "未開放 · ＋0 床");
    elements["observation2-row"].dataset.open = String(observation2Open);
    elements["observation2-row"].dataset.conflict = String(observation2Conflict);
    text("observation2-button", observation2Open ? "關閉留觀2" : "開放留觀2");
    elements["observation2-button"].setAttribute("aria-pressed", String(observation2Open));
    text("pause-button", paused ? "恢復監控" : "暫停監控");
    elements["pause-button"].setAttribute("aria-pressed", String(paused));
    const mutedMinutes = Math.max(0, Math.ceil((timestamp(state.mutedUntil) - Date.now()) / 6e4));
    text("mute-button", mutedMinutes > 0 ? `已靜音 · 剩 ${mutedMinutes} 分` : "靜音 30 分鐘");
    elements["mute-button"].classList.toggle("is-muted", mutedMinutes > 0);
    elements["mute-button"].title = mutedMinutes > 0 ? "再次點擊可重新靜音 30 分鐘" : "暫停桌面提醒 30 分鐘";
    text("settings-summary", `基本 ${settings.capacity} 床 · 每 ${pollSecondsForDisplay(settings.pollSeconds) / 60} 分鐘`);
    text("notification-state", state.notificationError ? "桌面通知受阻" : paused ? "提醒已暫停" : mutedMinutes > 0 ? "提醒已靜音" : !settings.notificationsEnabled ? "提醒已關閉" : !confirmed ? "提醒待啟用" : !valid ? "提醒暫停" : "提醒已啟用");
    elements["notification-state"].title = state.lastAlertAt ? `上次提醒：${formatTime(state.lastAlertAt)}` : "";
    if (!settingsDirty) fillSettings(settings);
  }
  function fillSettings(settings) {
    elements["capacity-input"].value = settings.capacity;
    elements["threshold-input"].value = settings.threshold;
    elements["poll-select"].value = pollSecondsForDisplay(settings.pollSeconds);
    elements["repeat-select"].value = settings.repeatMinutes;
    elements["excluded-input"].value = Array.isArray(settings.excludedBedNumbers) ? settings.excludedBedNumbers.join(", ") : "";
    elements["notifications-input"].checked = Boolean(settings.notificationsEnabled);
    elements["confirmed-input"].checked = Boolean(settings.capacityConfirmed);
  }
  function readSettings() {
    const capacity = Number(elements["capacity-input"].value);
    const threshold = Number(elements["threshold-input"].value);
    if (!Number.isInteger(capacity) || capacity < 1 || capacity > 1e3) throw new Error("基本容量請填入 1–1000 的整數。");
    if (!Number.isInteger(threshold) || threshold < 1 || threshold > 1e3) throw new Error("空床門檻請填入 1–1000 的整數。");
    const raw = elements["excluded-input"].value.trim();
    const parts = raw ? raw.split(/[,，、]/).map((part) => part.trim()) : [];
    if (parts.some((part) => !/^\d{1,2}$/.test(part) || Number(part) < 1 || Number(part) > 38)) {
      throw new Error("排除床號請填 1–38 的數字，以逗號分隔；不需加 M／P／T／O。");
    }
    const pollSeconds = Number(elements["poll-select"].value);
    const repeatMinutes = Number(elements["repeat-select"].value);
    if (![300, 600].includes(pollSeconds) || ![0, 5, 15, 30, 60].includes(repeatMinutes)) throw new Error("請重新選擇更新與提醒間隔。");
    return {
      capacity,
      threshold,
      pollSeconds,
      repeatMinutes,
      excludedBedNumbers: Array.from(new Set(parts.map(Number))).sort((a, b) => a - b),
      notificationsEnabled: elements["notifications-input"].checked,
      capacityConfirmed: elements["confirmed-input"].checked,
      observation2Open: Boolean(currentState?.settings?.observation2Open),
      paused: Boolean(currentState?.settings?.paused)
    };
  }
  function showMessage(message, error = false) {
    clearTimeout(messageTimer);
    text("action-message", message);
    elements["action-message"].dataset.tone = error ? "danger" : "good";
    elements["action-message"].hidden = false;
    messageTimer = setTimeout(() => {
      elements["action-message"].hidden = true;
    }, error ? 1e4 : 4500);
  }
  function showView(view) {
    const settingsOpen = view === "settings";
    elements["monitor-view"].hidden = settingsOpen;
    elements["settings-view"].hidden = !settingsOpen;
    elements[settingsOpen ? "back-button" : "settings-button"].focus();
  }
  async function send(type, payload = {}) {
    if (previewEnabled) return handlePreview(type, payload);
    if (!extensionAvailable) throw new Error("目前是介面頁面；請從 Chrome 擴充功能開啟，或使用預覽模式。");
    const state = await chrome.runtime.sendMessage({ type, ...payload });
    if (state?.error) throw new Error(typeof state.error === "string" ? state.error : "操作未完成，請再試一次。");
    if (!state || !state.settings) throw new Error("無法取得監控狀態，請重新開啟套件。");
    return state;
  }
  function setBusy(busy) {
    actionInProgress = busy;
    for (const id of ["refresh-button", "pause-button", "source-button", "mute-button", "observation2-button", "save-button"]) elements[id].disabled = busy || !extensionAvailable && !previewEnabled;
  }
  async function perform(type, payload, message) {
    if (actionInProgress) return;
    setBusy(true);
    try {
      const state = await send(type, payload);
      render(state);
      if (message) showMessage(message);
    } catch (error) {
      showMessage(error.message || "操作未完成，請再試一次。", true);
    } finally {
      setBusy(false);
    }
  }
  async function refreshState() {
    if (pollingInProgress || actionInProgress || document.visibilityState === "hidden") return;
    if (!previewEnabled && !extensionAvailable) return;
    pollingInProgress = true;
    try {
      render(await send("GET_STATE"));
    } catch (error) {
      showMessage(error.message || "監控連線中斷，請重新開啟套件。", true);
    } finally {
      pollingInProgress = false;
    }
  }
  elements["refresh-button"].addEventListener("click", () => perform("REFRESH"));
  elements["settings-button"].addEventListener("click", () => showView("settings"));
  elements["back-button"].addEventListener("click", () => showView("monitor"));
  elements["pause-button"].addEventListener("click", () => perform("TOGGLE_PAUSE"));
  elements["source-button"].addEventListener("click", () => perform("OPEN_SOURCE", {}, previewEnabled ? "預覽模式不會開啟病摘頁。" : "已開啟病摘頁；完成登入後可回到套件更新。"));
  elements["mute-button"].addEventListener("click", () => perform("MUTE", { minutes: 30 }, "桌面提醒已靜音 30 分鐘。"));
  elements["observation2-button"].addEventListener("click", () => {
    if (!currentState) return;
    const observation2Open = !currentState.settings.observation2Open;
    return perform("SAVE_SETTINGS", { settings: { observation2Open } }, observation2Open ? "留觀2已標記為開放。" : "留觀2已標記為關閉。");
  });
  elements["settings-form"].addEventListener("input", () => {
    settingsDirty = true;
    elements["settings-error"].hidden = true;
  });
  elements["settings-form"].addEventListener("change", () => {
    settingsDirty = true;
  });
  elements["settings-form"].addEventListener("submit", async (event) => {
    event.preventDefault();
    if (actionInProgress) return;
    try {
      const settings = readSettings();
      setBusy(true);
      const state = await send("SAVE_SETTINGS", { settings });
      settingsDirty = false;
      elements["settings-error"].hidden = true;
      render(state);
      showView("monitor");
      showMessage(settings.capacityConfirmed ? "設定已儲存。" : "設定已儲存；基準未核對，維持試算模式。");
    } catch (error) {
      text("settings-error", error.message || "設定未儲存，請再試一次。");
      elements["settings-error"].hidden = false;
    } finally {
      setBusy(false);
    }
  });
  function createPreviewState(scenario, settings = { ...defaults, capacityConfirmed: scenario !== "trial" }) {
    const threshold = scenario === "threshold";
    const unknown = scenario === "unknown";
    const baseBeds = [
      "M01",
      "M02",
      "M03",
      "M04",
      "M05",
      "M06",
      "M07",
      "M08",
      "M09",
      "M10",
      "P15",
      "P16",
      "T19",
      "T20",
      "T21",
      "T22",
      "O23",
      "O24",
      "O25",
      "O26",
      "O27",
      "O28",
      "O29",
      "O30",
      "O31",
      "O32"
    ];
    const beds = [...baseBeds.slice(0, threshold ? 24 : 18), "A01", "A02", "M17", "M40", "M41", "M42"];
    if (scenario === "observation2_closed_occupied") beds.push("O33", "O34");
    if (unknown) beds.push("X01", "X02");
    const summary = summarizeStretcherPatients(beds.map((bed, index) => ({
      bed,
      encounterId: `synthetic-preview-${index}`,
      status: "在院中"
    })));
    const paused = settings.paused;
    const assessment = assessSnapshot(summary, settings, { fresh: scenario !== "login", loggedIn: scenario !== "login", scopeValid: true, parseErrors: 0, complete: true });
    return {
      settings: { ...settings },
      lastSnapshot: { observedAt: new Date(Date.now() - (scenario === "login" ? 6e5 : 3e3)).toISOString(), summary, parseErrors: 0, scopeValid: true, complete: true, sourceTabId: null },
      assessment,
      connection: { status: paused ? "paused" : scenario === "login" ? "login_required" : !assessment.dataValid ? "invalid" : "ok", message: "", lastAttemptAt: (/* @__PURE__ */ new Date()).toISOString(), sourceTabId: null },
      nextPollAt: paused ? null : new Date(Date.now() + pollSecondsForDisplay(settings.pollSeconds) * 1e3).toISOString(),
      lastAlertAt: null,
      mutedUntil: null
    };
  }
  function handlePreview(type, payload) {
    const settings = { ...previewState.settings };
    const mutedUntil = previewState.mutedUntil;
    if (type === "SAVE_SETTINGS") Object.assign(settings, payload.settings);
    if (type === "TOGGLE_PAUSE") settings.paused = !settings.paused;
    if (["SAVE_SETTINGS", "TOGGLE_PAUSE", "REFRESH"].includes(type)) {
      previewState = createPreviewState(previewScenario, settings);
      previewState.mutedUntil = mutedUntil;
    }
    if (type === "MUTE") previewState.mutedUntil = Date.now() + payload.minutes * 6e4;
    return previewState;
  }
  elements["preview-scenario"].addEventListener("change", () => {
    if (!previewEnabled) return;
    previewScenario = elements["preview-scenario"].value;
    settingsDirty = false;
    previewState = createPreviewState(previewScenario, {
      ...previewState.settings,
      paused: false,
      capacityConfirmed: previewScenario !== "trial",
      observation2Open: previewScenario === "observation2_closed_occupied" ? false : previewState.settings.observation2Open
    });
    render(previewState);
  });
  if (previewEnabled) {
    elements["preview-banner"].hidden = false;
    elements["preview-scenario"].value = previewScenario;
    render(previewState);
  } else if (!extensionAvailable) {
    elements["preview-banner"].hidden = false;
    text("preview-label", "介面預覽 · 未連接 Chrome 擴充功能");
    elements["preview-scenario"].hidden = true;
    render({ settings: defaults, lastSnapshot: null, assessment: null, connection: { status: "no_tab" } });
    setBusy(false);
  } else {
    refreshState();
    chrome.storage?.onChanged?.addListener(() => {
      refreshState();
    });
  }
  if (extensionAvailable || previewEnabled) setInterval(refreshState, 3e3);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") refreshState();
  });
})();
