if (typeof importScripts === "function") importScripts("domain-utils.js");

const DU = typeof KMU_DOMAIN_UTILS !== "undefined"
  ? KMU_DOMAIN_UTILS
  : require("./domain-utils.js");

const CUSTOM_PREFIX = "kmu-custom-";
const LOGIN_GLOBS = [
  "*AuthServer*",
  "*authserver*",
  "*AUTHSERVER*",
  "*Authserver*",
  "*/Account/Login*",
  "*/account/login*",
  "*/ACCOUNT/LOGIN*",
  "*/Login*",
  "*/login*"
];
const CONTENT_JS = ["domain-utils.js", "core.js", "templates.js", "recog.js", "content.js"];

function buildRegistration(domain) {
  return {
    id: DU.registrationId(domain),
    matches: DU.domainOrigins(domain),
    js: CONTENT_JS,
    runAt: "document_idle",
    persistAcrossSessions: true
  };
}

function normalizedDomains(rawDomains) {
  const valid = [];
  for (const raw of Array.isArray(rawDomains) ? rawDomains : []) {
    try {
      const domain = DU.normalizeDomain(raw);
      if (!DU.isAllowedHost(domain, [])) valid.push(domain);
    } catch (error) { /* discard invalid stored data */ }
  }
  return [...new Set(valid)].sort();
}

async function syncCustomContentScripts(api = chrome) {
  if (!api.scripting || typeof api.scripting.getRegisteredContentScripts !== "function") {
    throw new Error("請更新瀏覽器；Safari 自訂白名單需要 Safari 16.4 以上。");
  }
  const stored = await api.storage.local.get({ customDomains: [] });
  const candidates = normalizedDomains(stored.customDomains);
  const activeDomains = [];

  for (const domain of candidates) {
    if (await api.permissions.contains({ origins: DU.domainOrigins(domain) })) activeDomains.push(domain);
  }

  if (JSON.stringify(activeDomains) !== JSON.stringify(stored.customDomains || [])) {
    await api.storage.local.set({ customDomains: activeDomains });
  }

  const current = await api.scripting.getRegisteredContentScripts();
  const oldIds = current
    .filter((item) => item.id.startsWith(CUSTOM_PREFIX))
    .map((item) => item.id);
  if (oldIds.length) await api.scripting.unregisterContentScripts({ ids: oldIds });
  if (activeDomains.length) {
    await api.scripting.registerContentScripts(activeDomains.map(buildRegistration));
  }
  return { activeDomains };
}

if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onInstalled) {
  const sync = () => syncCustomContentScripts().catch(console.error);
  chrome.runtime.onInstalled.addListener(sync);
  chrome.runtime.onStartup.addListener(sync);
  chrome.permissions.onRemoved.addListener(sync);
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (!message || message.type !== "syncWhitelist") return;
    syncCustomContentScripts().then(
      (result) => reply({ ok: true, ...result }),
      (error) => reply({ ok: false, error: error.message })
    );
    return true;
  });
}

if (typeof module !== "undefined") {
  module.exports = { buildRegistration, syncCustomContentScripts, LOGIN_GLOBS, CONTENT_JS };
}
