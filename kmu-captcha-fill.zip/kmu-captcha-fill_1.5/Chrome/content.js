// KMU 體系登入頁：同時找到驗證碼圖與輸入欄才動作；只填驗證碼欄，帳號密碼不讀值、不存、不送出。
let collecting = false;

// 收集樣本（v1.0.2，老闆 msg 377 實測常認錯）：popup 按鈕觸發，點圖換 n 張，只存驗證碼圖本身，下載成 JSON 檔讓老闆傳回來做專用辨識
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "collect") return;
  const img = document.getElementById("kmuh-captcha-img");
  if (!img) { reply({ ok: false, why: "這一頁沒有驗證碼圖，請先打開單一入口登入頁" }); return; }
  if (collecting) { reply({ ok: false, why: "正在收集中" }); return; }
  reply({ ok: true });
  collectSamples(Math.min(Math.max(+msg.n || 40, 1), 60));
});
async function collectSamples(n) {
  collecting = true;
  const seen = new Set(), out = [];
  const say = (t) => { let b = document.getElementById("kmuh-captcha-fill-banner"); if (!b) { b = document.createElement("div"); b.id = "kmuh-captcha-fill-banner"; b.style.cssText = "position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:2147483647;padding:8px 14px;border-radius:6px;font:14px/1.5 sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.25);max-width:90vw;background:#e6f2ee;color:#1f6f5c"; document.body.appendChild(b); } b.textContent = "驗證碼外掛：" + t; };
  try {
    for (let tries = 0; out.length < n && tries < n * 2; tries++) {
      const img = document.getElementById("kmuh-captcha-img");
      if (!img) break;
      if (!img.complete || !img.naturalWidth) await new Promise((r) => { img.onload = r; img.onerror = r; setTimeout(r, 2000); });
      let src = img.src;
      if (!/^data:image\//.test(src)) { try { const c = document.createElement("canvas"); c.width = img.naturalWidth; c.height = img.naturalHeight; c.getContext("2d").drawImage(img, 0, 0); src = c.toDataURL("image/png"); } catch (e) { src = ""; } }
      if (src && !seen.has(src)) { seen.add(src); out.push(src); }
      say(`收集驗證碼樣本中：${out.length} / ${n}（請不要操作這一頁）`);
      const before = img.src;
      img.click();
      for (let k = 0; k < 30 && document.getElementById("kmuh-captcha-img") && document.getElementById("kmuh-captcha-img").src === before; k++) await new Promise((r) => setTimeout(r, 100));
      await new Promise((r) => setTimeout(r, 200));
    }
    if (!out.length) { say("一張都沒收到（讀不到驗證碼圖），沒有下載。請把這個情況告訴助理。"); return; } // B 低2
    const d = new Date(), p2 = (x) => String(x).padStart(2, "0");
    const name = `kmuh-captcha-samples_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}.json`;
    const blob = new Blob([JSON.stringify({ kind: "kmuh-captcha-samples", version: 1, host: location.host, count: out.length, images: out })], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 5000);
    say(`已收集 ${out.length} 張，下載成 ${name}（只有驗證碼圖），請把這個檔案傳給助理。`);
  } finally { collecting = false; }
}

(async () => {
  if (!KMU_DOMAIN_UTILS.isLoginUrl(location.href)) return;
  const cfg = await chrome.storage.local.get({ enabled: true, customDomains: [] });
  if (!cfg.enabled || !KMU_DOMAIN_UTILS.isAllowedHost(location.hostname, cfg.customDomains)) return;
  const img0 = await waitFor(() => findCaptchaImage(), 5000);
  if (!img0) return;
  if (!findInput()) return;
  if (document.documentElement.hasAttribute("data-kmu-captcha-fill-active")) return;
  document.documentElement.setAttribute("data-kmu-captcha-fill-active", "true");
  let revision = 0, running = false, timer, internalRefresh = false;
  let lastInput = null, lastValue = "", manual = false, writing = false;
  let watchedImage = img0, watchedSource = img0.src;
  const internalLoads = new WeakMap();

  function canWrite(input) {
    return input && (!input.value || (!manual && input === lastInput && input.value === lastValue));
  }
  function invalidate() {
    revision++;
    const input = findInput();
    if (input && input === lastInput && !manual && input.value === lastValue) {
      writing = true;
      try { setValue(input, ""); } finally { writing = false; }
    }
  }
  function schedule() {
    if (collecting || internalRefresh) return;
    invalidate();
    clearTimeout(timer);
    timer = setTimeout(() => recognizeLatest().catch(console.error), 80);
  }
  async function recognizeLatest() {
    if (running || collecting) return;
    const request = revision;
    const input = findInput();
    if (!canWrite(input)) return;
    running = true;
    try {
      const settings = await chrome.storage.local.get({ enabled: true, customDomains: [] });
      if (!settings.enabled || !KMU_DOMAIN_UTILS.isAllowedHost(location.hostname, settings.customDomains)) return;
      if (request !== revision || !canWrite(input)) return;
      banner("辨識驗證碼中…");
      let code = "";
      for (let attempt = 0; attempt < MAX_READS && !code; attempt++) {
        if (request !== revision || !canWrite(input) || collecting) return;
        const img = findCaptchaImage();
        if (!img) return;
        const source = img.src;
        try { code = cleanCode((await readCaptcha(img)).code); } catch (error) { code = ""; }
        internalRefresh = false;
        if (request !== revision || img !== findCaptchaImage() || source !== img.src) return;
        if (!code && attempt < MAX_READS - 1) {
          internalRefresh = true;
          try {
            img.click();
            await waitFor(() => {
              const next = findCaptchaImage();
              return next && (next !== img || next.src !== source) ? next : null;
            }, 3000);
            await sleep(300);
          } catch (error) { internalRefresh = false; throw error; }
        }
      }
      if (request !== revision || collecting || !canWrite(input) || input !== findInput()) return;
      if (!code) { banner("驗證碼辨識不出來，請手動輸入或點圖重試。", true); return; }
      lastInput = input;
      lastValue = code;
      manual = false;
      writing = true;
      try { setValue(input, code); } finally { writing = false; }
      // 只填驗證碼；使用者自行確認後登入。
      banner(`驗證碼已填入 ${code}，請自行確認後按「登入」。`);
    } finally {
      internalRefresh = false;
      running = false;
      if (request !== revision) {
        clearTimeout(timer);
        timer = setTimeout(() => recognizeLatest().catch(console.error), 80);
      }
    }
  }
  document.addEventListener("input", (event) => {
    if (!writing && event.target === findInput()) {
      manual = !!event.target.value;
      revision++;
    }
  }, true);
  document.addEventListener("click", (event) => {
    if (event.target === findCaptchaImage() && (!internalRefresh || event.isTrusted)) {
      internalLoads.delete(event.target);
      invalidate();
    }
  }, true);
  document.addEventListener("load", (event) => {
    if (internalLoads.get(event.target) === event.target.src) {
      internalLoads.delete(event.target);
      return;
    }
    if (event.target === findCaptchaImage()) schedule();
  }, true);
  const imageObserver = new MutationObserver((mutations) => {
    const img = findCaptchaImage();
    const source = img && img.src;
    if (img && internalRefresh && (img !== watchedImage || mutations.some((item) => item.target === img))) {
      internalLoads.set(img, source);
    }
    if (img !== watchedImage || source !== watchedSource) {
      watchedImage = img;
      watchedSource = source;
      if (img) {
        if (!internalRefresh) internalLoads.delete(img);
        schedule();
      }
    }
  });
  imageObserver.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "srcset"] });
  schedule();
  return;

  // ---- 小工具
  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
  function waitFor(fn, ms) {
    return new Promise((res) => {
      const v = fn(); if (v) return res(v);
      const ob = new MutationObserver(() => { const x = fn(); if (x) { ob.disconnect(); clearTimeout(t); res(x); } });
      ob.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      const t = setTimeout(() => { ob.disconnect(); res(fn() || null); }, ms);
    });
  }
  function findInput() {
    return document.querySelector('input[name="kmuh-captcha"]') || document.getElementById("kmuh-captcha")
      || document.querySelector('input[name*="captcha" i]:not([type=hidden]), input[id*="captcha" i]:not([type=hidden])');
  }
  function findCaptchaImage() {
    const candidates = [
      document.getElementById("kmuh-captcha-img"),
      ...document.querySelectorAll("img[id*='captcha' i], img[name*='captcha' i], img[src*='captcha' i], img[alt*='驗證碼'], img[title*='驗證碼']")
    ].filter((img, index, all) => img && all.indexOf(img) === index);
    return candidates.find((img) => {
      const w = img.naturalWidth || img.width || 0;
      const h = img.naturalHeight || img.height || 0;
      return w > 0 && h > 0 && w <= 400 && h <= 200;
    }) || null;
  }
  // 密碼欄是 Chrome 自動填入（值被保護、讀到空字串）→ 只用來挑提示文字，不據此送出
  function looksAutofilled(el) {
    const pw = (el.form || document).querySelector('input[type=password]');
    const m = (sel) => { try { return !!pw && pw.matches(sel); } catch (e) { return false; } };
    return m(":autofill") || m(":-webkit-autofill");
  }
  // 帳號、密碼欄讀得到值才算已填（不讀出值本身，只看是否為空）
  function credsReadable(el) {
    const scope = el.form || document;
    const pw = scope.querySelector('input[type=password]');
    const user = scope.querySelector('input[name="username"], input[type=text]:not([name*="captcha" i]), input[type=email]');
    return !!pw && pw.value !== "" && (!user || user.value !== "");
  }
  function setValue(el, v) {
    const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    set.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  // v1.1.0：院內驗證碼專用辨識（recog.js＋templates.js），在頁面裡直接算，不再用 tesseract
  async function readCaptcha(img) {
    if (!img.complete || !img.naturalWidth) await new Promise((resolve) => {
      const done = () => { clearTimeout(timeout); img.removeEventListener("load", done); img.removeEventListener("error", done); resolve(); };
      const timeout = setTimeout(done, 2000);
      img.addEventListener("load", done);
      img.addEventListener("error", done);
    });
    if (!img.complete || !img.naturalWidth) return { code: "" };
    const w = img.naturalWidth, h = img.naturalHeight;
    if (!w || !h || w > 400 || h > 200) return { code: "" };
    const c = document.createElement("canvas"); c.width = w; c.height = h;
    const g = c.getContext("2d", { willReadFrequently: true });
    g.drawImage(img, 0, 0);
    return KMU_RECOG.recognize(g.getImageData(0, 0, w, h).data, w, h);
  }
  function banner(text, warn) {
    let b = document.getElementById("kmuh-captcha-fill-banner");
    if (!b) {
      b = document.createElement("div"); b.id = "kmuh-captcha-fill-banner";
      b.style.cssText = "position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:2147483647;padding:8px 14px;border-radius:6px;font:14px/1.5 sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.25);max-width:90vw";
      document.body.appendChild(b);
    }
    b.style.background = warn ? "#fff4bf" : "#e6f2ee"; b.style.color = warn ? "#8a5a00" : "#1f6f5c";
    b.textContent = "驗證碼外掛：" + text;
  }
})();
