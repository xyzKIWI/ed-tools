// 純函式（content script 與 node 測試共用）

// 辨識結果 → 4 碼英數（不分大小寫，一律轉大寫）；長度不對回 ""，不填（B 審查要求）
function cleanCode(text) {
  const s = String(text == null ? "" : text).toUpperCase().replace(/[^A-Z0-9]/g, "");
  return /^[A-Z0-9]{4}$/.test(s) ? s : "";
}

// 自動送出次數：同一分頁 3 分鐘內最多 2 次（照原程式「錯兩次改手動」，也避免帳號被鎖）
const MAX_SUBMITS = 2, WINDOW_MS = 3 * 60e3;
function triesNow(saved, now) {
  const s = saved && typeof saved === "object" ? saved : null;
  return s && Number.isFinite(s.n) && Number.isFinite(s.t) && now - s.t < WINDOW_MS && now >= s.t ? s.n : 0;
}
function canAutoSubmit(saved, now) { return triesNow(saved, now) < MAX_SUBMITS; }
function bump(saved, now) { return { n: triesNow(saved, now) + 1, t: now }; }

// 單頁內辨識次數上限：辨識不出 4 碼就點圖換一張，最多辨識 3 次
const MAX_READS = 3;

if (typeof module !== "undefined") module.exports = { cleanCode, triesNow, canAutoSubmit, bump, MAX_SUBMITS, WINDOW_MS, MAX_READS };
