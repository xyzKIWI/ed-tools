# KMU 體系驗證碼填入

內建網域：`kmuh.org.tw`、`kmu.edu.tw`、`kmugh.org.tw`、`kmsh.org.tw`、`kmch.org.tw`。也可以在擴充功能彈窗中自行加入其他 HTTPS 網域。

## 下載

- [下載 1.5 整合包：Chrome／Edge／Comet＋Safari](https://er.kiwi-ai.uk/kmu-captcha-fill.zip)
- [Safari Userscripts 腳本](https://er.kiwi-ai.uk/kmu-captcha-fill.user.js)（Mac／iPhone／iPad）
- [GitHub 版本與歷史封存](https://github.com/xyzKIWI/kmu-captcha-fill/releases)
- [EDTools 安裝與使用說明](https://er.kiwi-ai.uk/kmu-captcha-fill.html)

目前版本：`v1.5`（內部版號 `1.5.0`，2026-11-24）。原始碼 repo 維持 private；網站下載不需要 GitHub 登入。

開啟登入頁會自動辨識；點擊驗證碼圖片換圖後也會重新辨識。換圖時會清除外掛填入的舊碼，快速連點只保留最新圖片結果，使用者手動輸入的內容不會被覆蓋。

## 一個資料夾、同一個 ZIP

解壓後的 `kmu-captcha-fill_1.5/` 包含全部版本：

| 內容 | 安裝方式 |
|---|---|
| `Chrome/manifest.json` 與程式 | Chrome／Edge／Comet「載入未封裝項目」選 `Chrome/` 子資料夾 |
| `Safari/KMU Captcha Fill.app` | Mac Safari App，移至「應用程式」後啟用延伸功能 |
| `Userscripts/kmu-captcha-fill.user.js` | Mac／iPhone／iPad 的 Safari，透過 Userscripts 安裝 |
| `README.md` | 本安裝說明 |

Chrome 與 Safari 的安裝方式不同，但下載同一包即可。Safari 可選 Userscripts 或 App 其中一種方式。

## 安全設計

- 僅在頁面同時偵測到驗證碼圖與驗證碼輸入欄時執行。
- 在瀏覽器本機辨識四碼英數驗證碼；不傳送圖片或資料到外部服務。
- 不讀取、不保存帳號或密碼。
- 不會按下登入；使用者需自行確認與提交。
- 自訂網域使用 Chrome 的選擇性網站權限；未按「加入」並核准前，擴充功能不能讀取該網域。

## 管理自訂網域

1. 點擊擴充功能圖示，找到「允許網域」。
2. 只輸入網域，例如 `example.org.tw`，不要輸入 `https://`、路徑或 port。
3. 按「加入」，確認 Chrome 顯示的權限只有該網域及其子網域。
4. 重新整理已開啟的登入頁；符合登入路徑且具有 CAPTCHA 圖片與欄位時才會執行。
5. 不再使用時，按該網域旁的「移除」；擴充功能會停止動態注入並要求 Chrome 撤銷網站權限。

完整 URL、路徑、query、port、萬用字元、IP、`localhost` 及無效 DNS 名稱會被拒絕。內建網域不可刪除，也不需額外授權。

## 測試載入

1. 開啟 `chrome://extensions`。
2. 開啟右上角「開發人員模式」。
3. 選「載入未封裝項目」，選取整合包裡的 `Chrome/` 子資料夾（內含 `manifest.json`）。
4. 前往登入頁，確認僅填入驗證碼且未送出表單。

更新整合包時維持相同安裝路徑並替換內容，在擴充功能頁按「重新載入」。開發用原始碼根目錄也可直接載入：Kiwi 本機既有路徑為 `/Users/kiwi/kiwi_cc/kmu-captcha-fill`，既有使用者可沿用。

## Safari：Userscripts（Mac／iPhone／iPad）

1. 從 [App Store 安裝 Userscripts](https://apps.apple.com/app/userscripts/id1463298887)，在 Safari 延伸功能設定中啟用。
2. 開啟上方 `.user.js` 連結，在 Userscripts 彈窗選擇安裝；或把整合包 `Userscripts/` 裡的 `.user.js` 存到 Userscripts 設定的腳本資料夾。
3. 將目標網站的 Userscripts 權限設為「一律允許」，重新整理登入頁。
4. 停用舊的 KMU Safari App 延伸功能，避免與新腳本同時啟用。新版有防重複執行機制，舊版未必有。

這種方式不需要每次重開 Safari 允許未簽署延伸功能。首次安裝、增加網站或重設權限時，仍需確認網站存取權限。

腳本含內建網域；自訂網域請在 Userscripts 編輯器的標頭加入一行，例如 `// @match https://*.example.org.tw/*`，儲存並允許該網站存取。需精確主網域時可另加 `// @match https://example.org.tw/*`。腳本根據已安裝標頭的 `@match` 取得自訂白名單；更新腳本時請保留自行加入的規則。開關可用 Userscripts 的每腳本啟用切換。這與 Chrome／Edge／Comet 的彈窗白名單分開。

## Safari App（macOS 12.3 以上、Safari 16.4 以上）

1. 解壓整合包，將 `Safari/KMU Captcha Fill.app` 移至「應用程式」並開啟。
2. 目前提供本機開發版，尚未使用 Apple Developer ID 簽署／公證；如 macOS 阻擋，請在「系統設定 → 隱私權與安全性」查看「仍要打開」。
3. Safari「設定 → 進階」開啟網頁開發者功能，再於「設定 → 開發者」勾選「允許未簽署的延伸功能」（舊版在「開發」選單）。Safari 重開後可能需重新勾選。
4. Safari「設定 → 延伸功能」啟用 KMU Captcha Fill，允許目標網站存取，重新整理登入頁。
5. 在工具列彈窗加入自訂網域時，另核准 Safari 網站權限。

Chrome、Edge、Comet 共用根目錄的 `manifest.json` 與程式；Safari 由同一份程式產生 App。各瀏覽器的白名單設定分別儲存。

## 建置

`node scripts/package.mjs` 產生 `build/chromium/`、`build/safari/` 與 `build/userscripts/`（自含辨識資料，不載入外部程式）。macOS 安裝 Xcode 後，執行 `bash scripts/build-safari.sh`，App 位於 `build/safari-derived/Build/Products/Release/`。Safari App 在 manifest 使用背景頁，並透過共用登入路徑檢查限定執行範圍。

執行 `node scripts/package-universal.mjs` 產生 `build/universal/kmu-captcha-fill_1.5/`，再以 `ditto -c -k --norsrc --keepParent build/universal/kmu-captcha-fill_1.5 build/releases/kmu-captcha-fill.zip` 產生網站整合 ZIP。所有平台的內部版號均為 `1.5.0`。

Safari App 已通過 Xcode 雙架構建置；真實登入頁的 Safari 端互動仍需啟用延伸功能後驗收。

## v1.5 手動驗收

- 新增測試網域並核對 Chrome 權限提示範圍。
- 拒絕一次權限，確認網域沒有加入。
- 重新啟動 Chrome，確認已核准的網域仍保留。
- 確認同網域的非登入頁不執行，登入頁也必須有 CAPTCHA 元素才執行。
- 確認只填入 CAPTCHA，登入按鈕沒有被觸發。
- 點擊圖片換碼、連續換碼與整張圖片替換後，確認欄位更新為最新結果；手動輸入後換碼，確認不會覆蓋手動值。
- 移除網域並重新整理，確認不再注入。
- 從 Chrome 擴充功能設定手動撤銷網站權限，確認下一次同步會清除失效項目。
- 在 Chrome 工具列確認盾牌圖示大小與相鄰擴充功能相近，且四周沒有被裁切。

若目標頁的驗證碼圖片或輸入欄沒有常見的 `captcha` 識別字，擴充功能會不動作；請提供去識別化的 HTML 欄位名稱或畫面，才能安全加入明確選擇器。

## 歷史版本

- `v1.1.0` 原始 ZIP 保存在 `archive/v1.1.0/`，並另存於 GitHub Release。
- `v1.1.0` 具有自動按登入與錯誤重試行為，僅供歷史留存；日常使用請採用 `v1.3.1` 以上版本。

## License

MIT
