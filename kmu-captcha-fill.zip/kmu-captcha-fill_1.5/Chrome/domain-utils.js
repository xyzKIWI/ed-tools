var KMU_DOMAIN_UTILS = (function () {
  const BUILT_IN_DOMAINS = Object.freeze([
    "kmuh.org.tw",
    "kmu.edu.tw",
    "kmugh.org.tw",
    "kmsh.org.tw",
    "kmch.org.tw"
  ]);

  function isIp(host) {
    if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) return true;
    return host.includes(":");
  }

  function normalizeDomain(raw) {
    const input = String(raw == null ? "" : raw).trim().toLowerCase();
    if (!input || /:\/\/|[\/?#*]|:\d+$/.test(input)) {
      throw new Error("請只輸入網域，不要包含網址、路徑、port 或萬用字元。");
    }

    let hostname;
    try {
      hostname = new URL("https://" + input).hostname.toLowerCase().replace(/\.$/, "");
    } catch (error) {
      throw new Error("網域格式不正確。");
    }

    if (!hostname || hostname === "localhost" || !hostname.includes(".") || isIp(hostname)) {
      throw new Error("請輸入有效的網際網路網域。");
    }
    const labels = hostname.split(".");
    if (labels.some((label) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))) {
      throw new Error("網域格式不正確。");
    }
    if (hostname.length > 253) throw new Error("網域過長。");
    return hostname;
  }

  function domainOrigins(domain) {
    const normalized = normalizeDomain(domain);
    return [`https://${normalized}/*`, `https://*.${normalized}/*`];
  }

  function registrationId(domain) {
    return "kmu-custom-" + normalizeDomain(domain).replace(/\./g, "_");
  }

  function hostMatchesDomain(host, domain) {
    const normalizedHost = String(host || "").toLowerCase().replace(/\.$/, "");
    const normalizedDomain = normalizeDomain(domain);
    return normalizedHost === normalizedDomain || normalizedHost.endsWith("." + normalizedDomain);
  }

  function isAllowedHost(host, customDomains) {
    return [...BUILT_IN_DOMAINS, ...(Array.isArray(customDomains) ? customDomains : [])]
      .some((domain) => hostMatchesDomain(host, domain));
  }

  function isLoginUrl(url) {
    try {
      const parsed = new URL(url);
      return parsed.protocol === "https:" && /authserver|\/login/i.test(parsed.pathname);
    } catch (error) { return false; }
  }

  return {
    BUILT_IN_DOMAINS,
    normalizeDomain,
    domainOrigins,
    registrationId,
    hostMatchesDomain,
    isAllowedHost,
    isLoginUrl
  };
})();

if (typeof module !== "undefined") module.exports = KMU_DOMAIN_UTILS;
