(async () => {
  const DU = KMU_DOMAIN_UTILS;
  const enabled = document.getElementById("enabled");
  const form = document.getElementById("domain-form");
  const input = document.getElementById("domain-input");
  const status = document.getElementById("status");
  const builtInList = document.getElementById("built-in-domains");
  const customList = document.getElementById("custom-domains");
  let cachedCustomDomains = [];

  function say(text, ok = false) {
    status.textContent = text;
    status.className = text ? (ok ? "ok" : "error") : "";
  }

  async function loadState() {
    return chrome.storage.local.get({ enabled: true, customDomains: [] });
  }

  async function requestSync() {
    const result = await chrome.runtime.sendMessage({ type: "syncWhitelist" });
    if (!result || !result.ok) throw new Error((result && result.error) || "白名單同步失敗。");
    return result;
  }

  async function saveDomains(domains) {
    const customDomains = [...new Set(domains.map(DU.normalizeDomain))].sort();
    await chrome.storage.local.set({ customDomains });
    await requestSync();
    return customDomains;
  }

  function row(domain, removable) {
    const li = document.createElement("li");
    li.className = "domain-row";
    const text = document.createElement("span");
    text.textContent = domain;
    li.appendChild(text);
    if (removable) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "remove";
      button.textContent = "移除";
      button.addEventListener("click", () => removeDomain(domain));
      li.appendChild(button);
    } else {
      const badge = document.createElement("small");
      badge.textContent = "內建";
      li.appendChild(badge);
    }
    return li;
  }

  async function render() {
    const state = await loadState();
    enabled.checked = !!state.enabled;
    builtInList.replaceChildren(...DU.BUILT_IN_DOMAINS.map((domain) => row(domain, false)));
    const custom = (state.customDomains || []).map(DU.normalizeDomain).sort();
    cachedCustomDomains = custom;
    const empty = document.createElement("li");
    empty.textContent = "尚未新增";
    customList.replaceChildren(...(custom.length ? custom.map((domain) => row(domain, true)) : [empty]));
  }

  async function addDomain() {
    say("");
    let domain;
    try {
      domain = DU.normalizeDomain(input.value);
    } catch (error) {
      say(error.message);
      return;
    }

    const current = [...cachedCustomDomains];
    if (DU.isAllowedHost(domain, [])) {
      say("這是內建網域或其子網域，不需重複加入。");
      return;
    }
    if (current.some((item) => DU.hostMatchesDomain(domain, item))) {
      say("這個網域已由現有白名單涵蓋。");
      return;
    }

    const origins = DU.domainOrigins(domain);
    const granted = await chrome.permissions.request({ origins });
    if (!granted) {
      say("瀏覽器未授予權限，因此沒有加入。");
      return;
    }

    try {
      await saveDomains([...current, domain]);
      input.value = "";
      await render();
      say(`已加入 ${domain}，請重新整理登入頁。`, true);
    } catch (error) {
      await chrome.storage.local.set({ customDomains: current });
      await requestSync().catch(() => null);
      await chrome.permissions.remove({ origins }).catch(() => false);
      say(`加入失敗：${error.message}`);
    }
  }

  async function removeDomain(domain) {
    say("");
    const before = [...cachedCustomDomains];
    try {
      await saveDomains(before.filter((item) => DU.normalizeDomain(item) !== domain));
      const removed = await chrome.permissions.remove({ origins: DU.domainOrigins(domain) });
      await render();
      say(
        removed
          ? `已移除 ${domain}。`
          : `已停止使用 ${domain}；瀏覽器沒有回報可撤銷的權限。`,
        true
      );
    } catch (error) {
      await chrome.storage.local.set({ customDomains: before });
      await requestSync().catch(() => null);
      say(`移除失敗：${error.message}`);
    }
  }

  enabled.addEventListener("change", () => chrome.storage.local.set({ enabled: enabled.checked }));
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    addDomain().catch((error) => say(error.message));
  });
  await render();
})();
