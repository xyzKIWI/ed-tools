/* CXR 重新標註：急診清單（ipdNote ER_Main，附院與岡山）的頁面腳本。
 * 滑鼠移到清單上某一位病人，那一列右邊會浮出「🩻 PACS」按鈕；點選過的病人那一列會一直顯示（0.6.0）。
 * 按下去開外掛的「PACS 回顧」小視窗（0.6.0：整個瀏覽器只開一個；開著時點選別的病人，內容自動跟著換），
 * 列出這位病人在同院區 WebPACS 的檢查。
 * 按鈕不放進表格裡（放在頁面最外層、蓋在那一列上），不動清單本身，也不會觸發點選病人。
 * 對院內系統唯讀：只讀清單每一列本來就帶著的資料（td[data-erinfo]），不存清單。 */
(function () {
  'use strict';
  if (window.top !== window || !/^\/WEB\/ipdNote\/ER_Main(?:\/Index)?\/?$/i.test(location.pathname)) return;
  if (window.__cxrReviewLoaded) return;
  window.__cxrReviewLoaded = true;

  const ROW = '#ERPatientListTable tr';
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.id = 'cxr-relabel-pacs-btn';
  btn.textContent = '🩻 PACS';
  btn.title = '在 PACS 回顧小視窗列出這位病人的 WebPACS 影像（CXR 重新標註外掛）';
  btn.style.cssText = 'position:fixed;z-index:2147483000;display:none;padding:2px 8px;font:12px/1.5 "Microsoft JhengHei",system-ui,sans-serif;' +
    'border:1px solid #0277bd;border-radius:4px;background:#e1f5fe;color:#01579b;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.25);';
  // current：按鈕現在畫在哪一列（按下去就開這一列的病人）。
  // hover：滑鼠停著的那一列；pinned：點選過的病人（滑鼠移開後按鈕回到這一列，一直顯示）。
  let current = null, hover = null, pinnedChart = '', pinnedEl = null, hideTimer = 0;

  const infoOf = (row) => { try { return JSON.parse(row.querySelector('td[data-erinfo]').textContent); } catch (e) { return null; } };
  // 交給回顧小視窗的：這一列本來就帶著的欄位（只在按下或點選的當下讀）
  function jobOf(info) {
    const outRadio = document.getElementById('ERSTATUSout');
    return {
      chart: chartOf(info), name: info.PTNAME, bed: info['床號'], seq: info['檢傷序號'], status: info.STATUSNAME,
      since: info.CHECKINTIME, until: info.CHECKOUTTIME, aiurl: info.AIURL || '', listOut: !!(outRadio && outRadio.checked),
    };
  }
  const chartOf = (info) => { const c = String((info && info['病歷號']) || '').trim(); return /^\d{4,12}$/.test(c) ? c : ''; };

  // 清單放在可以捲動的框裡（真頁面：#ControlERPatientListTable，overflow:auto），打開病歷區後只剩半邊寬。
  // 按鈕要放在「框裡看得到的那一段列」的右端，不能用整列的右端（會跑到病歷區上面或框外）。
  function visibleBox(row) {
    const r = row.getBoundingClientRect();
    let left = Math.max(0, r.left), right = Math.min(innerWidth, r.right), top = Math.max(0, r.top), bottom = Math.min(innerHeight, r.bottom);
    for (let e = row.parentElement; e && e !== document.documentElement; e = e.parentElement) {
      const cs = getComputedStyle(e);
      if (cs.overflowX === 'visible' && cs.overflowY === 'visible') continue;
      const b = e.getBoundingClientRect();
      left = Math.max(left, b.left + e.clientLeft); right = Math.min(right, b.left + e.clientLeft + e.clientWidth);
      top = Math.max(top, b.top + e.clientTop); bottom = Math.min(bottom, b.top + e.clientTop + e.clientHeight);
    }
    return { left, right, top, bottom, rowTop: r.top, rowHeight: r.height };
  }
  function place(row) {
    const v = visibleBox(row);
    btn.style.display = 'block';
    const w = btn.offsetWidth, h = btn.offsetHeight;
    // 看得到的部分太小（捲到框外、框太窄）就先不顯示；捲回來會再出現
    if (!v.rowHeight || v.bottom - v.top < h * 0.6 || v.right - v.left < w + 12) { btn.style.display = 'none'; return; }
    btn.style.left = Math.round(v.right - w - 6) + 'px';
    btn.style.top = Math.round(Math.min(Math.max(v.rowTop + (v.rowHeight - h) / 2, v.top), v.bottom - h)) + 'px';
  }
  const patientRow = (row) => !!(row && row.isConnected && row.querySelector('td[data-erinfo]') && chartOf(infoOf(row)));
  // 點選過的病人那一列。清單重新載入後列會換新，用病歷號找回來；換到在院／出院另一張清單、病人不在了就不顯示。
  // 還沒點選過時，跟著頁面自己標起來的那一列（class="highlight"）。
  function pinnedRow() {
    if (!pinnedChart) { const h = document.querySelector('#ERPatientListTable tr.highlight'); return patientRow(h) ? h : null; }
    if (patientRow(pinnedEl) && chartOf(infoOf(pinnedEl)) === pinnedChart) return pinnedEl;
    pinnedEl = [...document.querySelectorAll(ROW)].find((r) => patientRow(r) && chartOf(infoOf(r)) === pinnedChart) || null;
    return pinnedEl;
  }
  function update() {
    if (hover && !patientRow(hover)) hover = null;
    current = hover || pinnedRow();
    if (current) place(current); else btn.style.display = 'none';
  }

  document.addEventListener('mouseover', (e) => {
    const t = e.target instanceof Element ? e.target : null;
    if (!t || t === btn) { clearTimeout(hideTimer); return; }
    const row = t.closest(ROW);
    clearTimeout(hideTimer);
    if (patientRow(row)) { hover = row; return update(); }
    hideTimer = setTimeout(() => { hover = null; update(); }, 250); // 滑鼠離開清單：回到點選的那一列
  }, true);
  // 點選病人（頁面自己用 mousedown 選病人）：記住是誰，按鈕之後一直留在那一列
  document.addEventListener('mousedown', (e) => {
    const t = e.target instanceof Element ? e.target : null;
    const row = t && t !== btn ? t.closest(ROW) : null;
    if (!patientRow(row)) return;
    const info = infoOf(row);
    pinnedChart = chartOf(info); pinnedEl = row;
    update();
    // PACS 回顧小視窗開著的話，跟著換成這位（沒開就什麼都不做；不搶焦點）
    try { chrome.runtime.sendMessage({ type: 'review-follow', job: jobOf(info) }).catch(() => {}); } catch (err) { /* 外掛剛更新過 */ }
  }, true);
  addEventListener('scroll', update, true);
  addEventListener('resize', update);
  // 清單重新查詢、版面切換（打開病歷區）之後重新找位置
  let moTimer = 0;
  new MutationObserver((recs) => { if (recs.every((r) => r.target === btn)) return; clearTimeout(moTimer); moTimer = setTimeout(update, 150); }) // 按鈕自己動的不算，免得自己觸發自己
    .observe(document.body || document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });

  // 不讓頁面自己的滑鼠處理（選病人、開病歷）接到這顆按鈕的事件
  for (const t of ['mousedown', 'mouseup', 'dblclick']) btn.addEventListener(t, (e) => e.stopPropagation());
  btn.addEventListener('click', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const row = current;
    const info = row && row.isConnected ? infoOf(row) : null; // 按下去的當下才讀，清單換過也不會拿到上一位
    const chart = chartOf(info);
    if (!chart) { btn.style.display = 'none'; return alert('讀不到這一列的病歷號，請重新整理清單後再試。'); }
    try {
      const r = await chrome.runtime.sendMessage({ type: 'review-open', job: jobOf(info) });
      if (!r || !r.ok) alert('無法開啟 PACS 回顧視窗' + (r && r.reason ? '（' + r.reason + '）' : '') + '。');
    } catch (err) {
      alert('無法開啟 PACS 回顧視窗：' + String((err && err.message) || err) + '\n（外掛剛更新過的話，請重新整理這一頁）');
    }
  });
  (document.body || document.documentElement).appendChild(btn);
})();
