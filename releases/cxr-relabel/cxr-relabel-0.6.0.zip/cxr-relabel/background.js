// 背景程式：
//   1. 把標註畫面交來的檔案存進「下載」資料夾底下的 CXR_relabel（url 一律是 data:，不連網路）。
//   2. 在分頁之間轉送：AI 結果頁／標註分頁 ⇄ 已登入的 WebPACS 分頁。
//      取圖的請求是 WebPACS 分頁自己發的（pacs.js），背景程式只傳話，不碰通行碼。

importScripts('core.js'); // 用到 CXRCore.cleanDir（檢查存檔資料夾）與 CXRCore.siteByHost（院區對應）

const waitDone = (id) =>
  new Promise((resolve) => {
    const t0 = Date.now();
    const tick = async () => {
      const [it] = await chrome.downloads.search({ id });
      if (it && it.state === 'complete') return resolve({ ok: true, path: it.filename });
      if (it && it.state === 'interrupted') return resolve({ ok: false, error: it.error || 'interrupted' });
      if (Date.now() - t0 > 60000) return resolve({ ok: false, error: '等待存檔逾時' });
      setTimeout(tick, 150);
    };
    tick();
  });

async function save(files) {
  const paths = [];
  for (const f of files) {
    // 檔名＝「下載」底下的資料夾／檔案。資料夾要過 cleanDir（不能跳出「下載」），檔案只收這幾種。
    const cut = String(f.filename).lastIndexOf('/');
    const dir = f.filename.slice(0, cut), name = f.filename.slice(cut + 1);
    if (!/^data:/.test(f.url) || cut < 1 || CXRCore.cleanDir(dir) !== dir || !/^[\w.-]+\.(png|jpg|json|dcm)$/.test(name)) throw new Error('不接受的檔案：' + f.filename);
    const id = await chrome.downloads.download({ url: f.url, filename: f.filename, conflictAction: 'overwrite', saveAs: false });
    const r = await waitDone(id);
    if (!r.ok) throw new Error(f.filename + '：' + r.error);
    paths.push(r.path);
  }
  return { ok: true, paths };
}

// 只問「同一院區」開著的 WebPACS 分頁；第一個查得到的就用它。
// 院區由發問的結果頁網址決定（sender.url），不跨院查。
async function pacsFind(accession, patientId, fromUrl) {
  let host = '';
  try { host = new URL(fromUrl).hostname; } catch (e) { /* 讀不到就當不認得的院區 */ }
  const site = CXRCore.siteByHost(host);
  if (!site) return { ok: false, reason: 'no-site', detail: host };
  const tabs = await chrome.tabs.query({ url: 'https://' + site.pacs + '/*' });
  if (!tabs.length) return { ok: false, reason: 'no-tab', site: site.name };
  let last = { ok: false, reason: 'no-session', site: site.name };
  const rank = { 'no-session': 0, 'not-found': 1, 'patient-mismatch': 2 };
  for (const tab of tabs) {
    let r;
    try { r = await chrome.tabs.sendMessage(tab.id, { type: 'pacs-lookup', accession, patientId }); }
    catch (e) { r = null; } // 那個分頁沒有查詢框架（登入頁），或是外掛安裝前開的
    if (r && r.ok) return Object.assign(r, { tabId: tab.id, site: site.name });
    if (r && (rank[r.reason] || 0) >= (rank[last.reason] || 0)) last = Object.assign(r, { site: site.name });
  }
  return last;
}

async function pacsImage(tabId, uid, kind) {
  try { return (await chrome.tabs.sendMessage(tabId, { type: 'pacs-fetch', uid, kind })) || { ok: false, reason: 'no-session' }; }
  catch (e) { return { ok: false, reason: 'no-session' }; }
}

// 從 WebPACS 的「標註」按鈕來：把這次要標的影像記在記憶體（關瀏覽器就消失），開標註分頁
// （PACS 回顧小視窗的「標註」不經過這裡，直接在小視窗裡開標註畫面）
async function openEditor(job, tab) {
  const id = crypto.randomUUID();
  await chrome.storage.session.set({ ['job:' + id]: { uid: String(job.uid || ''), meta: job.meta || {}, tabId: tab.id } });
  await chrome.tabs.create({ url: chrome.runtime.getURL('editor.html') + '#' + id, index: tab.index + 1, openerTabId: tab.id });
  return { ok: true };
}

// ---------- PACS 回顧：急診清單 → 外掛的回顧分頁 ⇄ 同院區的 WebPACS 分頁 ----------
// 院區：清單送來時看清單頁的網址；回顧分頁之後的請求帶著當時記下的院區代號。
const siteById = (id) => CXRCore.SITES.find((s) => s.id === id) || null;
const siteOfSender = (sender) => { try { return CXRCore.siteByHost(new URL(sender.url || (sender.tab && sender.tab.url) || '').hostname); } catch (e) { return null; } };

// 回顧固定用一個小視窗（0.6.0）：第一次開時建立，之後換病人就把那個視窗換成新的病人。
// follow：清單上點選了別的病人——只在小視窗已經開著時換內容，而且不搶焦點（使用者還在清單上操作）。
async function reviewWindow() {
  const w = (await chrome.storage.session.get('reviewWin')).reviewWin;
  if (!w) return null;
  try { const tab = await chrome.tabs.get(w.tabId); return tab.windowId === w.windowId ? w : null; } catch (e) { return null; }
}
async function openReview(job, sender, follow) {
  const site = siteOfSender(sender);
  if (!site || !sender.tab) return { ok: false, reason: 'no-site' };
  const chart = String(job.chart || '');
  if (!/^\d{4,12}$/.test(chart)) return { ok: false, reason: 'bad-chart' };
  const win = await reviewWindow();
  if (follow && !win) return { ok: true, skipped: true };
  const focus = async (w) => { if (!follow) await chrome.windows.update(w.windowId, { focused: true }).catch(() => {}); };
  if (win && win.chart === chart && win.site === site.id && win.listOut === !!job.listOut) { await focus(win); return { ok: true, same: true } };
  const keep = {};
  for (const k of ['name', 'bed', 'seq', 'since', 'until', 'status']) keep[k] = String(job[k] == null ? '' : job[k]).slice(0, 40);
  // AI 判讀結果頁：只收同一個院內主機上的 AI 平台網址
  let aiurl = '';
  try { const u = new URL(String(job.aiurl || '')); if (u.protocol === 'https:' && u.hostname === site.ai && /^\/web\/aiplatform\//i.test(u.pathname)) aiurl = u.href; } catch (e) { /* 沒有就不顯示 */ }
  const id = crypto.randomUUID();
  await chrome.storage.session.set({ ['review:' + id]: Object.assign(keep, { site: site.id, chart, aiurl, listOut: !!job.listOut }) });
  const url = chrome.runtime.getURL('review.html') + '#' + id;
  const info = { chart, site: site.id, listOut: !!job.listOut, jobId: id };
  if (win) {
    await chrome.tabs.update(win.tabId, { url }); // 只換 # 後面：回顧頁自己決定什麼時候換（標註還沒存時會先等）
    if (win.jobId) await chrome.storage.session.remove('review:' + win.jobId);
    await chrome.storage.session.set({ reviewWin: Object.assign({}, win, info) });
    await focus(win);
  } else {
    const b = (await chrome.storage.local.get('reviewBounds')).reviewBounds || { width: 1000, height: 900 };
    const w = await chrome.windows.create(Object.assign({ url, type: 'popup', focused: true }, b));
    await chrome.storage.session.set({ reviewWin: Object.assign({ windowId: w.id, tabId: w.tabs[0].id }, info) });
  }
  return { ok: true };
}
// 小視窗的位置與大小記起來，下次照樣開
chrome.windows.onBoundsChanged.addListener(async (w) => {
  const r = await reviewWindow();
  if (r && r.windowId === w.id && w.state === 'normal') chrome.storage.local.set({ reviewBounds: { left: w.left, top: w.top, width: w.width, height: w.height } });
});

// 問同院區每一個開著的 WebPACS 分頁，第一個答得出來的就用它（回覆裡帶 tabId，之後的縮圖、原圖都找它）
async function pacsStudies(siteId, chart) {
  const site = siteById(siteId);
  if (!site) return { ok: false, reason: 'no-site' };
  const tabs = await chrome.tabs.query({ url: 'https://' + site.pacs + '/*' });
  if (!tabs.length) return { ok: false, reason: 'no-tab', site: site.name };
  let last = { ok: false, reason: 'no-session', site: site.name };
  for (const tab of tabs) {
    let r;
    try { r = await chrome.tabs.sendMessage(tab.id, { type: 'pacs-studies', chart }); } catch (e) { r = null; }
    if (r && r.ok) return Object.assign(r, { tabId: tab.id, site: site.name });
    if (r && r.reason !== 'no-session') last = Object.assign(r, { site: site.name });
  }
  return last;
}
async function toPacsTab(tabId, message) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!CXRCore.SITES.some((s) => new URL(tab.url).hostname === s.pacs)) return { ok: false, reason: 'no-session' }; // 那個分頁已經不是 WebPACS
    return (await chrome.tabs.sendMessage(tabId, message)) || { ok: false, reason: 'no-session' };
  }
  catch (e) { return { ok: false, reason: 'no-session' }; }
}
async function pacsShow(tabId, chart) {
  const r = await toPacsTab(tabId, { type: 'pacs-show', chart });
  if (r.ok) {
    const tab = await chrome.tabs.update(tabId, { active: true });
    if (tab && tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  }
  return r;
}
async function openPacsLogin(siteId) {
  const site = siteById(siteId);
  if (!site) return { ok: false, reason: 'no-site' };
  await chrome.tabs.create({ url: 'https://' + site.pacs + '/DicomWeb/' });
  return { ok: true };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;
  let job;
  if (msg.type === 'cxr-save') job = save(msg.files || []);
  else if (msg.type === 'pacs-find') job = pacsFind(String(msg.accession || ''), String(msg.patientId || ''), sender.url || (sender.tab && sender.tab.url) || '');
  else if (msg.type === 'pacs-image') job = pacsImage(msg.tabId, String(msg.uid || ''), msg.kind);
  else if (msg.type === 'pacs-open-editor' && sender.tab) job = openEditor(msg.job || {}, sender.tab);
  else if (msg.type === 'review-open') job = openReview(msg.job || {}, sender, false);
  else if (msg.type === 'review-follow') job = openReview(msg.job || {}, sender, true);
  else if (msg.type === 'review-studies') job = pacsStudies(String(msg.site || ''), String(msg.chart || ''));
  else if (msg.type === 'review-thumbs') job = toPacsTab(msg.tabId, { type: 'pacs-thumbs', studyId: String(msg.studyId || '') });
  else if (msg.type === 'review-show') job = pacsShow(msg.tabId, String(msg.chart || ''));
  else if (msg.type === 'review-login') job = openPacsLogin(String(msg.site || ''));
  else return;
  job.then(sendResponse, (e) => sendResponse({ ok: false, reason: 'error', error: String((e && e.message) || e), detail: String((e && e.message) || e) }));
  return true; // 非同步回覆
});
