/* CXR 重新標註：急診清單（ipdNote ER_Main，附院與岡山）的頁面腳本。
 * 滑鼠移到清單上某一位病人，那一列右邊會浮出「🩻 PACS」按鈕；按下去開外掛的「PACS 回顧」分頁，
 * 列出這位病人在同院區 WebPACS 的檢查。
 * 按鈕不放進表格裡（放在頁面最外層、蓋在那一列上），不動清單本身，也不會觸發點選病人。
 * 對院內系統唯讀：只讀清單每一列本來就帶著的資料（td[data-erinfo]），不存清單。 */
(function () {
  'use strict';
  if (window.top !== window || !/^\/WEB\/ipdNote\/ER_Main(?:\/Index)?\/?$/i.test(location.pathname)) return;
  if (window.__cxrReviewLoaded) return;
  window.__cxrReviewLoaded = true;

  const ROW = '#ERPatientListTable tr';
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.id = 'cxr-relabel-pacs-btn';
  btn.textContent = '🩻 PACS';
  btn.title = '在新分頁列出這位病人的 WebPACS 影像（CXR 重新標註外掛）';
  btn.style.cssText = 'position:fixed;z-index:2147483000;display:none;padding:2px 8px;font:12px/1.5 "Microsoft JhengHei",system-ui,sans-serif;' +
    'border:1px solid #0277bd;border-radius:4px;background:#e1f5fe;color:#01579b;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.25);';
  let current = null, hideTimer = 0;

  const infoOf = (row) => { try { return JSON.parse(row.querySelector('td[data-erinfo]').textContent); } catch (e) { return null; } };
  const chartOf = (info) => { const c = String((info && info['病歷號']) || '').trim(); return /^\d{4,12}$/.test(c) ? c : ''; };

  // 清單放在可以捲動的框裡（真頁面：#ControlERPatientListTable，overflow:auto），打開病歷區後只剩半邊寬。
  // 按鈕要放在「框裡看得到的那一段列」的右端，不能用整列的右端（會跑到病歷區上面或框外）。
  function visibleBox(row) {
    const r = row.getBoundingClientRect();
    let left = Math.max(0, r.left), right = Math.min(innerWidth, r.right), top = Math.max(0, r.top), bottom = Math.min(innerHeight, r.bottom);
    for (let e = row.parentElement; e && e !== document.documentElement; e = e.parentElement) {
      const cs = getComputedStyle(e);
      if (cs.overflowX === 'visible' && cs.overflowY === 'visible') continue;
      const b = e.getBoundingClientRect();
      left = Math.max(left, b.left + e.clientLeft); right = Math.min(right, b.left + e.clientLeft + e.clientWidth);
      top = Math.max(top, b.top + e.clientTop); bottom = Math.min(bottom, b.top + e.clientTop + e.clientHeight);
    }
    return { left, right, top, bottom, rowTop: r.top, rowHeight: r.height };
  }
  function place(row) {
    const v = visibleBox(row);
    btn.style.display = 'block';
    const w = btn.offsetWidth, h = btn.offsetHeight;
    // 看得到的部分太小（捲到框外、框太窄）就不顯示
    if (!v.rowHeight || v.bottom - v.top < h * 0.6 || v.right - v.left < w + 12) return hide();
    btn.style.left = Math.round(v.right - w - 6) + 'px';
    btn.style.top = Math.round(Math.min(Math.max(v.rowTop + (v.rowHeight - h) / 2, v.top), v.bottom - h)) + 'px';
  }
  function show(row) {
    clearTimeout(hideTimer);
    if (row !== current) { current = row; }
    place(row);
  }
  function hide() { clearTimeout(hideTimer); btn.style.display = 'none'; current = null; }

  document.addEventListener('mouseover', (e) => {
    const t = e.target instanceof Element ? e.target : null;
    if (!t || t === btn) { clearTimeout(hideTimer); return; }
    const row = t.closest(ROW);
    if (row && row.querySelector('td[data-erinfo]') && chartOf(infoOf(row))) return show(row);
    clearTimeout(hideTimer);
    hideTimer = setTimeout(hide, 250);
  }, true);
  addEventListener('scroll', () => { if (current) place(current); }, true);
  addEventListener('resize', () => { if (current) place(current); });

  // 不讓頁面自己的滑鼠處理（選病人、開病歷）接到這顆按鈕的事件
  for (const t of ['mousedown', 'mouseup', 'dblclick']) btn.addEventListener(t, (e) => e.stopPropagation());
  btn.addEventListener('click', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const row = current;
    const info = row && row.isConnected ? infoOf(row) : null; // 按下去的當下才讀，清單換過也不會拿到上一位
    const chart = chartOf(info);
    if (!chart) { hide(); return alert('讀不到這一列的病歷號，請重新整理清單後再試。'); }
    const outRadio = document.getElementById('ERSTATUSout');
    const job = {
      chart, name: info.PTNAME, bed: info['床號'], seq: info['檢傷序號'], status: info.STATUSNAME,
      since: info.CHECKINTIME, until: info.CHECKOUTTIME, aiurl: info.AIURL || '', listOut: !!(outRadio && outRadio.checked),
    };
    try {
      const r = await chrome.runtime.sendMessage({ type: 'review-open', job });
      if (!r || !r.ok) alert('無法開啟 PACS 回顧分頁' + (r && r.reason ? '（' + r.reason + '）' : '') + '。');
    } catch (err) {
      alert('無法開啟 PACS 回顧分頁：' + String((err && err.message) || err) + '\n（外掛剛更新過的話，請重新整理這一頁）');
    }
  });
  (document.body || document.documentElement).appendChild(btn);
})();
