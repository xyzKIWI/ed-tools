/* CXR 重新標註：共用的標註畫面。
 * AI 平台結果頁（蓋在原分頁上）與外掛自己的分頁（從 WebPACS 開）都用這一份。
 * 只管畫框與存檔流程；影像從哪裡來、要存哪些檔，由呼叫的人決定（opts）。 */
(function (root) {
  'use strict';
  const C = root.CXRCore;

  const TEMPLATE = `
<style>
:host{all:initial}
*{box-sizing:border-box;font-family:"Microsoft JhengHei","PingFang TC",system-ui,sans-serif}
.wrap{position:absolute;inset:0;display:flex;background:#0b1620;color:#e3eef6;font-size:14px}
.stage{flex:1;position:relative;min-width:0;background:#000;overflow:hidden}
canvas{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none}
.tip{position:absolute;left:10px;bottom:8px;right:10px;font-size:12px;color:#b6c8d5;background:rgba(0,0,0,.6);padding:4px 8px;border-radius:4px;pointer-events:none;width:fit-content}
aside{width:310px;flex:none;display:flex;flex-direction:column;gap:12px;padding:14px;overflow-y:auto;border-left:1px solid #1f3547;background:#0f2231}
h1{font-size:17px;margin:0}
h2{font-size:13px;margin:0 0 5px;color:#8fb6cf;font-weight:600}
.meta{font-size:12px;color:#9fb3c2;line-height:1.7;word-break:break-all}
button{font:inherit;color:inherit;cursor:pointer}
.classes{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.cls{display:flex;align-items:center;gap:6px;padding:5px 6px;border:1px solid #2a4860;border-radius:5px;background:#132c3f;text-align:left;line-height:1.2}
.cls.on{border-color:#fff;background:#1d4a69}
.cls.minor{opacity:.8}
.cls i,.item i{width:10px;height:10px;border-radius:2px;flex:none;display:inline-block}
.cls kbd{font:11px Consolas,monospace;color:#8fb6cf}
.cls small{display:block;font-size:10px;color:#8fb6cf}
.list{display:flex;flex-direction:column;gap:4px}
.item{display:flex;align-items:center;gap:6px;padding:4px 6px;border:1px solid #2a4860;border-radius:5px;background:#132c3f;cursor:pointer}
.item.sel{border-color:#fff}
.item.bad{border-color:#ff8a80}
.item select{flex:1;min-width:0;background:#0b1620;color:inherit;border:1px solid #2a4860;border-radius:4px;padding:2px;font:inherit}
.item .src{font-size:11px;color:#8fb6cf;flex:none}
.item .del{border:0;background:none;color:#ff8a80;font-size:15px;padding:0 4px}
.empty{font-size:12px;color:#7d93a3}
label.chk{display:flex;gap:6px;align-items:center;cursor:pointer}
textarea{width:100%;min-height:52px;background:#0b1620;color:inherit;border:1px solid #2a4860;border-radius:5px;padding:5px;font:inherit;resize:vertical}
input[type=text]{width:100%;background:#0b1620;color:inherit;border:1px solid #2a4860;border-radius:5px;padding:5px;font:inherit}
.actions{display:flex;gap:6px;flex-wrap:wrap}
.btn{padding:7px 12px;border:1px solid #2a4860;border-radius:5px;background:#132c3f}
.btn.primary{background:#1976d2;border-color:#1976d2;color:#fff;font-weight:600;flex:1 1 100%}
.status{font-size:12px;line-height:1.5;min-height:18px;word-break:break-all}
.status.err{color:#ff8a80}.status.ok{color:#a5d6a7}
[hidden]{display:none!important}
</style>
<div class="wrap">
  <div class="stage"><canvas></canvas><div class="tip" id="tip"></div></div>
  <aside>
    <h1 id="title">CXR 重新標註</h1>
    <div class="meta" id="meta"></div>
    <div><h2>類別（數字鍵切換；選取框時會改那個框）</h2><div class="classes" id="classes"></div></div>
    <div><h2>框</h2><div class="list" id="list"></div></div>
    <label class="chk"><input type="checkbox" id="nofinding">這張沒有任何病灶</label>
    <label class="chk" id="dicomrow" hidden><input type="checkbox" id="dicom">同時存 DICOM 原檔（檔頭含姓名、病歷號）</label>
    <div><h2>備註（選填）</h2><textarea id="note"></textarea></div>
    <div><h2>存檔資料夾（在瀏覽器的「下載」底下，設一次就會記住）</h2><input type="text" id="dir" spellcheck="false"></div>
    <div class="actions">
      <button class="btn primary" id="save">儲存影像與標註（Ctrl+S）</button>
      <button class="btn" id="reset">還原成模型的框</button>
      <span id="extra" style="display:contents"></span>
      <button class="btn" id="close">關閉（Esc）</button>
    </div>
    <div class="status" id="status"></div>
  </aside>
</div>`;

  let current = null;

  /**
   * opts:
   *   title, metaLines[], intro           畫面上的文字
   *   image, width, height                要標註的影像（canvas 能畫的東西）與它的像素大小；框的座標以它為準
   *   compare                             （選填）按 O 對照用的另一張影像，會拉成同樣大小顯示
   *   boxes, resetBoxes()                 一開始的框；「還原成模型的框」要還原成什麼（沒有就不顯示那顆按鈕）
   *   defaultLabel, storeKey              預設類別；記住上次標註用的鍵
   *   dicomOption                         顯示「同時存 DICOM」勾選
   *   extraButtons[{label,onClick}]       額外按鈕
   *   makeFiles({boxes,noFinding,note,savedAt,wantDicom}) → [{filename,url}]（filename 不含資料夾）
   *   onSaved(savedAtText), onClose()
   */
  async function open(opts) {
    if (current) return current;
    const W = opts.width, H = opts.height;
    let uid = 0;
    const withId = (list) => (list || []).map((b) => ({ id: ++uid, label: b.label || '', source: b.source || 'manual', x1: b.x1, y1: b.y1, x2: b.x2, y2: b.y2 }));
    const st = { boxes: withId(opts.boxes), sel: null, cur: opts.defaultLabel || C.CLASSES[0].name, hide: false, showCompare: false, noFinding: false, note: '', dirty: false, wantDicom: false, dir: C.DEFAULT_DIR };

    let loadedSaved = false;
    try {
      const got = await chrome.storage.local.get([opts.storeKey, 'opt:dicom', 'opt:dir']);
      st.wantDicom = !!got['opt:dicom'];
      st.dir = C.cleanDir(got['opt:dir']) || C.DEFAULT_DIR;
      const s = got[opts.storeKey];
      if (s && Array.isArray(s.boxes)) {
        // 上次可能是在另一種解析度的影像上標的（例如當時拿不到 PACS 原圖），按比例換過來
        const kx = s.w ? W / s.w : 1, ky = s.h ? H / s.h : 1;
        st.boxes = withId(s.boxes.map((b) => C.scaleBox(b, kx, ky)));
        st.noFinding = !!s.noFinding;
        st.note = s.note || '';
        loadedSaved = true;
      }
    } catch (e) { /* 沒有上次紀錄 */ }

    const host = document.createElement('div');
    host.id = 'cxr-relabel-editor';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;';
    const sh = host.attachShadow({ mode: 'open' });
    sh.innerHTML = TEMPLATE;
    document.documentElement.appendChild(host);
    const prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';

    const $ = (s) => sh.querySelector(s);
    const cv = $('canvas'), ctx = cv.getContext('2d'), stage = $('.stage');
    const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
    const classOf = (name) => C.CLASSES.find((c) => c.name === name);
    const colorOf = (name) => (classOf(name) ? classOf(name).color : '#ffffff');
    const status = (msg, kind) => { const s = $('#status'); s.textContent = msg; s.className = 'status' + (kind ? ' ' + kind : ''); };
    const touch = () => { st.dirty = true; };

    if (opts.title) $('#title').textContent = opts.title;
    $('#tip').textContent = '拖曳空白處＝畫新框｜拖框的邊＝移動｜拖角落＝改大小｜滾輪＝縮放｜右鍵拖曳＝平移｜F＝回到全圖｜H＝暫時隱藏框' +
      (opts.compare ? '｜O＝對照結果頁原本的影像' : '') + '｜Delete＝刪除選取的框';
    const meta = $('#meta');
    (opts.metaLines || []).concat('影像大小：' + W + ' × ' + H).forEach((t) => meta.appendChild(el('div', '', t)));

    function renderClasses() {
      const box = $('#classes');
      box.textContent = '';
      C.CLASSES.forEach((c, i) => {
        const b = el('button', 'cls' + (c.main ? '' : ' minor') + (st.cur === c.name ? ' on' : ''));
        b.type = 'button';
        const dot = el('i'); dot.style.background = c.color;
        const txt = el('span'); txt.appendChild(document.createTextNode(c.zh)); txt.appendChild(el('small', '', c.name));
        b.append(el('kbd', '', String((i + 1) % 10)), dot, txt);
        b.addEventListener('click', () => setClass(c.name));
        box.appendChild(b);
      });
    }

    function renderList() {
      const box = $('#list');
      box.textContent = '';
      if (!st.boxes.length) { box.appendChild(el('div', 'empty', '還沒有框。在影像上拖曳就能畫一個。')); return; }
      st.boxes.forEach((b) => {
        const known = !!classOf(b.label);
        const row = el('div', 'item' + (st.sel === b.id ? ' sel' : '') + (known ? '' : ' bad'));
        const dot = el('i'); dot.style.background = colorOf(b.label);
        const sel = el('select');
        if (!known) { const o = el('option', '', '？請選類別'); o.value = ''; sel.appendChild(o); }
        C.CLASSES.forEach((c) => { const o = el('option', '', c.zh + ' ' + c.name); o.value = c.name; sel.appendChild(o); });
        sel.value = known ? b.label : '';
        sel.addEventListener('change', () => { b.label = sel.value; touch(); renderList(); draw(); });
        sel.addEventListener('click', (e) => e.stopPropagation());
        const del = el('button', 'del', '✕'); del.type = 'button'; del.title = '刪除這個框';
        del.addEventListener('click', (e) => { e.stopPropagation(); removeBox(b.id); });
        row.append(dot, sel, el('span', 'src', b.source === 'model' ? '模型' : '手動'), del);
        row.addEventListener('click', () => { st.sel = b.id; renderList(); draw(); });
        box.appendChild(row);
      });
    }

    function setClass(name) {
      st.cur = name;
      const b = st.boxes.find((x) => x.id === st.sel);
      if (b && b.label !== name) { b.label = name; touch(); }
      renderClasses(); renderList(); draw();
    }
    function removeBox(id) {
      st.boxes = st.boxes.filter((x) => x.id !== id);
      if (st.sel === id) st.sel = null;
      touch(); renderList(); draw();
    }

    // ----- 畫布 -----
    const v = { s: 1, tx: 0, ty: 0, fitS: 1 };
    let cw = 1, ch = 1;
    function fit() {
      v.fitS = Math.min(cw / W, ch / H) * 0.97;
      v.s = v.fitS;
      v.tx = (cw - W * v.s) / 2;
      v.ty = (ch - H * v.s) / 2;
    }
    function resize() {
      const r = stage.getBoundingClientRect();
      cw = Math.max(1, r.width); ch = Math.max(1, r.height);
      const dpr = window.devicePixelRatio || 1;
      cv.width = Math.round(cw * dpr); cv.height = Math.round(ch * dpr);
      fit(); draw();
    }
    const sx = (x) => x * v.s + v.tx, sy = (y) => y * v.s + v.ty;
    let drag = null;

    function draw() {
      const dpr = window.devicePixelRatio || 1;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, cw, ch);
      ctx.imageSmoothingEnabled = v.s < 3;
      ctx.drawImage(st.showCompare && opts.compare ? opts.compare : opts.image, v.tx, v.ty, W * v.s, H * v.s);
      if (!st.hide) {
        ctx.font = '12px "Microsoft JhengHei",sans-serif';
        ctx.textBaseline = 'bottom';
        for (const b of st.boxes) {
          const known = !!classOf(b.label), selected = st.sel === b.id, col = colorOf(b.label);
          const x = sx(Math.min(b.x1, b.x2)), y = sy(Math.min(b.y1, b.y2));
          const w = Math.abs(b.x2 - b.x1) * v.s, h = Math.abs(b.y2 - b.y1) * v.s;
          ctx.setLineDash(known ? [] : [6, 4]);
          ctx.lineWidth = selected ? 3 : 2;
          ctx.strokeStyle = col;
          ctx.strokeRect(x, y, w, h);
          ctx.setLineDash([]);
          const tag = known ? b.label : '？未選類別';
          const tw = ctx.measureText(tag).width + 8;
          const ty = y >= 16 ? y : y + h + 16;
          ctx.fillStyle = col;
          ctx.fillRect(x - 1, ty - 16, tw, 16);
          ctx.fillStyle = '#000';
          ctx.fillText(tag, x + 3, ty - 1);
          if (selected) {
            ctx.fillStyle = '#fff';
            for (const [hx, hy] of [[x, y], [x + w, y], [x, y + h], [x + w, y + h]]) ctx.fillRect(hx - 4, hy - 4, 8, 8);
          }
        }
      }
      if (drag && drag.mode === 'draw') {
        ctx.setLineDash([5, 4]);
        ctx.lineWidth = 2;
        ctx.strokeStyle = colorOf(st.cur);
        ctx.strokeRect(sx(Math.min(drag.x1, drag.x2)), sy(Math.min(drag.y1, drag.y2)), Math.abs(drag.x2 - drag.x1) * v.s, Math.abs(drag.y2 - drag.y1) * v.s);
        ctx.setLineDash([]);
      }
    }

    const clampX = (x) => Math.min(W, Math.max(0, x)), clampY = (y) => Math.min(H, Math.max(0, y));
    const toImg = (e) => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left - v.tx) / v.s, y: (e.clientY - r.top - v.ty) / v.s }; };

    function hit(p) {
      if (st.hide) return null;
      const tol = 7 / v.s;
      const order = st.boxes.slice().reverse().sort((a, b) => (b.id === st.sel) - (a.id === st.sel));
      for (const b of order)
        for (const xk of ['x1', 'x2'])
          for (const yk of ['y1', 'y2'])
            if (Math.abs(p.x - b[xk]) <= tol && Math.abs(p.y - b[yk]) <= tol) return { type: 'corner', box: b, xk, yk };
      for (const b of order) {
        const outer = p.x >= b.x1 - tol && p.x <= b.x2 + tol && p.y >= b.y1 - tol && p.y <= b.y2 + tol;
        const inner = p.x > b.x1 + tol && p.x < b.x2 - tol && p.y > b.y1 + tol && p.y < b.y2 - tol;
        if (outer && !inner) return { type: 'edge', box: b };
      }
      return null;
    }

    let spaceDown = false;
    cv.addEventListener('contextmenu', (e) => e.preventDefault());
    cv.addEventListener('pointerdown', (e) => {
      cv.setPointerCapture(e.pointerId);
      if (e.button === 1 || e.button === 2 || (e.button === 0 && spaceDown)) {
        e.preventDefault();
        drag = { mode: 'pan', cx: e.clientX, cy: e.clientY, tx: v.tx, ty: v.ty };
        return;
      }
      if (e.button !== 0) return;
      const p = toImg(e), h = hit(p);
      if (h && h.type === 'corner') { st.sel = h.box.id; drag = { mode: 'resize', box: h.box, xk: h.xk, yk: h.yk }; }
      else if (h) { st.sel = h.box.id; drag = { mode: 'move', box: h.box, px: p.x, py: p.y, o: Object.assign({}, h.box) }; }
      else { st.sel = null; drag = { mode: 'draw', x1: clampX(p.x), y1: clampY(p.y), x2: clampX(p.x), y2: clampY(p.y) }; }
      renderList(); draw();
    });
    cv.addEventListener('pointermove', (e) => {
      const p = toImg(e);
      if (!drag) {
        const h = hit(p);
        cv.style.cursor = !h ? 'crosshair' : h.type === 'edge' ? 'move' : (h.xk === 'x1') === (h.yk === 'y1') ? 'nwse-resize' : 'nesw-resize';
        return;
      }
      if (drag.mode === 'pan') { v.tx = drag.tx + e.clientX - drag.cx; v.ty = drag.ty + e.clientY - drag.cy; }
      else if (drag.mode === 'draw') { drag.x2 = clampX(p.x); drag.y2 = clampY(p.y); }
      else if (drag.mode === 'resize') { drag.box[drag.xk] = clampX(p.x); drag.box[drag.yk] = clampY(p.y); touch(); }
      else if (drag.mode === 'move') {
        const o = drag.o;
        const dx = Math.min(W - o.x2, Math.max(-o.x1, p.x - drag.px)), dy = Math.min(H - o.y2, Math.max(-o.y1, p.y - drag.py));
        Object.assign(drag.box, { x1: o.x1 + dx, x2: o.x2 + dx, y1: o.y1 + dy, y2: o.y2 + dy });
        touch();
      }
      draw();
    });
    const endDrag = () => {
      if (!drag) return;
      const d = drag;
      drag = null;
      if (d.mode === 'draw') {
        const nb = C.normBox(d, W, H);
        const min = Math.max(4, Math.min(W, H) / 300); // 太小的當成誤觸
        if (nb.x2 - nb.x1 >= min && nb.y2 - nb.y1 >= min) {
          const b = Object.assign({ id: ++uid, label: st.cur, source: 'manual' }, nb);
          st.boxes.push(b); st.sel = b.id; touch();
        }
      } else if (d.mode === 'resize') {
        Object.assign(d.box, C.normBox(d.box, W, H));
      }
      renderList(); draw();
    };
    cv.addEventListener('pointerup', endDrag);
    cv.addEventListener('pointercancel', endDrag);
    cv.addEventListener('dblclick', () => { fit(); draw(); });
    cv.addEventListener('wheel', (e) => {
      e.preventDefault();
      const r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top;
      const ns = Math.min(12, Math.max(v.fitS * 0.5, v.s * Math.exp(-e.deltaY * 0.0015)));
      v.tx = mx - ((mx - v.tx) / v.s) * ns;
      v.ty = my - ((my - v.ty) / v.s) * ns;
      v.s = ns;
      draw();
    }, { passive: false });

    // ----- 鍵盤 -----
    const onKeyDown = (e) => {
      const t = e.composedPath()[0];
      const typing = t && (t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || (t.tagName === 'INPUT' && t.type === 'text'));
      const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      let used = true;
      if ((e.ctrlKey || e.metaKey) && k === 's') save();
      else if (e.key === 'Escape') close();
      else if (typing || e.ctrlKey || e.metaKey || e.altKey) used = false;
      else if (k === ' ') spaceDown = true;
      else if (/^[0-9]$/.test(k)) { const c = C.CLASSES[k === '0' ? 9 : Number(k) - 1]; if (c) setClass(c.name); }
      else if (e.key === 'Delete' || e.key === 'Backspace') { if (st.sel != null) removeBox(st.sel); }
      else if (k === 'h') { st.hide = !st.hide; draw(); }
      else if (k === 'o' && opts.compare) { st.showCompare = !st.showCompare; draw(); status(st.showCompare ? '現在顯示的是結果頁原本的影像（有模型的框）。再按 O 切回來。' : '已切回要存檔的影像。'); }
      else if (k === 'f') { fit(); draw(); }
      else used = false;
      e.stopPropagation(); // 標註畫面開著時，按鍵不交給底下的頁面
      if (used) e.preventDefault();
    };
    const onKeyUp = (e) => { if (e.key === ' ') spaceDown = false; e.stopPropagation(); };
    window.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('keyup', onKeyUp, true);

    // ----- 儲存 -----
    const pad = (n) => String(n).padStart(2, '0');
    let saving = false;
    async function save() {
      if (saving) return;
      const bad = st.boxes.filter((b) => !classOf(b.label));
      if (bad.length) { st.sel = bad[0].id; renderList(); draw(); return status('有 ' + bad.length + ' 個框還沒選類別。', 'err'); }
      if (!st.boxes.length && !st.noFinding) return status('目前沒有任何框。如果這張確實沒有病灶，請勾選「這張沒有任何病灶」再儲存。', 'err');
      if (st.boxes.length && st.noFinding) return status('已勾選「這張沒有任何病灶」，但畫面上還有框，請擇一。', 'err');
      if (!applyDir()) return;
      saving = true;
      status('儲存中…');
      try {
        const d = new Date();
        const off = -d.getTimezoneOffset();
        const savedAt = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) +
          (off >= 0 ? '+' : '-') + pad(Math.floor(Math.abs(off) / 60)) + ':' + pad(Math.abs(off) % 60);
        const plain = st.boxes.map((b) => ({ label: b.label, source: b.source, x1: b.x1, y1: b.y1, x2: b.x2, y2: b.y2 }));
        const made = await opts.makeFiles({ boxes: plain, noFinding: st.noFinding, note: st.note, savedAt, wantDicom: !!opts.dicomOption && st.wantDicom });
        const files = made.map((f) => ({ filename: st.dir + '/' + f.filename, url: f.url }));
        const res = await chrome.runtime.sendMessage({ type: 'cxr-save', files });
        if (!res || !res.ok) throw new Error((res && res.error) || '背景程式沒有回應');
        const savedAtText = pad(d.getMonth() + 1) + '/' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
        st.dirty = false;
        try {
          await chrome.storage.local.set({ [opts.storeKey]: { boxes: plain, w: W, h: H, noFinding: st.noFinding, note: st.note, savedAtText } });
        } catch (e) { /* 記不住上次標註不影響已存的檔 */ }
        if (opts.onSaved) opts.onSaved(savedAtText);
        const first = (res.paths && res.paths[0]) || '';
        status('已儲存 ' + files.length + ' 個檔（' + st.boxes.length + ' 個框）：' + first.replace(/[\\/][^\\/]*$/, ''), 'ok');
      } catch (e) {
        const msg = String((e && e.message) || e);
        status('儲存失敗：' + msg + (/context invalidated/i.test(msg) ? '（外掛剛更新過，請重新整理這一頁再試）' : ''), 'err');
      } finally {
        saving = false;
      }
    }

    const ro = new ResizeObserver(resize);
    function close(force) {
      if (!force && st.dirty && !confirm('標註還沒儲存，確定要關閉嗎？')) return false;
      window.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('keyup', onKeyUp, true);
      ro.disconnect();
      host.remove();
      document.documentElement.style.overflow = prevOverflow;
      current = null;
      if (opts.onClose) opts.onClose();
      return true;
    }
    const api = { close, status, isDirty: () => st.dirty };

    $('#save').addEventListener('click', save);
    $('#close').addEventListener('click', () => close(false));
    const resetBtn = $('#reset');
    if (opts.resetBoxes) resetBtn.addEventListener('click', () => { st.boxes = withId(opts.resetBoxes()); st.sel = null; touch(); renderList(); draw(); status('已還原成模型的 ' + st.boxes.length + ' 個框。'); });
    else resetBtn.hidden = true;
    (opts.extraButtons || []).forEach((x) => { const b = el('button', 'btn', x.label); b.type = 'button'; b.addEventListener('click', () => x.onClick(api)); $('#extra').appendChild(b); });
    const nf = $('#nofinding');
    nf.checked = st.noFinding;
    nf.addEventListener('change', () => { st.noFinding = nf.checked; touch(); });
    if (opts.dicomOption) {
      $('#dicomrow').hidden = false;
      const dc = $('#dicom');
      dc.checked = st.wantDicom;
      dc.addEventListener('change', () => { st.wantDicom = dc.checked; chrome.storage.local.set({ 'opt:dicom': st.wantDicom }).catch(() => {}); });
    }
    const note = $('#note');
    note.value = st.note;
    note.addEventListener('input', () => { st.note = note.value; touch(); });
    // 存檔資料夾：填的是「下載」底下的相對路徑；合法才採用並記住，不合法就說明、不存檔
    const dirInput = $('#dir');
    dirInput.value = st.dir;
    function applyDir() {
      const clean = C.cleanDir(dirInput.value);
      if (!clean) {
        status('存檔資料夾的寫法不能用。請填「下載」底下的資料夾名稱，例如 CXR_relabel 或 CXR_relabel/2026-11（不能有磁碟代號、..，或 < > : " | ? * 這些字元）。', 'err');
        return false;
      }
      if (clean !== st.dir) { st.dir = clean; chrome.storage.local.set({ 'opt:dir': clean }).catch(() => {}); }
      dirInput.value = clean;
      return true;
    }
    dirInput.addEventListener('change', () => { if (applyDir()) status('之後都會存到「下載\\' + st.dir.replace(/\//g, '\\') + '」。'); });

    renderClasses();
    renderList();
    ro.observe(stage);
    resize();
    status((loadedSaved ? '已載入上次存檔的標註，可以接著改。' : '') + (opts.intro || ''));
    current = api;
    return api;
  }

  root.CXREditor = { open };
})(globalThis);
