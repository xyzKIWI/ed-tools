/* CXR 重新標註：在 WebPACS 查詢框架「頁面自己的環境」裡跑的一小段（manifest 的 world: MAIN）。
 * 為什麼需要：登入後的通行碼（AccKey）只放在查詢框架的程式變數裡，頁面要到使用者按「查詢」時才把它
 * 填進查詢表單；外掛的頁面腳本（pacs.js）在隔離環境裡讀不到這個變數。所以 pacs.js 要用之前發一個
 * 事件，這裡做頁面按「查詢」時本來就會做的那一步：把通行碼填進查詢表單的隱藏欄位。
 * 不存、不外傳、不改其他東西。 */
(function () {
  'use strict';
  if (window.name !== 'Queryfrm') return;
  document.addEventListener('cxr-relabel-acckey', function () {
    try {
      var form = document.getElementById('QueryPatient');
      var key = window.AccKey;
      if (form && form.AccKey && typeof key === 'string' && key) form.AccKey.value = key;
    } catch (e) { /* 讀不到就照舊，pacs.js 會說「沒登入」 */ }
  });
})();
