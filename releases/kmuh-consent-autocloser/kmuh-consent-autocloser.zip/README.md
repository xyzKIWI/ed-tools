# KMUH 數位簽名同意書系統自動關閉小工具 (kmuh-consent-autocloser)

專為 **高雄醫學大學醫療體系 (KMUH / KMUGH)** 看診與急診 HIS 系統設計之背景常駐自動化小工具。

---

## 核心設計邏輯

1. **嚴格保留醫師作業時間**：
   - 當開啟 `ConsentForm.exe` 時，監控進入待命狀態，**絕不提前關閉**。
   - 完整保留醫師勾選同意書、插入醫事人員卡執行「完成卡簽」、或開立其他診斷書的時間。
2. **網頁觸發 1 分鐘倒數**：
   - 唯有在【偵測到同意書簽名網頁開啟】（透過偵測 `svs.kmugh.org.tw` / `10.122.120.6` 活躍連線，或視窗標題包含 `SelfieSign` / `signDoc`）時，才正式啟動 **60 秒（1 分鐘）關閉倒數**。
3. **多份同意書連續開立展延**：
   - 倒數 1 分鐘期間，若醫師再次送出並開啟新同意書分頁，系統自動偵測並**重設倒數為 60 秒**，確保連續作業不受中斷。
4. **優雅退出與強制防呆**：
   - 1 分鐘倒數完畢後，優先發送標準 Windows 視窗關閉指令 (`WM_CLOSE` / `CloseMainWindow`)。
   - 若 5 秒內未能正常退出（如背景卡死），自動升級強制關閉 (`Stop-Process -Force`)。
5. **充裕之無網頁保底**：
   - 預設 300 秒（5 分鐘）保底，若醫師開啟系統後完全未開啟簽名網頁亦未關閉，達到保底時間後才自動關閉（可在 `config.json` 自訂秒數或設為 0 關閉）。
6. **防毒相容與純原生背景架構**：
   - 徹底移除舊版 `.vbs` (VBScript) 啟動機制，避免觸發卡巴斯基企業防毒 (Kaspersky Endpoint Security, KES) 自適應異常控制之「從 VBScript 指令碼啟動 PowerShell」規則。
   - 主常駐程序採用 C# 原生編譯 Windows GUI 子系統 (`/target:winexe`) 之 `ConsentFormAutoCloser.exe`，100% 無黑框、無跳窗，記憶體僅佔用約 3~14MB。

---

## 核心架構流程圖 (簡易橫向長條版)

```mermaid
flowchart LR
    A["背景待命"] --> B["同意書程式開啟"]
    B --> C["醫師勾選／卡簽<br/>等待簽名網頁"]
    C --> D["簽名網頁開啟<br/>倒數 1 分鐘"]
    D --> E["關閉同意書程式<br/>逾時則強制終止"]
    E --> F["回到待命"]
```

> **補充**：倒數期間偵測到新同意書，重設為 1 分鐘；若一直未開啟簽名網頁，達 5 分鐘保底時間後亦自動關閉。

---

## 交付檔案目錄結構

```text
C:\Users\User\.gemini\antigravity\scratch\ConsentFormAutoCloser\
├── ConsentFormAutoCloser.exe       # 原生 Windows GUI 背景常駐監控程式 (100% 無黑框、無防毒警報)
├── ConsentFormAutoCloser.cs        # C# 原生原始碼 (可透過 .NET csc.exe 隨時重新編譯)
├── ConsentFormAutoCloser.ps1       # PowerShell 核心腳本 (供測試與前景互動調試使用)
├── config.json                     # 參數設定檔 (倒數秒數、保底時間、目標 IP/主機)
├── closer.log                      # 執行日誌 (自動循環滾動，上限 2MB)
│
├── Start-Background.bat            # 一鍵背景啟動腳本 (呼叫原生 .exe，無 VBScript)
├── Run-Interactive.bat             # 前景互動測試模式 (即時顯示色彩化倒數與事件)
├── Check-Status.bat                # 檢查監控狀態、ConsentForm 狀態、連線與最新日誌
├── Stop-Service.bat                # 一鍵停止背景監控程序
├── View-Log.bat                    # 日誌檢視器 (支援 Live Stream 即時追蹤與記事本)
│
├── Enable-AutoStart.bat            # 一鍵啟用開機自動啟動 (加入 Windows 啟動資料夾)
├── Disable-AutoStart.bat           # 一鍵關閉開機自動啟動
│
├── Test-ConsentFormCloser.ps1      # 完整自動化測試套件 (含 13 項單元、原生 WinExe 與端到端測試)
├── Run-MockTest.bat                # 一鍵執行自動化測試
├── Create-DesktopShortcuts.ps1     # 建立桌面捷徑腳本 (直接指向 ConsentFormAutoCloser.exe)
└── Install-DesktopShortcuts.bat    # 一鍵安裝桌面捷徑
```

---

## 桌面捷徑一覽

執行 `Install-DesktopShortcuts.bat` 後，會在醫師桌面建立以下三個便捷捷徑：
- `【啟動】同意書自動關閉.lnk`：背景靜默啟動原生監控 (`ConsentFormAutoCloser.exe`)，無黑框、無彈窗。
- `【狀態】同意書自動關閉.lnk`：快速檢查運作狀態與最後 15 筆日誌。
- `【停止】同意書自動關閉.lnk`：停止背景監控。

---

## 參數設定說明 (`config.json`)

```json
{
  "WebDelaySeconds": 60,             // 偵測到網頁開啟後的關閉倒數秒數 (預設 60 秒 / 1分鐘)
  "FallbackTimeoutSeconds": 300,     // 無網頁開啟之保底超時秒數 (預設 300 秒 / 5分鐘；設 0 關閉)
  "TargetHost": "svs.kmugh.org.tw",  // SelfieSign 伺服器網址
  "TargetIp": "10.122.120.6",        // SelfieSign 伺服器遠端 IP
  "ProcessName": "ConsentForm",      // 數位簽名同意書執行檔處理序名稱
  "CheckIntervalMilliseconds": 1000, // 輪詢偵測間隔毫秒數 (CPU 耗用 < 0.1%)
  "GracefulWaitSeconds": 5,          // 優雅關閉視窗等待秒數
  "LogFile": "closer.log",           // 日誌檔案路徑
  "MaxLogSizeBytes": 2097152         // 日誌檔上限 (預設 2MB，超過自動建立 .bak 循環)
}
```

---

## 原生編譯指令說明

若需重新編譯 `ConsentFormAutoCloser.exe`，可直接在 PowerShell 執行：
```powershell
& "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /target:winexe /optimize+ /out:"ConsentFormAutoCloser.exe" "ConsentFormAutoCloser.cs"
```
編譯後為標準 Windows GUI 子系統 (`subsystem: 2`)，雙擊啟動完全不會產生控制台黑框。
