(() => {
  // src/monitor-core.mjs
  var SETTINGS_VERSION = 2;
  var OBSERVATION2_NUMBERS = Object.freeze([33, 34, 35, 36, 37, 38]);
  var DEFAULT_SETTINGS = Object.freeze({
    settingsVersion: SETTINGS_VERSION,
    // Known base: M01-10 (10), P15-16 (2), T19-22 (4), O23-32 (10).
    // C/R and available corridor capacity must be included by the operator.
    capacity: 26,
    observation2Open: false,
    threshold: 4,
    pollSeconds: 60,
    notificationsEnabled: true,
    repeatMinutes: 15,
    excludedBedNumbers: Object.freeze([]),
    capacityConfirmed: false,
    paused: false
  });
  function integerInRange(value, minimum, maximum) {
    if (typeof value !== "number" && typeof value !== "string") return null;
    if (typeof value === "string" && value.trim() === "") return null;
    const number = Number(value);
    return Number.isInteger(number) && number >= minimum && number <= maximum ? number : null;
  }
  function normalizeSettings(input = {}) {
    const source = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    const capacity = integerInRange(source.capacity, 1, 1e3);
    const threshold = integerInRange(source.threshold, 1, 1e3);
    const excludedInput = Array.isArray(source.excludedBedNumbers) ? source.excludedBedNumbers : [];
    const excludedNumbers = excludedInput.map((value) => integerInRange(value, 1, 38));
    const invalidCalculationSetting = source.capacity !== void 0 && capacity === null || source.threshold !== void 0 && threshold === null || source.excludedBedNumbers !== void 0 && !Array.isArray(source.excludedBedNumbers) || excludedNumbers.some((value) => value === null) || source.observation2Open !== void 0 && typeof source.observation2Open !== "boolean";
    return {
      settingsVersion: SETTINGS_VERSION,
      capacity: capacity ?? DEFAULT_SETTINGS.capacity,
      observation2Open: source.observation2Open === true,
      threshold: threshold ?? DEFAULT_SETTINGS.threshold,
      pollSeconds: integerInRange(source.pollSeconds, 30, 3600) ?? DEFAULT_SETTINGS.pollSeconds,
      notificationsEnabled: typeof source.notificationsEnabled === "boolean" ? source.notificationsEnabled : DEFAULT_SETTINGS.notificationsEnabled,
      repeatMinutes: integerInRange(source.repeatMinutes, 0, 1440) ?? DEFAULT_SETTINGS.repeatMinutes,
      excludedBedNumbers: [...new Set(excludedNumbers.filter((value) => value !== null))].sort((a, b) => a - b),
      capacityConfirmed: source.capacityConfirmed === true && !invalidCalculationSetting,
      paused: source.paused === true
    };
  }
  var COUNT_FIELDS = [
    "inputRows",
    "identifiedPatients",
    "stretcherPatients",
    "standardPatients",
    "cPatients",
    "rPatients",
    "corridorPatients",
    "isolationPatients",
    "nonStretcherPatients",
    "unknownPositionPatients",
    "occupiedPhysicalBeds"
  ];
  var QUALITY_COUNT_FIELDS = [
    "invalidRecordRows",
    "missingEncounterRows",
    "duplicateEncounterRows",
    "conflictingEncounters",
    "duplicatePhysicalBeds"
  ];
  var isCount = (value) => Number.isSafeInteger(value) && value >= 0;
  function validSummaryShape(summary) {
    if (!summary || typeof summary !== "object" || Array.isArray(summary)) return false;
    if (!COUNT_FIELDS.every((key) => isCount(summary[key]))) return false;
    const quality = summary.quality;
    if (!quality || !QUALITY_COUNT_FIELDS.every((key) => isCount(quality[key])) || typeof quality.classifiedCountReliable !== "boolean" || typeof quality.bedOccupancyReliable !== "boolean") return false;
    const byNumber = summary.standardPatientsByNumber;
    if (!byNumber || typeof byNumber !== "object" || Array.isArray(byNumber)) return false;
    const entries = Object.entries(byNumber);
    if (!entries.every(([key, count]) => /^(?:[1-9]|[12]\d|3[0-8])$/.test(key) && isCount(count))) return false;
    if (entries.reduce((total, [, count]) => total + count, 0) !== summary.standardPatients) {
      return false;
    }
    if (summary.standardPatients + summary.cPatients + summary.rPatients + summary.corridorPatients + summary.isolationPatients !== summary.stretcherPatients) return false;
    if (summary.stretcherPatients + summary.nonStretcherPatients + summary.unknownPositionPatients + quality.conflictingEncounters !== summary.identifiedPatients) return false;
    return summary.occupiedPhysicalBeds <= summary.stretcherPatients;
  }
  function assessSnapshot(summary, inputSettings = {}, context = {}) {
    const settings = normalizeSettings(inputSettings);
    const source = context && typeof context === "object" ? context : {};
    const reasons = [];
    const shapeValid = validSummaryShape(summary);
    const observation2Patients = shapeValid ? OBSERVATION2_NUMBERS.reduce((total, number) => total + (summary.standardPatientsByNumber[number] ?? 0), 0) : null;
    const pediatricSmallBedPatients = shapeValid ? summary.standardPatientsByNumber[17] ?? 0 : null;
    const observation2Capacity = settings.observation2Open ? OBSERVATION2_NUMBERS.filter((number) => !settings.excludedBedNumbers.includes(number)).length : 0;
    const capacity = settings.capacity + observation2Capacity;
    if (!summary) reasons.push("missing_summary");
    else if (!shapeValid) reasons.push("invalid_summary");
    if (source.fresh !== true) reasons.push("stale");
    if (source.scopeValid !== true) reasons.push("scope_invalid");
    if (source.parseErrors !== void 0 && (!isCount(source.parseErrors) || source.parseErrors !== 0)) reasons.push("parse_errors");
    if (source.loggedIn === false) reasons.push("login_required");
    if (source.complete === false) reasons.push("incomplete");
    if (shapeValid) {
      const quality = summary.quality;
      if (quality.invalidRecordRows > 0) reasons.push("invalid_records");
      if (quality.missingEncounterRows > 0) reasons.push("missing_identifiers");
      if (quality.conflictingEncounters > 0) reasons.push("encounter_conflicts");
      if (quality.duplicatePhysicalBeds > 0) reasons.push("duplicate_beds");
      if (summary.unknownPositionPatients > 0) reasons.push("unknown_positions");
      if (!settings.observation2Open && observation2Patients > 0) {
        reasons.push("observation2_closed_occupied");
      }
      if ((!quality.classifiedCountReliable || !quality.bedOccupancyReliable) && reasons.length === 0) {
        reasons.push("invalid_summary");
      }
    }
    const dataValid = reasons.length === 0;
    const excludedNumbers = [.../* @__PURE__ */ new Set([17, ...settings.excludedBedNumbers])];
    const excludedPatients = shapeValid ? summary.isolationPatients + excludedNumbers.reduce((total, number) => total + (summary.standardPatientsByNumber[number] ?? 0), 0) : null;
    const includedPatients = shapeValid ? summary.stretcherPatients - excludedPatients : null;
    const estimatedFreeBeds = dataValid ? capacity - includedPatients : null;
    const thresholdReached = dataValid && estimatedFreeBeds < settings.threshold;
    if (!settings.capacityConfirmed) reasons.push("unconfirmed_capacity");
    if (settings.paused) reasons.push("paused");
    const state = settings.paused ? "paused" : !dataValid ? "invalid" : !settings.capacityConfirmed ? "trial" : thresholdReached ? "threshold" : "normal";
    return {
      state,
      dataValid,
      capacityConfirmed: settings.capacityConfirmed,
      thresholdReached,
      shouldNotify: dataValid && settings.capacityConfirmed && !settings.paused && settings.notificationsEnabled && thresholdReached,
      totalStretcherPatients: shapeValid ? summary.stretcherPatients : null,
      excludedPatients,
      includedPatients,
      estimatedFreeBeds,
      capacity,
      baseCapacity: settings.capacity,
      observation2Capacity,
      observation2Patients,
      pediatricSmallBedPatients,
      isolationPatients: shapeValid ? summary.isolationPatients : null,
      threshold: settings.threshold,
      reasons
    };
  }

  // src/list-parser.mjs
  var SOURCE_URL = "https://intraweb.kmugh.org.tw/WEB/ipdNote/ER_Main";
  var LIST_URL = SOURCE_URL + "/ER_PatientListIN";
  var SOURCE_PATTERN = SOURCE_URL + "*";
  function isSourceUrl(value) {
    try {
      const url = new URL(value);
      return url.origin === "https://intraweb.kmugh.org.tw" && url.pathname.replace(/\/$/, "").toLowerCase() === "/web/ipdnote/er_main";
    } catch {
      return false;
    }
  }

  // src/monitor-controller.mjs
  var ALARM_NAME = "ed-monitor-poll";
  var EXPIRY_ALARM_NAME = "ed-monitor-expiry";
  var ERROR_MESSAGES = {
    login_required: "病摘登入已失效，請在來源分頁重新登入。",
    no_tab: "請開啟並登入急診病摘分頁。",
    refresh_required: "請重新整理病摘分頁，啟用監控連線。",
    source_not_ready: "病摘清單尚未就緒，請確認來源分頁。",
    network_error: "查詢失敗，保留上次結果並暫停門檻判定。",
    invalid_response: "清單格式無法辨識，已暫停門檻判定。",
    incomplete_response: "清單資料不完整，已暫停門檻判定。",
    empty_unverified: "收到空清單，尚未確認此格式；不作空床判定。",
    invalid: "資料有待核對項目，已暫停門檻判定。",
    stale: "資料已過期，請重新查詢。",
    paused: "監控已暫停。"
  };
  var countFields = [
    "inputRows",
    "identifiedPatients",
    "stretcherPatients",
    "standardPatients",
    "cPatients",
    "rPatients",
    "corridorPatients",
    "isolationPatients",
    "nonStretcherPatients",
    "unknownPositionPatients",
    "occupiedPhysicalBeds"
  ];
  var qualityCounts = [
    "invalidRecordRows",
    "missingEncounterRows",
    "duplicateEncounterRows",
    "conflictingEncounters",
    "duplicatePhysicalBeds"
  ];
  var isCount2 = (value) => Number.isSafeInteger(value) && value >= 0;
  function sanitizeSummary(value) {
    if (!value || !countFields.every((key) => isCount2(value[key])) || !value.quality || !qualityCounts.every((key) => isCount2(value.quality[key]))) return null;
    const safe = Object.fromEntries(countFields.map((key) => [key, value[key]]));
    safe.quality = Object.fromEntries(qualityCounts.map((key) => [key, value.quality[key]]));
    for (const key of ["classifiedCountReliable", "bedOccupancyReliable"]) {
      if (typeof value.quality[key] !== "boolean") return null;
      safe.quality[key] = value.quality[key];
    }
    safe.standardPatientsByNumber = {};
    for (let number = 1; number <= 38; number++) {
      const count = value.standardPatientsByNumber?.[number];
      if (count !== void 0) {
        if (!isCount2(count)) return null;
        safe.standardPatientsByNumber[number] = count;
      }
    }
    safe.byZone = {};
    for (const zone of ["standard", "resuscitation_area", "resuscitation_room", "corridor_observation", "isolation", "non_bedded", "unknown"]) {
      const count = value.byZone?.[zone];
      if (isCount2(count)) safe.byZone[zone] = count;
    }
    safe.byStatus = {};
    for (const status of ["在院中", "在院", "發落", "other"]) {
      const item = value.byStatus?.[status];
      if (item && isCount2(item.patients) && isCount2(item.stretcherPatients)) {
        safe.byStatus[status] = { patients: item.patients, stretcherPatients: item.stretcherPatients };
      }
    }
    return safe;
  }
  function safeSnapshot(value) {
    const summary = sanitizeSummary(value?.summary);
    const timestamp = Date.parse(value?.observedAt);
    if (!summary || !Number.isFinite(timestamp) || !isCount2(value?.parseErrors)) return null;
    return {
      summary,
      observedAt: new Date(timestamp).toISOString(),
      parseErrors: value.parseErrors,
      scopeValid: value.scopeValid === true,
      complete: value.complete === true,
      sourceTabId: Number.isInteger(value.sourceTabId) ? value.sourceTabId : null
    };
  }
  function createMonitorController(api, options = {}) {
    const now = options.now || (() => Date.now());
    let inFlight = null;
    let state = {
      settings: normalizeSettings(),
      lastSnapshot: null,
      connection: { status: "no_tab", message: ERROR_MESSAGES.no_tab, lastAttemptAt: null, sourceTabId: null },
      lastAlertAt: 0,
      mutedUntil: 0,
      alertActive: false,
      notificationError: null
    };
    function view() {
      const age = state.lastSnapshot ? now() - Date.parse(state.lastSnapshot.observedAt) : Infinity;
      const recent = age >= -5e3 && age <= Math.max(12e4, state.settings.pollSeconds * 2e3 + 15e3);
      const connected = ["ok", "checking"].includes(state.connection.status);
      const assessment = assessSnapshot(state.lastSnapshot?.summary, state.settings, {
        fresh: recent && connected,
        scopeValid: state.lastSnapshot?.scopeValid === true,
        parseErrors: state.lastSnapshot?.parseErrors ?? 0,
        complete: state.lastSnapshot?.complete === true,
        loggedIn: state.connection.status !== "login_required"
      });
      const connection = state.settings.paused ? { ...state.connection, status: "paused", message: ERROR_MESSAGES.paused } : state.connection.status === "ok" && !recent ? { ...state.connection, status: "stale", message: ERROR_MESSAGES.stale } : { ...state.connection };
      return { ...state, settings: { ...state.settings }, connection, assessment };
    }
    async function saveState() {
      await api.storage.session.set({ monitorState: {
        lastSnapshot: state.lastSnapshot,
        connection: state.connection,
        lastAlertAt: state.lastAlertAt,
        mutedUntil: state.mutedUntil,
        alertActive: state.alertActive,
        notificationError: state.notificationError
      } });
    }
    async function badge() {
      const current = view(), a = current.assessment;
      let text = "?", color = "#a16207", title = "急診監控：資料尚未就緒";
      if (a.state === "paused") {
        text = "Ⅱ";
        color = "#64748b";
        title = "急診監控已暫停";
      } else if (a.dataValid) {
        const free = a.estimatedFreeBeds;
        text = (a.state === "trial" ? "~" : "") + String(free);
        if (text.length > 4) text = free < 0 ? "<0" : ">99";
        color = a.state === "trial" ? "#34699a" : a.thresholdReached ? "#b91c1c" : "#16756b";
        title = (a.state === "trial" ? "試算" : "急診監控") + "：剩餘 " + free + " 床，通報計入 " + a.includedPatients + " 人";
      }
      await Promise.allSettled([
        api.action.setBadgeText({ text }),
        api.action.setBadgeBackgroundColor({ color }),
        api.action.setTitle({ title })
      ]);
    }
    async function alarm() {
      if (state.settings.paused) {
        await api.alarms.clear(ALARM_NAME);
        return;
      }
      const period = state.settings.pollSeconds / 60;
      const existing = await api.alarms.get(ALARM_NAME);
      if (!existing || existing.periodInMinutes !== period) {
        await api.alarms.create(ALARM_NAME, { periodInMinutes: period });
      }
      await expiryAlarm();
    }
    async function expiryAlarm() {
      if (!state.lastSnapshot) return;
      const expiresAt = Date.parse(state.lastSnapshot.observedAt) + Math.max(12e4, state.settings.pollSeconds * 2e3 + 15e3) + 1;
      if (expiresAt > now()) await api.alarms.create(EXPIRY_ALARM_NAME, { when: expiresAt });
    }
    const ready = (async () => {
      const [savedSettings, savedSession] = await Promise.all([
        api.storage.local.get("settings"),
        api.storage.session.get("monitorState")
      ]);
      const previous = savedSettings.settings;
      const changedDefinition = Boolean(previous && previous.settingsVersion !== SETTINGS_VERSION);
      state.settings = normalizeSettings(changedDefinition ? {
        ...previous,
        capacity: DEFAULT_SETTINGS.capacity,
        observation2Open: false,
        capacityConfirmed: false
      } : previous);
      const saved = changedDefinition ? null : savedSession.monitorState;
      if (saved) {
        state.lastSnapshot = safeSnapshot(saved.lastSnapshot);
        const allowed = [
          "ok",
          "checking",
          "login_required",
          "no_tab",
          "refresh_required",
          "network_error",
          "invalid",
          "source_not_ready",
          "stale",
          "paused"
        ];
        const status = allowed.includes(saved.connection?.status) ? saved.connection.status : "no_tab";
        state.connection = {
          status: status === "checking" ? "stale" : status,
          message: ERROR_MESSAGES[status] || "監控已連線。",
          lastAttemptAt: typeof saved.connection?.lastAttemptAt === "string" ? saved.connection.lastAttemptAt : null,
          sourceTabId: Number.isInteger(saved.connection?.sourceTabId) ? saved.connection.sourceTabId : null
        };
        state.lastAlertAt = Number.isFinite(saved.lastAlertAt) ? saved.lastAlertAt : 0;
        state.mutedUntil = Number.isFinite(saved.mutedUntil) ? saved.mutedUntil : 0;
        state.alertActive = saved.alertActive === true;
      }
      await api.storage.local.set({ settings: state.settings });
      if (changedDefinition) await saveState();
      await alarm();
      await badge();
    })();
    async function fail(error, tabId = null) {
      const status = Object.hasOwn(ERROR_MESSAGES, error) ? error : "invalid";
      state.connection = {
        status: ["invalid_response", "incomplete_response", "empty_unverified"].includes(status) ? "invalid" : status,
        message: ERROR_MESSAGES[status],
        lastAttemptAt: new Date(now()).toISOString(),
        sourceTabId: tabId
      };
      await saveState();
      await badge();
      return view();
    }
    async function notifyIfNeeded() {
      const a = view().assessment;
      if (a.dataValid && !a.thresholdReached) {
        state.alertActive = false;
        return;
      }
      if (!a.shouldNotify || now() < state.mutedUntil) return;
      const elapsed = now() - state.lastAlertAt;
      if (state.alertActive && (state.settings.repeatMinutes === 0 || elapsed < state.settings.repeatMinutes * 6e4)) return;
      try {
        if (await api.notifications.getPermissionLevel() !== "granted") {
          state.notificationError = "permission_denied";
          return;
        }
        await api.notifications.create("ed-capacity-alert", {
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: "急診床位不足：估計剩 " + a.estimatedFreeBeds + " 床",
          message: "計入推床患者 " + a.includedPatients + " 人／基準 " + a.capacity + " 床。請評估滿載通報需求。",
          priority: 1,
          requireInteraction: true
        });
        state.lastAlertAt = now();
        state.alertActive = true;
        state.notificationError = null;
      } catch {
        state.notificationError = "notification_failed";
      }
    }
    async function refreshInner() {
      await ready;
      if (state.settings.paused) {
        await badge();
        return view();
      }
      const tabs = await api.tabs.query({ url: SOURCE_PATTERN });
      const available = tabs.filter((tab2) => isSourceUrl(tab2.url) && !tab2.discarded);
      if (!available.length) return fail(tabs.length ? "refresh_required" : "no_tab");
      available.sort((a, b) => Number(b.id === state.connection.sourceTabId) - Number(a.id === state.connection.sourceTabId) || Number(b.active) - Number(a.active) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
      const tab = available[0];
      state.connection = {
        status: "checking",
        message: "正在更新全急診清單。",
        lastAttemptAt: new Date(now()).toISOString(),
        sourceTabId: tab.id
      };
      await saveState();
      let response, requestTimer;
      try {
        response = await Promise.race([
          api.tabs.sendMessage(tab.id, { type: "COLLECT" }, { frameId: 0 }).catch(() => ({ ok: false, error: "refresh_required" })),
          new Promise((resolve) => {
            requestTimer = setTimeout(() => resolve({ ok: false, error: "network_error" }), 2e4);
          })
        ]);
      } finally {
        clearTimeout(requestTimer);
      }
      if (state.connection.sourceTabId !== tab.id || state.connection.status === "login_required") {
        return view();
      }
      if (state.settings.paused) {
        await saveState();
        await badge();
        return view();
      }
      if (!response?.ok) return fail(response?.error || "invalid_response", tab.id);
      const snapshot = safeSnapshot({ ...response, sourceTabId: tab.id });
      if (!snapshot) return fail("invalid_response", tab.id);
      state.lastSnapshot = snapshot;
      await expiryAlarm();
      state.connection = {
        status: "ok",
        message: "已更新全急診清單。",
        lastAttemptAt: state.connection.lastAttemptAt,
        sourceTabId: tab.id
      };
      if (!view().assessment.dataValid) {
        state.connection.status = "invalid";
        state.connection.message = ERROR_MESSAGES.invalid;
      }
      await notifyIfNeeded();
      await saveState();
      await badge();
      return view();
    }
    function refresh() {
      if (!inFlight) inFlight = refreshInner().catch(() => fail("network_error")).finally(() => {
        inFlight = null;
      });
      return inFlight;
    }
    async function saveSettings(input) {
      await ready;
      state.settings = normalizeSettings({ ...state.settings, ...input });
      state.lastAlertAt = 0;
      state.alertActive = false;
      await api.storage.local.set({ settings: state.settings });
      await alarm();
      await saveState();
      await badge();
      return state.settings.paused ? view() : refresh();
    }
    async function openSource() {
      await ready;
      const tabs = await api.tabs.query({ url: SOURCE_PATTERN });
      const tab = tabs.find((item) => isSourceUrl(item.url));
      if (tab) {
        await api.tabs.update(tab.id, { active: true });
      } else {
        await api.tabs.create({ url: SOURCE_URL });
      }
      return view();
    }
    async function sourceEvent(type, tabId, url) {
      await ready;
      if (!isSourceUrl(url)) return view();
      if (type === "SOURCE_AUTH_REQUIRED") {
        if (state.connection.sourceTabId === tabId || state.connection.sourceTabId === null) {
          return fail("login_required", tabId);
        }
        return view();
      }
      return refresh();
    }
    async function sourceGone(tabId) {
      await ready;
      if (state.connection.sourceTabId === tabId) {
        await fail("no_tab");
        if (!state.settings.paused) return refresh();
      }
      return view();
    }
    return {
      ready,
      refresh,
      saveSettings,
      openSource,
      sourceEvent,
      sourceGone,
      getState: async () => {
        await ready;
        await badge();
        return view();
      },
      togglePause: async () => {
        await ready;
        return saveSettings({ paused: !state.settings.paused });
      },
      mute: async (minutes = 30) => {
        await ready;
        const safeMinutes = [0, 15, 30, 60].includes(minutes) ? minutes : 30;
        state.mutedUntil = now() + safeMinutes * 6e4;
        await saveState();
        return view();
      }
    };
  }

  // src/service-worker.js
  var monitor = createMonitorController(chrome);
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return false;
    let task;
    if (["SOURCE_READY", "SOURCE_AUTH_REQUIRED"].includes(message?.type) && sender.tab && sender.frameId === 0 && isSourceUrl(sender.url)) {
      task = () => monitor.sourceEvent(message.type, sender.tab.id, sender.url);
    } else if (sender.url?.startsWith(chrome.runtime.getURL(""))) {
      const actions = {
        GET_STATE: () => monitor.getState(),
        REFRESH: () => monitor.refresh(),
        SAVE_SETTINGS: () => monitor.saveSettings(message.settings),
        TOGGLE_PAUSE: () => monitor.togglePause(),
        MUTE: () => monitor.mute(message.minutes),
        OPEN_SOURCE: () => monitor.openSource()
      };
      task = actions[message?.type];
    }
    if (!task) return false;
    Promise.resolve().then(task).then(sendResponse).catch(() => sendResponse({ error: "operation_failed" }));
    return true;
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === ALARM_NAME) void monitor.refresh();
    if (alarm.name === EXPIRY_ALARM_NAME) void monitor.getState();
  });
  chrome.runtime.onInstalled.addListener(() => {
    void monitor.refresh();
  });
  chrome.runtime.onStartup.addListener(() => {
    void monitor.refresh();
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void monitor.sourceGone(tabId);
  });
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (change.url && !isSourceUrl(change.url)) void monitor.sourceGone(tabId);
  });
  chrome.notifications.onClicked.addListener((id) => {
    if (id === "ed-capacity-alert") void monitor.openSource();
  });
})();
