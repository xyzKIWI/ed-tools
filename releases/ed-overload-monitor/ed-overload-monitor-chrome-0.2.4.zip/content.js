(() => {
  // src/bed-rules.mjs
  var STATUS_KEYS = ["在院中", "在院", "發落", "other"];
  function normalizeStatus(value) {
    if (typeof value !== "string") return "other";
    const status = value.trim();
    return STATUS_KEYS.includes(status) ? status : "other";
  }
  function classifyBed(value) {
    const text = String(value ?? "").normalize("NFKC").trim().toUpperCase();
    const match = /^([A-Z]+)\s*(\d{1,3})$/.exec(text);
    const unknown = { kind: "unknown", zone: "unknown", physicalBedKey: null };
    if (!match) return unknown;
    const prefix = match[1];
    const number = Number(match[2]);
    const result = (kind, zone, physicalBedKey = null) => ({ prefix, number, kind, zone, physicalBedKey });
    if (prefix === "M" && number >= 97 && number <= 99) {
      return result("stretcher", "corridor_observation", "M-" + number);
    }
    if (["M", "P", "T", "O"].includes(prefix) && number >= 1 && number <= 38) {
      return result("stretcher", "standard", "standard-" + number);
    }
    const nonStretcherStart = { M: 40, T: 70, P: 80 }[prefix];
    if (nonStretcherStart !== void 0 && number >= nonStretcherStart) {
      return result("non_stretcher", "non_bedded");
    }
    if (["C", "R"].includes(prefix) && number > 0) {
      return result(
        "stretcher",
        prefix === "C" ? "resuscitation_area" : "resuscitation_room",
        prefix + "-" + number
      );
    }
    if (prefix === "A" && number > 0) {
      return result("stretcher", "isolation", "A-" + number);
    }
    return result("unknown", "unknown");
  }
  function summarizeStretcherPatients(records) {
    const rows = Array.isArray(records) ? records : [];
    const encounters = /* @__PURE__ */ new Map();
    let invalidRecordRows = Array.isArray(records) ? 0 : 1;
    let missingEncounterRows = 0;
    for (const record of rows) {
      if (!record || typeof record !== "object" || Array.isArray(record)) {
        invalidRecordRows++;
        continue;
      }
      const rawId = record.encounterId;
      const id = typeof rawId === "string" || typeof rawId === "number" && Number.isFinite(rawId) ? String(rawId).trim() : "";
      if (!id) {
        missingEncounterRows++;
        continue;
      }
      const bed = classifyBed(record.bed);
      const normalizedCode = String(record.bed ?? "").normalize("NFKC").trim().toUpperCase();
      const signature = bed.physicalBedKey ?? [bed.kind, bed.prefix ?? "", bed.number ?? "", normalizedCode].join(":");
      const status = normalizeStatus(record.status);
      const existing = encounters.get(id);
      if (existing) {
        existing.rows++;
        if (existing.signature !== signature || existing.status !== status) {
          existing.conflict = true;
        }
      } else {
        encounters.set(id, { bed, signature, status, rows: 1, conflict: false });
      }
    }
    const byZone = {
      standard: 0,
      resuscitation_area: 0,
      resuscitation_room: 0,
      isolation: 0,
      corridor_observation: 0,
      non_bedded: 0,
      unknown: 0
    };
    const byStatus = Object.fromEntries(
      STATUS_KEYS.map((status) => [status, { patients: 0, stretcherPatients: 0 }])
    );
    const standardPatientsByNumber = {};
    const occupied = /* @__PURE__ */ new Map();
    const counts = { stretcher: 0, non_stretcher: 0, unknown: 0 };
    let conflictingEncounters = 0;
    let duplicateEncounterRows = 0;
    for (const entry of encounters.values()) {
      duplicateEncounterRows += entry.rows - 1;
      if (entry.conflict) {
        conflictingEncounters++;
        continue;
      }
      const { bed, status } = entry;
      counts[bed.kind]++;
      byZone[bed.zone]++;
      byStatus[status].patients++;
      if (bed.kind !== "stretcher") continue;
      byStatus[status].stretcherPatients++;
      if (bed.zone === "standard") {
        standardPatientsByNumber[bed.number] = (standardPatientsByNumber[bed.number] ?? 0) + 1;
      }
      occupied.set(bed.physicalBedKey, (occupied.get(bed.physicalBedKey) ?? 0) + 1);
    }
    const duplicatePhysicalBeds = [...occupied.values()].filter((count) => count > 1).length;
    const classifiedCountReliable = invalidRecordRows === 0 && missingEncounterRows === 0 && conflictingEncounters === 0;
    return {
      inputRows: rows.length,
      identifiedPatients: encounters.size,
      stretcherPatients: counts.stretcher,
      standardPatients: byZone.standard,
      cPatients: byZone.resuscitation_area,
      rPatients: byZone.resuscitation_room,
      isolationPatients: byZone.isolation,
      corridorPatients: byZone.corridor_observation,
      nonStretcherPatients: counts.non_stretcher,
      unknownPositionPatients: counts.unknown,
      occupiedPhysicalBeds: occupied.size,
      standardPatientsByNumber,
      byZone,
      byStatus,
      quality: {
        invalidRecordRows,
        missingEncounterRows,
        duplicateEncounterRows,
        conflictingEncounters,
        duplicatePhysicalBeds,
        classifiedCountReliable,
        bedOccupancyReliable: classifiedCountReliable && duplicatePhysicalBeds === 0 && counts.unknown === 0
      }
    };
  }

  // src/list-parser.mjs
  var SOURCE_URL = "https://intraweb.kmugh.org.tw/WEB/ipdNote/ER_Main";
  var LIST_URL = SOURCE_URL + "/ER_PatientListIN";
  var SOURCE_PATTERN = SOURCE_URL + "*";
  function isSourceUrl(value) {
    try {
      const url = new URL(value);
      return url.origin === "https://intraweb.kmugh.org.tw" && url.pathname.replace(/\/$/, "").toLowerCase() === "/web/ipdnote/er_main";
    } catch {
      return false;
    }
  }
  function hasVisibleLogin(document2) {
    return [...document2.querySelectorAll('input[type="password"]')].some((element) => element.getClientRects().length > 0 && (typeof element.checkVisibility !== "function" || element.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })));
  }
  function parsePatientListHtml(html, Parser = globalThis.DOMParser) {
    const fail = (error) => ({ ok: false, error });
    if (typeof html !== "string" || html.length > 5e6 || !html.trim()) {
      return fail("invalid_response");
    }
    let document2;
    try {
      document2 = new Parser().parseFromString(html, "text/html");
    } catch {
      return fail("invalid_response");
    }
    if (document2.querySelector('input[type="password"]')) return fail("login_required");
    let scope = document2.querySelector("#ERPatientListTable");
    if (!scope && /<(?:tr|tbody)\b/i.test(html)) {
      const wrapped = new Parser().parseFromString(
        '<table id="ed-response-table">' + html + "</table>",
        "text/html"
      );
      scope = wrapped.querySelector("#ERPatientListTable") || wrapped.querySelector("#ed-response-table");
    }
    if (!scope) return fail("invalid_response");
    const rows = [...scope.querySelectorAll("tr.tr-item")];
    if (rows.length === 0) {
      return fail("empty_unverified");
    }
    if (rows.length > 5e3) return fail("invalid_response");
    const cells = [...scope.querySelectorAll("td[data-erinfo]")];
    if (cells.length !== rows.length) return fail("incomplete_response");
    const records = [];
    let parseErrors = 0;
    for (const row of rows) {
      const rowCells = row.querySelectorAll("td[data-erinfo]");
      if (rowCells.length !== 1) {
        parseErrors++;
        continue;
      }
      try {
        const data = JSON.parse(rowCells[0].textContent);
        if (!data || typeof data !== "object" || Array.isArray(data) || !Object.hasOwn(data, "INHOSPID") || !Object.hasOwn(data, "床號")) {
          parseErrors++;
          continue;
        }
        const status = String(data.STATUSNAME ?? "").trim();
        if (!["在院中", "在院", "發落"].includes(status)) {
          parseErrors++;
          continue;
        }
        const bedCode = String(data["床號"] ?? "").normalize("NFKC").trim().toUpperCase();
        if (/^Z\s*0*1$/.test(bedCode)) continue;
        records.push({ encounterId: data.INHOSPID, bed: data["床號"], status });
      } catch {
        parseErrors++;
      }
    }
    return {
      ok: true,
      summary: summarizeStretcherPatients(records),
      parseErrors,
      scopeValid: true,
      complete: parseErrors === 0
    };
  }

  // src/content.js
  if (isSourceUrl(location.href) && !globalThis.__edOverloadCollectorInstalled) {
    let listRequest = function() {
      return {
        tempD: document.getElementById("doctorsListText")?.value || "",
        tempST: document.getElementById("StationListText")?.value || ""
      };
    };
    globalThis.__edOverloadCollectorInstalled = true;
    let inFlight = null;
    async function collect() {
      if (hasVisibleLogin(document)) return { ok: false, error: "login_required" };
      if (!document.querySelector("#ERPatientListTable")) {
        return { ok: false, error: "source_not_ready" };
      }
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15e3);
      try {
        const response = await fetch(LIST_URL, {
          method: "POST",
          credentials: "same-origin",
          cache: "no-store",
          headers: { "Content-Type": "application/json; charset=UTF-8" },
          body: JSON.stringify(listRequest()),
          signal: controller.signal
        });
        if ([401, 403].includes(response.status)) return { ok: false, error: "login_required" };
        if (!response.ok) return { ok: false, error: "network_error" };
        const finalUrl = new URL(response.url);
        if (finalUrl.origin !== location.origin || finalUrl.pathname.toLowerCase() !== new URL(LIST_URL).pathname.toLowerCase()) {
          return { ok: false, error: "login_required" };
        }
        if (!(response.headers.get("content-type") || "").toLowerCase().includes("text/html")) {
          return { ok: false, error: "invalid_response" };
        }
        const html = await response.text();
        if (hasVisibleLogin(document)) return { ok: false, error: "login_required" };
        const result = parsePatientListHtml(html);
        return result.ok ? { ...result, observedAt: (/* @__PURE__ */ new Date()).toISOString() } : result;
      } catch {
        return { ok: false, error: "network_error" };
      } finally {
        clearTimeout(timeout);
      }
    }
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (sender.id !== chrome.runtime.id || message?.type !== "COLLECT") return false;
      if (!inFlight) inFlight = collect().finally(() => {
        inFlight = null;
      });
      inFlight.then(sendResponse).catch(() => sendResponse({ ok: false, error: "invalid_response" }));
      return true;
    });
    const sourceState = () => hasVisibleLogin(document) ? "SOURCE_AUTH_REQUIRED" : document.querySelector("#ERPatientListTable") ? "SOURCE_READY" : "loading";
    let lastSourceState = sourceState();
    const announce = (type) => chrome.runtime.sendMessage({ type }).catch(() => {
    });
    if (lastSourceState !== "loading") announce(lastSourceState);
    let checkTimer;
    new MutationObserver(() => {
      if (checkTimer) return;
      checkTimer = setTimeout(() => {
        checkTimer = null;
        const current = sourceState();
        if (current !== lastSourceState) {
          lastSourceState = current;
          if (current !== "loading") announce(current);
        }
      }, 300);
    }).observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style", "hidden"]
    });
  }
})();
