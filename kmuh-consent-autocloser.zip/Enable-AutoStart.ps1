﻿<#
.SYNOPSIS
    一鍵啟用開機自動啟動 (加入 Windows 啟動資料夾)
#>

$startup = [Environment]::GetFolderPath('Startup')
$targetExe = Join-Path $PSScriptRoot "ConsentFormAutoCloser.exe"
$lnkPath = Join-Path $startup "KMUGH ConsentForm AutoCloser.lnk"

if (-not (Test-Path $targetExe)) {
    Write-Host "[錯誤] 找不到 $targetExe" -ForegroundColor Red
    exit 1
}

$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($lnkPath)
$sc.TargetPath = $targetExe
$sc.WorkingDirectory = $PSScriptRoot
$sc.WindowStyle = 7
$sc.Description = "KMUGH 數位簽名同意書自動關閉背景守護服務"
$sc.Save()

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   KMUGH ConsentFormAutoCloser 開機自啟設定" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "[成功] 已啟用開機自動啟動！" -ForegroundColor Green
Write-Host "捷徑位置: $lnkPath" -ForegroundColor Gray
Write-Host "目標程式: $targetExe" -ForegroundColor Gray
Write-Host "============================================================" -ForegroundColor Cyan
