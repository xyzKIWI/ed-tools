@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在建立桌面捷徑...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create-DesktopShortcuts.ps1"
echo.
pause
