﻿<#
.SYNOPSIS
    KMUGH ConsentFormAutoCloser 完整自動化測試套件
.DESCRIPTION
    測試包含：
    1. 設定檔完整性與欄位檢查
    2. 主腳本語法與 AST 解析
    3. Mutex 防重複啟動防護
    4. Win32 跨桌面視窗枚舉元件
    5. 端到端生命週期流程測試 (未開網頁不關閉 -> 網頁開啟後倒數自動關閉)
    6. 邊界測試 A：醫師手動提前關閉 ConsentForm.exe，監控引擎平穩重設待命狀態
    7. 邊界測試 B：無網頁開啟時的保底超時關閉防呆測試
#>

$ErrorActionPreference = "Stop"
$testDir = $PSScriptRoot
$mainScript = Join-Path $testDir "ConsentFormAutoCloser.ps1"
$configFile = Join-Path $testDir "config.json"

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   KMUGH ConsentFormAutoCloser 自動化單元與整合測試套件" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

$passedCount = 0
$failedCount = 0

function Assert-Test {
    param(
        [string]$TestName,
        [scriptblock]$TestBlock
    )
    Write-Host "[TEST] $TestName ... " -NoNewline
    try {
        & $TestBlock
        Write-Host "PASSED" -ForegroundColor Green
        $script:passedCount++
    } catch {
        Write-Host "FAILED" -ForegroundColor Red
        Write-Host "  詳細錯誤: $_" -ForegroundColor Red
        $script:failedCount++
    }
}

# -------------------------------------------------------------
# 測試 1: 設定檔完整性與語法檢查
# -------------------------------------------------------------
Assert-Test "測試 config.json 存在且包含必要欄位" {
    if (-not (Test-Path $configFile)) { throw "找不到 config.json" }
    $cfg = Get-Content $configFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($cfg.WebDelaySeconds -ne 45) { throw "WebDelaySeconds 應為 45，實際為 $($cfg.WebDelaySeconds)" }
    if ($cfg.ProcessName -ne "ConsentForm") { throw "ProcessName 應為 ConsentForm" }
    if ($cfg.TargetIp -ne "10.122.120.6") { throw "TargetIp 應為 10.122.120.6" }
    if ($cfg.TargetHost -ne "svs.kmugh.org.tw") { throw "TargetHost 應為 svs.kmugh.org.tw" }
}

# -------------------------------------------------------------
# 測試 2: 腳本語法檢驗 (PowerShell AST 解析)
# -------------------------------------------------------------
Assert-Test "測試 ConsentFormAutoCloser.ps1 語法無解析錯誤" {
    $tokens = $null
    $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($mainScript, [ref]$tokens, [ref]$errors)
    if ($errors.Count -gt 0) {
        throw "語法解析錯誤: $($errors -join '; ')"
    }
}

# -------------------------------------------------------------
# 測試 3: Mutex 防重複啟動防護
# -------------------------------------------------------------
Assert-Test "測試 Mutex 單一執行個體防重複啟動機制" {
    $mutexName = "ConsentFormAutoCloser_Test_Mutex"
    $isNew = $false
    $m1 = New-Object System.Threading.Mutex($true, $mutexName, [ref]$isNew)
    try {
        if (-not $isNew) { throw "初始化測試 Mutex 失敗" }
        $isNew2 = $false
        $m2 = New-Object System.Threading.Mutex($true, $mutexName, [ref]$isNew2)
        try {
            if ($isNew2) { throw "第二個 Mutex 竟然成功取得到鎖，防重複啟動失效！" }
        } finally {
            $m2.Dispose()
        }
    } finally {
        if ($isNew -and $m1) {
            $m1.ReleaseMutex()
            $m1.Dispose()
        }
    }
}

# -------------------------------------------------------------
# 測試 4: Win32 跨桌面視窗枚舉元件
# -------------------------------------------------------------
Assert-Test "測試 Win32 跨桌面視窗枚舉元件" {
    $pinvokeCode = @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace KMUGH.TestHelper
{
    public class WindowHelperTest
    {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr OpenDesktop(string lpszDesktop, uint dwFlags, bool fInherit, uint dwDesiredAccess);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool CloseDesktop(IntPtr hDesktop);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool EnumDesktopWindows(IntPtr hDesktop, EnumWindowsProc lpfn, IntPtr lParam);
        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder strText, int maxCount);
        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(IntPtr hWnd);
        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        public static int CountVisibleWindows() {
            int count = 0;
            IntPtr hDesk = OpenDesktop("Default", 0, false, 0x0100 | 0x0001);
            if (hDesk == IntPtr.Zero) return -1;
            try {
                EnumDesktopWindows(hDesk, (hWnd, lParam) => {
                    if (IsWindowVisible(hWnd) && GetWindowTextLength(hWnd) > 0) count++;
                    return true;
                }, IntPtr.Zero);
            } finally {
                CloseDesktop(hDesk);
            }
            return count;
        }
    }
}
'@
    if (-not ([System.Management.Automation.PSTypeName]'KMUGH.TestHelper.WindowHelperTest').Type) {
        Add-Type -TypeDefinition $pinvokeCode -Language CSharp
    }
    $c = [KMUGH.TestHelper.WindowHelperTest]::CountVisibleWindows()
    if ($c -lt 0) { throw "無法開啟 Default 桌面進行枚舉" }
}

# -------------------------------------------------------------
# 測試 5: 端到端生命週期流程測試 (模擬 ConsentForm.exe 與 網頁觸發)
# -------------------------------------------------------------
Assert-Test "端到端生命週期測試：未開網頁不關閉 -> 網頁開啟後倒數自動關閉" {
    $tempDir = Join-Path $env:TEMP ("CFT_" + [Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $mockExe = Join-Path $tempDir "MockConsentForm.exe"
    Copy-Item "C:\Windows\System32\cmd.exe" $mockExe -Force
    
    $testCfgFile = Join-Path $tempDir "test_config.json"
    $testLogFile = Join-Path $tempDir "test.log"
    @{
        WebDelaySeconds = 2
        FallbackTimeoutSeconds = 30
        TargetHost = "svs.kmugh.org.tw"
        TargetIp = "10.122.120.6"
        ProcessName = "MockConsentForm"
        CheckIntervalMilliseconds = 300
        GracefulWaitSeconds = 2
        LogFile = $testLogFile
        MaxLogSizeBytes = 1048576
    } | ConvertTo-Json | Set-Content -Path $testCfgFile -Encoding UTF8

    $mockProc = $null
    $monitorProc = $null
    $dummyBrowser = $null

    try {
        # 1. 啟動模擬 ConsentForm.exe
        $mockProc = Start-Process $mockExe -ArgumentList "/k title 數位簽名同意書系統_V1150901EXE_KMUGH" -PassThru
        Start-Sleep -Milliseconds 600

        # 2. 啟動監控程序
        $monitorProc = Start-Process "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$mainScript`" -ConfigFile `"$testCfgFile`"" -PassThru
        Start-Sleep -Seconds 2

        # 階段 A：未開啟網頁時，ConsentForm 必須持續存在，不得提前關閉！
        $stillRunning = Get-Process -Id $mockProc.Id -ErrorAction SilentlyContinue
        if (-not $stillRunning) {
            throw "ConsentForm.exe 在未開啟網頁前就被提前關閉了！違反醫師卡簽作業時間保留原則！"
        }

        # 階段 B：模擬開啟同意書網頁
        $dummyBrowser = Start-Process "C:\Windows\System32\cmd.exe" -ArgumentList "/k title SelfieSign - Google Chrome" -PassThru
        Start-Sleep -Milliseconds 600

        # 階段 C：等待倒數 + 關閉
        $waitedSec = 0
        $isClosed = $false
        while ($waitedSec -lt 8) {
            Start-Sleep -Seconds 1
            $waitedSec++
            $chk = Get-Process -Id $mockProc.Id -ErrorAction SilentlyContinue
            if (-not $chk) {
                $isClosed = $true
                break
            }
        }

        if (-not $isClosed) {
            $logContent = if (Test-Path $testLogFile) { Get-Content $testLogFile -Raw } else { "日誌檔案不存在" }
            throw "倒數已結束，但 ConsentForm.exe 尚未被關閉！測試日誌內容：`n$logContent"
        }
    } finally {
        if ($dummyBrowser -and -not $dummyBrowser.HasExited) {
            Stop-Process -Id $dummyBrowser.Id -Force -ErrorAction SilentlyContinue
        }
        if ($mockProc -and -not $mockProc.HasExited) {
            Stop-Process -Id $mockProc.Id -Force -ErrorAction SilentlyContinue
        }
        if ($monitorProc -and -not $monitorProc.HasExited) {
            Stop-Process -Id $monitorProc.Id -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Milliseconds 500
        Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# -------------------------------------------------------------
# 測試 6: 邊界測試 A - 醫師手動提前關閉 ConsentForm.exe
# -------------------------------------------------------------
Assert-Test "邊界測試 A：醫師手動提前關閉 ConsentForm.exe，監控引擎平穩重設待命狀態" {
    $tempDir = Join-Path $env:TEMP ("CFT_Manual_" + [Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $mockExe = Join-Path $tempDir "MockConsentForm.exe"
    Copy-Item "C:\Windows\System32\cmd.exe" $mockExe -Force
    
    $testCfgFile = Join-Path $tempDir "test_config.json"
    $testLogFile = Join-Path $tempDir "test.log"
    @{
        WebDelaySeconds = 10
        FallbackTimeoutSeconds = 30
        TargetHost = "svs.kmugh.org.tw"
        TargetIp = "10.122.120.6"
        ProcessName = "MockConsentForm"
        CheckIntervalMilliseconds = 300
        GracefulWaitSeconds = 2
        LogFile = $testLogFile
        MaxLogSizeBytes = 1048576
    } | ConvertTo-Json | Set-Content -Path $testCfgFile -Encoding UTF8

    $mockProc = $null
    $monitorProc = $null
    try {
        # 先啟動監控引擎，確認完全就緒
        $monitorProc = Start-Process "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$mainScript`" -ConfigFile `"$testCfgFile`"" -PassThru
        Start-Sleep -Seconds 2

        # 啟動 ConsentForm.exe 並等待監控引擎偵測到
        $mockProc = Start-Process $mockExe -ArgumentList "/k title 數位簽名同意書系統_V1150901EXE_KMUGH" -PassThru
        $detected = $false
        for ($i = 0; $i -lt 10; $i++) {
            Start-Sleep -Milliseconds 500
            if (Test-Path $testLogFile) {
                $content = Get-Content $testLogFile -Raw
                if ($content -match "偵測到 MockConsentForm\.exe 執行中") {
                    $detected = $true
                    break
                }
            }
        }
        if (-not $detected) { throw "監控引擎未能及時偵測到 ConsentForm.exe 啟動" }

        # 模擬醫師手動提前關閉 ConsentForm
        Stop-Process -Id $mockProc.Id -Force
        
        # 等待監控引擎偵測到關閉並記載日誌
        $resetLogged = $false
        for ($i = 0; $i -lt 10; $i++) {
            Start-Sleep -Milliseconds 500
            if (Test-Path $testLogFile) {
                $content = Get-Content $testLogFile -Raw
                if ($content -match "重設監控待命狀態") {
                    $resetLogged = $true
                    break
                }
            }
        }

        if ($monitorProc.HasExited) {
            throw "監控引擎在 ConsentForm 提前關閉後異常退出！"
        }
        if (-not $resetLogged) {
            $logContent = if (Test-Path $testLogFile) { Get-Content $testLogFile -Raw } else { "" }
            throw "未在日誌中找到重設待命紀錄: $logContent"
        }
    } finally {
        if ($mockProc -and -not $mockProc.HasExited) { Stop-Process -Id $mockProc.Id -Force -ErrorAction SilentlyContinue }
        if ($monitorProc -and -not $monitorProc.HasExited) { Stop-Process -Id $monitorProc.Id -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 500
        Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# -------------------------------------------------------------
# 測試 7: 邊界測試 B - 無網頁開啟時的保底超時關閉防呆測試
# -------------------------------------------------------------
Assert-Test "邊界測試 B：無網頁開啟時的保底超時關閉防呆測試 (3秒保底超時)" {
    $tempDir = Join-Path $env:TEMP ("CFT_Fallback_" + [Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $mockExe = Join-Path $tempDir "MockConsentForm.exe"
    Copy-Item "C:\Windows\System32\cmd.exe" $mockExe -Force
    
    $testCfgFile = Join-Path $tempDir "test_config.json"
    $testLogFile = Join-Path $tempDir "test.log"
    @{
        WebDelaySeconds = 60
        FallbackTimeoutSeconds = 3 # 3 秒無網頁開啟即保底關閉
        TargetHost = "svs.kmugh.org.tw"
        TargetIp = "10.122.120.6"
        ProcessName = "MockConsentForm"
        CheckIntervalMilliseconds = 300
        GracefulWaitSeconds = 2
        LogFile = $testLogFile
        MaxLogSizeBytes = 1048576
    } | ConvertTo-Json | Set-Content -Path $testCfgFile -Encoding UTF8

    $mockProc = $null
    $monitorProc = $null
    try {
        # 先啟動監控引擎
        $monitorProc = Start-Process "powershell.exe" -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$mainScript`" -ConfigFile `"$testCfgFile`"" -PassThru
        Start-Sleep -Seconds 2

        # 啟動 ConsentForm
        $mockProc = Start-Process $mockExe -ArgumentList "/k title 數位簽名同意書系統_V1150901EXE_KMUGH" -PassThru
        
        # 輪詢等待 ConsentForm 被保底關閉 (3 秒超時 + 2 秒寬限 + 緩衝，共最多 12 秒)
        $isClosed = $false
        for ($i = 0; $i -lt 12; $i++) {
            Start-Sleep -Seconds 1
            if (-not (Get-Process -Id $mockProc.Id -ErrorAction SilentlyContinue)) {
                $isClosed = $true
                break
            }
        }

        if (-not $isClosed) {
            $logContent = if (Test-Path $testLogFile) { Get-Content $testLogFile -Raw } else { "" }
            throw "保底時間已過，但 ConsentForm 尚未關閉！日誌：`n$logContent"
        }
        $logContent = if (Test-Path $testLogFile) { Get-Content $testLogFile -Raw } else { "" }
        if ($logContent -notmatch "保底關閉") {
            throw "未在日誌中找到保底關閉紀錄: $logContent"
        }
    } finally {
        if ($mockProc -and -not $mockProc.HasExited) { Stop-Process -Id $mockProc.Id -Force -ErrorAction SilentlyContinue }
        if ($monitorProc -and -not $monitorProc.HasExited) { Stop-Process -Id $monitorProc.Id -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 500
        Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# -------------------------------------------------------------
# 測試 8: 徹底移除 .vbs 啟動方式與防毒規則合規性檢查
# -------------------------------------------------------------
Assert-Test "徹底移除 .vbs 與 wscript 啟動 PowerShell 呼叫 (KES 合規)" {
    $vbsFiles = Get-ChildItem -Path $testDir -Filter "*.vbs" -Recurse -ErrorAction SilentlyContinue
    if ($vbsFiles.Count -gt 0) {
        throw "目錄中仍殘留 .vbs 檔案: $($vbsFiles.FullName -join ', ')"
    }
    
    $wscriptCalls = Get-ChildItem -Path $testDir -Include "*.bat", "*.cmd", "*.ps1" -Recurse |
        Select-String -Pattern "wscript\.exe\s+.*\.vbs"
    if ($wscriptCalls.Count -gt 0) {
        throw "檔案中仍存在呼叫 wscript 執行 vbs 的指令: $($wscriptCalls -join '; ')"
    }
}

# -------------------------------------------------------------
# 測試 9: 驗證 ConsentFormAutoCloser.exe 編譯與 GUI 子系統
# -------------------------------------------------------------
Assert-Test "驗證 ConsentFormAutoCloser.exe 存在且為 Windows GUI 子系統 (Subsystem=2)" {
    $exePath = Join-Path $testDir "ConsentFormAutoCloser.exe"
    if (-not (Test-Path $exePath)) {
        throw "找不到 ConsentFormAutoCloser.exe"
    }
    $bytes = [System.IO.File]::ReadAllBytes($exePath)
    $peOffset = [BitConverter]::ToInt32($bytes, 0x3C)
    $subsystem = [BitConverter]::ToInt16($bytes, $peOffset + 0x5C)
    if ($subsystem -ne 2) {
        throw "PE Subsystem 應為 2 (Windows GUI, 無控制台黑框)，實際為: $subsystem"
    }
}

# -------------------------------------------------------------
# 測試 10: 桌面捷徑正確性與無效舊捷徑清除檢查
# -------------------------------------------------------------
Assert-Test "驗證桌面捷徑正確指向原生 .exe 與相關管理腳本" {
    $desktop = [Environment]::GetFolderPath("Desktop")
    $obsLnk = Join-Path $desktop "同意書自動關閉工具.lnk"
    if (Test-Path $obsLnk) {
        throw "桌面仍存在已失效之舊版捷徑: $obsLnk"
    }
    
    $startLnk = Join-Path $desktop "【啟動】同意書自動關閉.lnk"
    if (-not (Test-Path $startLnk)) {
        throw "桌面缺少【啟動】同意書自動關閉.lnk 捷徑"
    }
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($startLnk)
    $validTargets = @(
        (Join-Path $testDir "ConsentFormAutoCloser.exe"),
        (Join-Path $testDir "Start-Background.bat")
    )
    if ($validTargets -notcontains $sc.TargetPath) {
        throw "【啟動】捷徑指向不符預期: $($sc.TargetPath)"
    }
}

# -------------------------------------------------------------
# 測試 11: 原生 C# WinExe (ConsentFormAutoCloser.exe) 端到端模擬測試
# -------------------------------------------------------------
Assert-Test "原生 C# WinExe 端到端生命週期測試：未開網頁不關閉 -> 網頁開啟倒數後關閉" {
    $tempDir = Join-Path $env:TEMP ("CFT_Native_" + [Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $mockExe = Join-Path $tempDir "MockConsentForm.exe"
    Copy-Item "C:\Windows\System32\cmd.exe" $mockExe -Force
    
    $testCfgFile = Join-Path $tempDir "test_config.json"
    $testLogFile = Join-Path $tempDir "test.log"
    @{
        WebDelaySeconds = 2
        FallbackTimeoutSeconds = 30
        TargetHost = "svs.kmugh.org.tw"
        TargetIp = "10.122.120.6"
        ProcessName = "MockConsentForm"
        CheckIntervalMilliseconds = 300
        GracefulWaitSeconds = 2
        LogFile = $testLogFile
        MaxLogSizeBytes = 1048576
    } | ConvertTo-Json | Set-Content -Path $testCfgFile -Encoding UTF8

    $nativeExe = Join-Path $testDir "ConsentFormAutoCloser.exe"
    $mockProc = $null
    $monitorProc = $null
    $dummyBrowser = $null

    try {
        # 1. 啟動模擬 ConsentForm.exe
        $mockProc = Start-Process $mockExe -ArgumentList "/k title 數位簽名同意書系統_V1150901EXE_KMUGH" -PassThru
        Start-Sleep -Milliseconds 600

        # 2. 啟動原生監控程序 (使用獨立 Mutex 避免與背景常駐衝突)
        $monitorProc = Start-Process $nativeExe -ArgumentList "-ConfigFile `"$testCfgFile`" -MutexName `"ConsentForm_NativeTest_Mutex`"" -PassThru
        Start-Sleep -Seconds 2

        # 階段 A：未開啟網頁時，ConsentForm 必須持續存在
        $stillRunning = Get-Process -Id $mockProc.Id -ErrorAction SilentlyContinue
        if (-not $stillRunning) {
            throw "原生監控在未開網頁前就關閉了 ConsentForm.exe！"
        }

        # 階段 B：模擬開啟同意書網頁
        $dummyBrowser = Start-Process "C:\Windows\System32\cmd.exe" -ArgumentList "/k title SelfieSign - Google Chrome" -PassThru
        Start-Sleep -Milliseconds 600

        # 階段 C：等待倒數 (2秒) + 關閉
        $waitedSec = 0
        $isClosed = $false
        while ($waitedSec -lt 8) {
            Start-Sleep -Seconds 1
            $waitedSec++
            $chk = Get-Process -Id $mockProc.Id -ErrorAction SilentlyContinue
            if (-not $chk) {
                $isClosed = $true
                break
            }
        }

        if (-not $isClosed) {
            $logContent = if (Test-Path $testLogFile) { Get-Content $testLogFile -Raw } else { "日誌檔案不存在" }
            throw "倒數已結束，但 ConsentForm.exe 尚未被關閉！測試日誌內容：`n$logContent"
        }
    } finally {
        if ($dummyBrowser -and -not $dummyBrowser.HasExited) { Stop-Process -Id $dummyBrowser.Id -Force -ErrorAction SilentlyContinue }
        if ($mockProc -and -not $mockProc.HasExited) { Stop-Process -Id $mockProc.Id -Force -ErrorAction SilentlyContinue }
        if ($monitorProc -and -not $monitorProc.HasExited) { Stop-Process -Id $monitorProc.Id -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 500
        Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# -------------------------------------------------------------
# 測試 12: 多份同意書連續開立展延測試 (倒數期間開新分頁重設倒數)
# -------------------------------------------------------------
Assert-Test "多份同意書連續開立展延測試：倒數期間開啟新同意書視窗，成功觸發重設倒數" {
    $tempDir = Join-Path $env:TEMP ("CFT_Multi_" + [Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $mockExe = Join-Path $tempDir "MockConsentForm.exe"
    Copy-Item "C:\Windows\System32\cmd.exe" $mockExe -Force
    
    $testCfgFile = Join-Path $tempDir "test_config.json"
    $testLogFile = Join-Path $tempDir "test.log"
    @{
        WebDelaySeconds = 4 # 倒數 4 秒
        FallbackTimeoutSeconds = 30
        TargetHost = "svs.kmugh.org.tw"
        TargetIp = "10.122.120.6"
        ProcessName = "MockConsentForm"
        CheckIntervalMilliseconds = 250
        GracefulWaitSeconds = 2
        LogFile = $testLogFile
        MaxLogSizeBytes = 1048576
    } | ConvertTo-Json | Set-Content -Path $testCfgFile -Encoding UTF8

    $nativeExe = Join-Path $testDir "ConsentFormAutoCloser.exe"
    $mockProc = $null
    $monitorProc = $null
    $dummyBrowser1 = $null
    $dummyBrowser2 = $null

    try {
        # 1. 啟動模擬 ConsentForm.exe
        $mockProc = Start-Process $mockExe -ArgumentList "/k title 數位簽名同意書系統_V1150901EXE_KMUGH" -PassThru
        Start-Sleep -Milliseconds 600

        # 2. 啟動原生監控程序
        $monitorProc = Start-Process $nativeExe -ArgumentList "-ConfigFile `"$testCfgFile`" -MutexName `"ConsentForm_MultiTest_Mutex`"" -PassThru
        Start-Sleep -Seconds 1

        # 3. 模擬開啟第一份同意書網頁
        $dummyBrowser1 = Start-Process "C:\Windows\System32\cmd.exe" -ArgumentList "/k title SelfieSign - Google Chrome (Doc 1)" -PassThru
        Start-Sleep -Seconds 2 # 倒數消耗 2 秒，剩餘 2 秒

        # 4. 在倒數進行中開啟第二份同意書網頁
        $dummyBrowser2 = Start-Process "C:\Windows\System32\cmd.exe" -ArgumentList "/k title SelfieSign - Google Chrome (Doc 2)" -PassThru
        Start-Sleep -Seconds 1

        # 5. 檢查日誌中是否成功觸發 REFRESH 展延重設倒數
        $logText = if (Test-Path $testLogFile) { Get-Content $testLogFile -Raw -Encoding UTF8 } else { "" }
        if ($logText -notmatch "重設倒數為 4 秒") {
            throw "未在日誌中偵測到新同意書重設倒數紀錄！日誌內容：`n$logText"
        }

        # 6. 在原始倒數應結束之時間點 (從第一次開啟算起 4.5 秒)，ConsentForm 必須依然存活！
        Start-Sleep -Seconds 1.5
        $stillAlive = Get-Process -Id $mockProc.Id -ErrorAction SilentlyContinue
        if (-not $stillAlive) {
            throw "ConsentForm.exe 提早關閉！多份同意書連續作業展延機制失效！"
        }

        # 7. 等待展延後之新倒數結束並正常關閉
        $isClosed = $false
        for ($i = 0; $i -lt 8; $i++) {
            Start-Sleep -Seconds 1
            if (-not (Get-Process -Id $mockProc.Id -ErrorAction SilentlyContinue)) {
                $isClosed = $true
                break
            }
        }
        if (-not $isClosed) {
            throw "展延倒數結束後，ConsentForm.exe 未被關閉！"
        }
    } finally {
        if ($dummyBrowser1 -and -not $dummyBrowser1.HasExited) { Stop-Process -Id $dummyBrowser1.Id -Force -ErrorAction SilentlyContinue }
        if ($dummyBrowser2 -and -not $dummyBrowser2.HasExited) { Stop-Process -Id $dummyBrowser2.Id -Force -ErrorAction SilentlyContinue }
        if ($mockProc -and -not $mockProc.HasExited) { Stop-Process -Id $mockProc.Id -Force -ErrorAction SilentlyContinue }
        if ($monitorProc -and -not $monitorProc.HasExited) { Stop-Process -Id $monitorProc.Id -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 500
        Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# -------------------------------------------------------------
# 測試 13: 原生 WinExe 命令行介面驗證 (-Status 與 -Stop)
# -------------------------------------------------------------
Assert-Test "原生 WinExe 命令行介面驗證 (-Status 與 -Stop)" {
    $nativeExe = Join-Path $testDir "ConsentFormAutoCloser.exe"
    $statusOutFile = Join-Path $env:TEMP ("CFT_Status_" + [Guid]::NewGuid().ToString("N") + ".txt")
    $stopOutFile = Join-Path $env:TEMP ("CFT_Stop_" + [Guid]::NewGuid().ToString("N") + ".txt")

    try {
        # 1. 確保無常駐程序時，-Status 正確顯示 STOPPED (不把自己誤判為背景常駐)
        $p = Start-Process -FilePath $nativeExe -ArgumentList "-Status" -NoNewWindow -Wait -PassThru -RedirectStandardOutput $statusOutFile
        $statusText = Get-Content $statusOutFile -Raw -Encoding UTF8
        if ($statusText -notmatch "\[監控狀態\] 未在執行中 \(STOPPED\)") {
            throw "無常駐時 -Status 未正確顯示 STOPPED，輸出為：`n$statusText"
        }

        # 2. 啟動背景常駐程序
        $daemon = Start-Process -FilePath $nativeExe -PassThru
        Start-Sleep -Seconds 2

        # 3. 測試 -Status 正確顯示 NORMAL
        Remove-Item $statusOutFile -Force -ErrorAction SilentlyContinue
        $p = Start-Process -FilePath $nativeExe -ArgumentList "-Status" -NoNewWindow -Wait -PassThru -RedirectStandardOutput $statusOutFile
        $statusText = Get-Content $statusOutFile -Raw -Encoding UTF8
        if ($statusText -notmatch "\[監控狀態\] 正在背景執行中 \(NORMAL\)") {
            throw "常駐中 -Status 未正確顯示 NORMAL，輸出為：`n$statusText"
        }

        # 4. 測試 -Stop 成功停止背景常駐程序
        $p = Start-Process -FilePath $nativeExe -ArgumentList "-Stop" -NoNewWindow -Wait -PassThru -RedirectStandardOutput $stopOutFile
        $stopText = Get-Content $stopOutFile -Raw -Encoding UTF8
        if ($stopText -notmatch "\[成功\] 已停止監控程序") {
            throw "-Stop 未成功停止程序，輸出為：`n$stopText"
        }

        Start-Sleep -Seconds 1
        $daemonCheck = Get-Process -Id $daemon.Id -ErrorAction SilentlyContinue
        if ($daemonCheck) {
            throw "-Stop 執行後常駐程序依然在執行中 (PID: $($daemon.Id))！"
        }
    } finally {
        Remove-Item $statusOutFile -Force -ErrorAction SilentlyContinue
        Remove-Item $stopOutFile -Force -ErrorAction SilentlyContinue
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "測試結果: 通過 $passedCount 項 / 失敗 $failedCount 項" -ForegroundColor $(if ($failedCount -eq 0) { [ConsoleColor]::Green } else { [ConsoleColor]::Red })
Write-Host "============================================================" -ForegroundColor Cyan

if ($failedCount -gt 0) {
    exit 1
} else {
    exit 0
}

