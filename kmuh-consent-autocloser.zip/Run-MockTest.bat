@echo off
chcp 65001 >nul
cd /d "%~dp0"
title KMUGH ConsentFormAutoCloser 自動化測試
echo 正在執行 ConsentFormAutoCloser 自動化生命週期與防呆測試...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-ConsentFormCloser.ps1"
echo.
pause
