@echo off
chcp 65001 >nul
cd /d "%~dp0"
title ConsentForm 自動關閉監控 (互動測試模式)
echo ============================================================
echo   KMUGH 數位簽名同意書自動關閉監控 (前景互動測試模式)
echo   - 偵測到同意書網頁開啟後倒數 45 秒自動關閉 ConsentForm.exe
echo   - 期間若開立新同意書自動重設 45 秒
echo   - 按 Ctrl+C 可隨時中斷結束
echo ============================================================
echo.
if exist "%~dp0ConsentFormAutoCloser.exe" (
    "%~dp0ConsentFormAutoCloser.exe" -Interactive
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ConsentFormAutoCloser.ps1" -Interactive
)
pause
