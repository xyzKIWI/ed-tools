@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 停止 ConsentForm 監控服務
if exist "%~dp0ConsentFormAutoCloser.exe" (
    "%~dp0ConsentFormAutoCloser.exe" -Stop
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Stop-Service.ps1"
echo.
ping 127.0.0.1 -n 3 >nul
