﻿<#
.SYNOPSIS
    即時檢視 KMUGH ConsentFormAutoCloser 日誌
#>

$logFile = Join-Path $PSScriptRoot "closer.log"

if (-not (Test-Path $logFile)) {
    Write-Host "[提醒] 日誌檔案尚未建立: $logFile" -ForegroundColor Yellow
    exit 0
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   正在即時監控 closer.log (按 Ctrl+C 結束)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

Get-Content -Path $logFile -Tail 20 -Wait -Encoding UTF8 | ForEach-Object {
    if ($_ -match 'TRIGGER|REFRESH|ACTION') {
        Write-Host $_ -ForegroundColor Yellow
    } elseif ($_ -match 'SUCCESS') {
        Write-Host $_ -ForegroundColor Green
    } elseif ($_ -match 'ERROR|TIMEOUT') {
        Write-Host $_ -ForegroundColor Red
    } else {
        Write-Host $_ -ForegroundColor Gray
    }
}
