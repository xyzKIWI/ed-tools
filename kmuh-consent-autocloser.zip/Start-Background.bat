@echo off
chcp 65001 >nul
pushd "%~dp0"
echo [啟動中] KMUGH ConsentForm 自動關閉背景監控...

if exist "%~dp0ConsentFormAutoCloser.exe" (
    start "" "%~dp0ConsentFormAutoCloser.exe"
) else (
    start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0ConsentFormAutoCloser.ps1"
)

ping 127.0.0.1 -n 2 >nul
if exist "%~dp0ConsentFormAutoCloser.exe" (
    "%~dp0ConsentFormAutoCloser.exe" -Status
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Check-Status.ps1"
)
echo.
ping 127.0.0.1 -n 3 >nul
popd
