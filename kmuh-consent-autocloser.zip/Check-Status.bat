@echo off
chcp 65001 >nul
cd /d "%~dp0"
title KMUGH ConsentForm 狀態檢查
if exist "%~dp0ConsentFormAutoCloser.exe" (
    "%~dp0ConsentFormAutoCloser.exe" -Status
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Check-Status.ps1"
)
echo.
pause
