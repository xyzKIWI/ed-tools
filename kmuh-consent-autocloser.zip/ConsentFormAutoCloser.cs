using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Threading;
using System.Reflection;
using Microsoft.Win32.SafeHandles;

[assembly: AssemblyTitle("KMUGH ConsentFormAutoCloser")]
[assembly: AssemblyDescription("KMUGH 數位簽名同意書自動關閉背景監控服務")]
[assembly: AssemblyCompany("KMUGH")]
[assembly: AssemblyProduct("ConsentFormAutoCloser")]
[assembly: AssemblyCopyright("Copyright (C) 2026 KMUGH")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace ConsentFormAutoCloser
{
    public class Config
    {
        public int WebDelaySeconds = 60;
        public int FallbackTimeoutSeconds = 300;
        public string TargetHost = "svs.kmugh.org.tw";
        public string TargetIp = "10.122.120.6";
        public string ProcessName = "ConsentForm";
        public int CheckIntervalMilliseconds = 1000;
        public int GracefulWaitSeconds = 5;
        public string LogFile = "closer.log";
        public long MaxLogSizeBytes = 2097152;
    }

    public class DetectionResult
    {
        public bool Detected;
        public bool IsNew;
        public string Reason = "";
    }

    public static class WindowHelper
    {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr OpenDesktop(string lpszDesktop, uint dwFlags, bool fInherit, uint dwDesiredAccess);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool CloseDesktop(IntPtr hDesktop);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool EnumDesktopWindows(IntPtr hDesktop, EnumWindowsProc lpfn, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder strText, int maxCount);

        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        public class WindowItem
        {
            public IntPtr Handle;
            public uint ProcessId;
            public string Title;
        }

        public static List<WindowItem> GetDesktopWindows()
        {
            var list = new List<WindowItem>();
            IntPtr hDesk = OpenDesktop("Default", 0, false, 0x0100 | 0x0001);
            if (hDesk == IntPtr.Zero)
            {
                return list;
            }
            try
            {
                EnumDesktopWindows(hDesk, (hWnd, lParam) =>
                {
                    try
                    {
                        if (IsWindowVisible(hWnd))
                        {
                            int len = GetWindowTextLength(hWnd);
                            if (len > 0)
                            {
                                StringBuilder sb = new StringBuilder(len + 1);
                                GetWindowText(hWnd, sb, sb.Capacity);
                                uint pid;
                                GetWindowThreadProcessId(hWnd, out pid);
                                list.Add(new WindowItem { Handle = hWnd, ProcessId = pid, Title = sb.ToString() });
                            }
                        }
                    }
                    catch { }
                    return true;
                }, IntPtr.Zero);
            }
            finally
            {
                CloseDesktop(hDesk);
            }
            return list;
        }
    }

    public class Program
    {
        private const int STD_OUTPUT_HANDLE = -11;
        private const int STD_ERROR_HANDLE = -12;
        private const uint GENERIC_WRITE = 0x40000000;
        private const uint FILE_SHARE_WRITE = 0x00000002;
        private const uint OPEN_EXISTING = 3;
        private const int ATTACH_PARENT_PROCESS = -1;

        [DllImport("kernel32.dll")]
        private static extern bool SetProcessWorkingSetSize(IntPtr hProcess, int minSize, int maxSize);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetStdHandle(int nStdHandle);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool AttachConsole(int dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode,
            IntPtr lpSecurityAttributes,
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        private static Config _config = new Config();
        private static readonly object _logLock = new object();
        private static bool _consoleAttached = false;
        private static List<string> _targetIps = new List<string>();

        private static void InitializeConsoleOutput()
        {
            try
            {
                IntPtr stdOut = GetStdHandle(STD_OUTPUT_HANDLE);
                if (stdOut != IntPtr.Zero && stdOut.ToInt64() != -1)
                {
                    var safe = new SafeFileHandle(stdOut, false);
                    var fs = new FileStream(safe, FileAccess.Write);
                    var writer = new StreamWriter(fs, Encoding.UTF8) { AutoFlush = true };
                    Console.SetOut(writer);
                    _consoleAttached = true;
                    return;
                }
            }
            catch { }

            try
            {
                if (AttachConsole(ATTACH_PARENT_PROCESS))
                {
                    IntPtr hOut = CreateFile("CONOUT$", GENERIC_WRITE, FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                    if (hOut != IntPtr.Zero && hOut.ToInt64() != -1)
                    {
                        var safeHandle = new SafeFileHandle(hOut, true);
                        var fs = new FileStream(safeHandle, FileAccess.Write);
                        var writer = new StreamWriter(fs, Encoding.UTF8) { AutoFlush = true };
                        Console.SetOut(writer);
                        _consoleAttached = true;
                    }
                }
            }
            catch { }
        }

        public static void Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                try
                {
                    Log("FATAL", "未處理之嚴重例外: " + e.ExceptionObject);
                }
                catch { }
            };

            string customConfigFile = null;
            string customMutexName = null;
            bool noMutex = false;
            bool isInteractive = false;
            bool isStop = false;
            bool isStatus = false;

            for (int i = 0; i < args.Length; i++)
            {
                string arg = args[i];
                if (string.Equals(arg, "-ConfigFile", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                {
                    customConfigFile = args[++i];
                }
                else if (string.Equals(arg, "-MutexName", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                {
                    customMutexName = args[++i];
                }
                else if (string.Equals(arg, "-NoMutex", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(arg, "--no-mutex", StringComparison.OrdinalIgnoreCase))
                {
                    noMutex = true;
                }
                else if (string.Equals(arg, "-Interactive", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(arg, "--interactive", StringComparison.OrdinalIgnoreCase))
                {
                    isInteractive = true;
                }
                else if (string.Equals(arg, "--stop", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(arg, "-Stop", StringComparison.OrdinalIgnoreCase))
                {
                    isStop = true;
                }
                else if (string.Equals(arg, "--status", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(arg, "-Status", StringComparison.OrdinalIgnoreCase))
                {
                    isStatus = true;
                }
            }

            if (isInteractive || isStop || isStatus)
            {
                InitializeConsoleOutput();
            }

            LoadConfig(customConfigFile);

            if (isStop)
            {
                StopExistingInstances();
                return;
            }

            if (isStatus)
            {
                ShowStatus();
                return;
            }

            if (noMutex)
            {
                RunMonitorLoop(isInteractive);
                return;
            }

            string mutexName = !string.IsNullOrEmpty(customMutexName)
                ? customMutexName
                : "ConsentFormAutoCloser_SingleInstance_Mutex";

            bool createdNew;
            using (Mutex mutex = new Mutex(true, mutexName, out createdNew))
            {
                if (!createdNew)
                {
                    if (isInteractive || _consoleAttached)
                    {
                        try { Console.WriteLine("[WARNING] ConsentFormAutoCloser 已經在執行中，跳過重複啟動。"); } catch { }
                    }
                    return;
                }

                RunMonitorLoop(isInteractive);
            }
        }

        private static void LoadConfig(string customConfigFile)
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string configPath = !string.IsNullOrEmpty(customConfigFile)
                ? (Path.IsPathRooted(customConfigFile) ? customConfigFile : Path.Combine(baseDir, customConfigFile))
                : Path.Combine(baseDir, "config.json");

            if (File.Exists(configPath))
            {
                try
                {
                    string json = File.ReadAllText(configPath, Encoding.UTF8);
                    _config.WebDelaySeconds = GetJsonInt(json, "WebDelaySeconds", _config.WebDelaySeconds);
                    _config.FallbackTimeoutSeconds = GetJsonInt(json, "FallbackTimeoutSeconds", _config.FallbackTimeoutSeconds);
                    _config.TargetHost = GetJsonString(json, "TargetHost", _config.TargetHost);
                    _config.TargetIp = GetJsonString(json, "TargetIp", _config.TargetIp);
                    _config.ProcessName = GetJsonString(json, "ProcessName", _config.ProcessName);
                    _config.CheckIntervalMilliseconds = GetJsonInt(json, "CheckIntervalMilliseconds", _config.CheckIntervalMilliseconds);
                    _config.GracefulWaitSeconds = GetJsonInt(json, "GracefulWaitSeconds", _config.GracefulWaitSeconds);

                    string log = GetJsonString(json, "LogFile", _config.LogFile);
                    _config.LogFile = Path.IsPathRooted(log) ? log : Path.Combine(baseDir, log);

                    _config.MaxLogSizeBytes = GetJsonLong(json, "MaxLogSizeBytes", _config.MaxLogSizeBytes);
                }
                catch (Exception ex)
                {
                    Log("WARN", "解析設定檔失敗，使用預設值: " + ex.Message);
                }
            }
            else
            {
                _config.LogFile = Path.Combine(baseDir, _config.LogFile);
            }

            // 動態解析伺服器 IP
            _targetIps.Clear();
            if (!string.IsNullOrEmpty(_config.TargetIp))
            {
                _targetIps.Add(_config.TargetIp);
            }
            try
            {
                IPAddress[] addrs = Dns.GetHostAddresses(_config.TargetHost);
                foreach (IPAddress a in addrs)
                {
                    string ipStr = a.ToString();
                    if (!_targetIps.Contains(ipStr))
                    {
                        _targetIps.Add(ipStr);
                    }
                }
            }
            catch { }
        }

        private static string GetJsonString(string json, string key, string def)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\"([^\"]*)\"");
            return m.Success ? m.Groups[1].Value : def;
        }

        private static int GetJsonInt(string json, string key, int def)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*(-?\\d+)");
            return m.Success ? int.Parse(m.Groups[1].Value) : def;
        }

        private static long GetJsonLong(string json, string key, long def)
        {
            Match m = Regex.Match(json, "\"" + key + "\"\\s*:\\s*(\\d+)");
            return m.Success ? long.Parse(m.Groups[1].Value) : def;
        }

        private static void CaptureBaseline(HashSet<int> baselinePorts, Dictionary<IntPtr, string> baselineWindows)
        {
            baselinePorts.Clear();
            baselineWindows.Clear();

            // 1. 抓取當前既存的 TCP 活躍連線 (排除 TimeWait / CloseWait)
            try
            {
                IPGlobalProperties props = IPGlobalProperties.GetIPGlobalProperties();
                TcpConnectionInformation[] conns = props.GetActiveTcpConnections();
                foreach (TcpConnectionInformation c in conns)
                {
                    string remoteIp = c.RemoteEndPoint.Address.ToString();
                    if (_targetIps.Contains(remoteIp))
                    {
                        if (c.State == TcpState.Established || c.State == TcpState.SynSent)
                        {
                            baselinePorts.Add(c.LocalEndPoint.Port);
                        }
                    }
                }
            }
            catch { }

            // 2. 抓取當前既有的桌面視窗及其標題
            try
            {
                List<WindowHelper.WindowItem> windows = WindowHelper.GetDesktopWindows();
                foreach (var w in windows)
                {
                    if (Regex.IsMatch(w.Title, "SelfieSign|signDoc", RegexOptions.IgnoreCase))
                    {
                        baselineWindows[w.Handle] = w.Title;
                    }
                }
            }
            catch { }

            // 3. 抓取當前既有的 Process 主視窗及其標題
            try
            {
                Process[] allProcs = Process.GetProcesses();
                foreach (var p in allProcs)
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(p.MainWindowTitle) &&
                            Regex.IsMatch(p.MainWindowTitle, "SelfieSign|signDoc", RegexOptions.IgnoreCase))
                        {
                            baselineWindows[p.MainWindowHandle] = p.MainWindowTitle;
                        }
                    }
                    catch { }
                    finally
                    {
                        try { p.Dispose(); } catch { }
                    }
                }
            }
            catch { }
        }

        private static void RunMonitorLoop(bool isInteractive)
        {
            // 待命前置基線 (ConsentForm 未開啟前持續維護，避免同輪開啟時漏抓真正的新網頁)
            HashSet<int> standbyPorts = new HashSet<int>();
            Dictionary<IntPtr, string> standbyWindows = new Dictionary<IntPtr, string>();

            // 本次生命週期基線與已偵測字典 (記錄視窗標題，支援同一視窗開新分頁展延)
            HashSet<int> baselinePorts = new HashSet<int>();
            Dictionary<IntPtr, string> baselineWindows = new Dictionary<IntPtr, string>();
            HashSet<int> knownPorts = new HashSet<int>();
            Dictionary<IntPtr, string> knownWindows = new Dictionary<IntPtr, string>();

            bool hasLoggedStart = false;
            int lastConsentProcCount = 0;
            DateTime? consentStartTime = null;
            DateTime? countdownEndTime = null;
            DateTime? webTriggerTime = null;
            int lastLoggedSecond = -1;

            Log("INFO", "=== KMUGH ConsentForm 自動關閉原生監控服務已啟動 ===");
            Log("INFO", string.Format("設定參數: 網頁觸發倒數={0}秒, 無網頁保底={1}秒, 目標伺服器={2} ({3})",
                _config.WebDelaySeconds, _config.FallbackTimeoutSeconds, _config.TargetHost, string.Join(", ", _targetIps.ToArray())));

            TrimMemory();

            while (true)
            {
                try
                {
                    Process[] procs = new Process[0];
                    try
                    {
                        procs = Process.GetProcessesByName(_config.ProcessName);
                    }
                    catch { }

                    if (procs.Length == 0)
                    {
                        if (lastConsentProcCount > 0)
                        {
                            Log("INFO", string.Format("{0}.exe 已關閉，重設監控待命狀態。", _config.ProcessName));
                            baselinePorts.Clear();
                            baselineWindows.Clear();
                            knownPorts.Clear();
                            knownWindows.Clear();
                            consentStartTime = null;
                            countdownEndTime = null;
                            webTriggerTime = null;
                            lastLoggedSecond = -1;
                            hasLoggedStart = false;
                            if (isInteractive)
                            {
                                try { Console.WriteLine(); } catch { }
                            }
                            TrimMemory();
                        }
                        lastConsentProcCount = 0;

                        // ConsentForm 尚未啟動時，每輪更新待命基線 (ConsentForm 開啟前的最後一刻快照)
                        CaptureBaseline(standbyPorts, standbyWindows);

                        Thread.Sleep(_config.CheckIntervalMilliseconds);
                        continue;
                    }

                    // 偵測到 ConsentForm.exe 執行中
                    lastConsentProcCount = procs.Length;
                    if (!hasLoggedStart)
                    {
                        List<string> pids = new List<string>();
                        foreach (var p in procs) pids.Add(p.Id.ToString());
                        Log("DETECT", string.Format("偵測到 {0}.exe 執行中 (PID: {1})。", _config.ProcessName, string.Join(", ", pids.ToArray())));
                        
                        // 使用程式開啟前一刻的待命快照作為基線，絕不漏抓與程式同步開啟的新網頁
                        baselinePorts = new HashSet<int>(standbyPorts);
                        baselineWindows = new Dictionary<IntPtr, string>(standbyWindows);
                        knownPorts.Clear();
                        knownWindows.Clear();

                        if (baselinePorts.Count > 0 || baselineWindows.Count > 0)
                        {
                            Log("INFO", string.Format("已載入前置歷史快照 (視窗: {0} 個, 連線: {1} 個)，歷史分頁將不會誤觸發關閉。",
                                baselineWindows.Count, baselinePorts.Count));
                        }

                        Log("INFO", "保留醫師勾選同意書、完成卡簽或開其他診斷書作業時間，等待開啟簽名網頁...");
                        consentStartTime = DateTime.Now;
                        countdownEndTime = null;
                        webTriggerTime = null;
                        lastLoggedSecond = -1;
                        hasLoggedStart = true;
                    }

                    // 檢查同意書網頁 (SelfieSign / svs) 是否開啟 (支援同一視窗開新分頁標題變化判定)
                    DetectionResult det = TestConsentWebOpened(baselinePorts, baselineWindows, knownPorts, knownWindows);

                    if (det.Detected)
                    {
                        // 情況 1：尚未開始倒數，首次偵測到網頁開啟
                        if (!countdownEndTime.HasValue)
                        {
                            countdownEndTime = DateTime.Now.AddSeconds(_config.WebDelaySeconds);
                            webTriggerTime = DateTime.Now;
                            lastLoggedSecond = -1;
                            Log("TRIGGER", "【網頁開啟觸發】" + det.Reason);
                            Log("TRIGGER", string.Format("開始執行 {0} 秒關閉倒數 (保留最後簽名與作業時間)...", _config.WebDelaySeconds));
                        }
                        // 情況 2：倒數進行中，又偵測到開啟新的同意書/連線
                        else if (det.IsNew)
                        {
                            countdownEndTime = DateTime.Now.AddSeconds(_config.WebDelaySeconds);
                            lastLoggedSecond = -1;
                            Log("REFRESH", string.Format("【偵測到新同意書連線/視窗】重設倒數為 {0} 秒！", _config.WebDelaySeconds));
                        }
                    }

                    // 處理倒數計時 (依據真實系統時間戳判定)
                    if (countdownEndTime.HasValue)
                    {
                        double remainingExact = (countdownEndTime.Value - DateTime.Now).TotalSeconds;
                        int remainingSeconds = (int)Math.Ceiling(remainingExact);

                        if (remainingSeconds > 0)
                        {
                            if (remainingSeconds != lastLoggedSecond)
                            {
                                lastLoggedSecond = remainingSeconds;

                                if (isInteractive)
                                {
                                    try
                                    {
                                        Console.Write(string.Format("\r[COUNTDOWN] 同意書網頁已開啟，將於 {0} 秒後自動關閉 {1}.exe...   ",
                                            remainingSeconds, _config.ProcessName));
                                    }
                                    catch { }
                                }

                                if (remainingSeconds % 15 == 0 || remainingSeconds <= 5)
                                {
                                    Log("COUNTDOWN", string.Format("剩餘 {0} 秒自動關閉 {1}.exe...", remainingSeconds, _config.ProcessName));
                                }
                            }
                        }
                        else
                        {
                            if (isInteractive)
                            {
                                try { Console.WriteLine(); } catch { }
                            }
                            Log("ACTION", string.Format("倒數 {0} 秒已結束，執行自動關閉 {1}.exe...", _config.WebDelaySeconds, _config.ProcessName));
                            StopConsentProcesses(procs, _config.GracefulWaitSeconds);
                            countdownEndTime = null;
                            lastLoggedSecond = -1;
                            hasLoggedStart = false;
                            knownPorts.Clear();
                            knownWindows.Clear();
                            TrimMemory();
                        }
                    }
                    // 無網頁開啟之保底機制
                    else if (_config.FallbackTimeoutSeconds > 0 && consentStartTime.HasValue)
                    {
                        double elapsed = (DateTime.Now - consentStartTime.Value).TotalSeconds;
                        if (elapsed >= _config.FallbackTimeoutSeconds)
                        {
                            if (isInteractive)
                            {
                                try { Console.WriteLine(); } catch { }
                            }
                            Log("TIMEOUT", string.Format("{0}.exe 開啟已滿保底時間 {1} 秒且未偵測到簽名網頁，執行保底關閉。",
                                _config.ProcessName, _config.FallbackTimeoutSeconds));
                            StopConsentProcesses(procs, _config.GracefulWaitSeconds);
                            countdownEndTime = null;
                            lastLoggedSecond = -1;
                            hasLoggedStart = false;
                            knownPorts.Clear();
                            knownWindows.Clear();
                            TrimMemory();
                        }
                    }

                    // 釋放本輪取得之 Process 物件
                    foreach (var p in procs)
                    {
                        try { p.Dispose(); } catch { }
                    }
                }
                catch (Exception ex)
                {
                    Log("ERROR", "監控迴圈異常: " + ex.Message);
                }

                Thread.Sleep(_config.CheckIntervalMilliseconds);
            }
        }

        private static DetectionResult TestConsentWebOpened(
            HashSet<int> baselinePorts,
            Dictionary<IntPtr, string> baselineWindows,
            HashSet<int> knownPorts,
            Dictionary<IntPtr, string> knownWindows)
        {
            DetectionResult result = new DetectionResult();
            bool detected = false;
            bool isNew = false;
            string detectedReason = "";
            string newReason = "";

            // 1. TCP 連線偵測 (僅限 Established / SynSent，嚴格排除 TimeWait / CloseWait 與歷史連線)
            try
            {
                IPGlobalProperties props = IPGlobalProperties.GetIPGlobalProperties();
                TcpConnectionInformation[] conns = props.GetActiveTcpConnections();
                foreach (TcpConnectionInformation c in conns)
                {
                    string remoteIp = c.RemoteEndPoint.Address.ToString();
                    if (_targetIps.Contains(remoteIp))
                    {
                        // 僅接受真正連線中的狀態
                        if (c.State == TcpState.Established || c.State == TcpState.SynSent)
                        {
                            int port = c.LocalEndPoint.Port;

                            // 若此連線在 ConsentForm 開啟時就已存在，視為歷史連線，絕不觸發！
                            if (baselinePorts != null && baselinePorts.Contains(port))
                            {
                                continue;
                            }

                            detected = true;
                            if (!knownPorts.Contains(port))
                            {
                                knownPorts.Add(port);
                                isNew = true;
                                if (string.IsNullOrEmpty(newReason))
                                {
                                    newReason = string.Format("網路連線至同意書伺服器 {0}:{1} (本地埠: {2}, 狀態: {3})",
                                        remoteIp, c.RemoteEndPoint.Port, port, c.State);
                                }
                            }
                            else if (string.IsNullOrEmpty(detectedReason))
                            {
                                detectedReason = string.Format("網路連線至同意書伺服器 {0}:{1} (本地埠: {2}, 狀態: {3})",
                                    remoteIp, c.RemoteEndPoint.Port, port, c.State);
                            }
                        }
                    }
                }
            }
            catch { }

            // 2. 視窗標題偵測 (包含 SelfieSign 或 signDoc，支援同視窗開新分頁標題變化展延)
            try
            {
                List<WindowHelper.WindowItem> windows = WindowHelper.GetDesktopWindows();
                foreach (var w in windows)
                {
                    if (Regex.IsMatch(w.Title, "SelfieSign|signDoc", RegexOptions.IgnoreCase))
                    {
                        // 若此視窗在 ConsentForm 開啟前就已經存在，且標題完全沒變，視為歷史視窗，絕不誤觸發！
                        if (baselineWindows != null && baselineWindows.ContainsKey(w.Handle) && baselineWindows[w.Handle] == w.Title)
                        {
                            continue;
                        }

                        detected = true;
                        bool isTitleChanged = knownWindows.ContainsKey(w.Handle) && knownWindows[w.Handle] != w.Title;
                        bool isNewWindow = !knownWindows.ContainsKey(w.Handle);

                        if (isNewWindow || isTitleChanged)
                        {
                            knownWindows[w.Handle] = w.Title;
                            isNew = true;
                            if (string.IsNullOrEmpty(newReason))
                            {
                                newReason = isTitleChanged
                                    ? string.Format("同一瀏覽器視窗載入新同意書分頁: '{0}' (PID: {1})", w.Title, w.ProcessId)
                                    : string.Format("桌面視窗標題符合同意書特徵: '{0}' (PID: {1})", w.Title, w.ProcessId);
                            }
                        }
                        else if (string.IsNullOrEmpty(detectedReason))
                        {
                            detectedReason = string.Format("桌面視窗標題符合同意書特徵: '{0}' (PID: {1})", w.Title, w.ProcessId);
                        }
                    }
                }
            }
            catch { }

            // 3. 備援：Process 主視窗標題偵測 (僅在尚未偵測到時才執行，支援同視窗新分頁)
            if (!detected)
            {
                try
                {
                    Process[] allProcs = Process.GetProcesses();
                    foreach (var p in allProcs)
                    {
                        try
                        {
                            if (!string.IsNullOrEmpty(p.MainWindowTitle) &&
                                Regex.IsMatch(p.MainWindowTitle, "SelfieSign|signDoc", RegexOptions.IgnoreCase))
                            {
                                if (baselineWindows != null && baselineWindows.ContainsKey(p.MainWindowHandle) &&
                                    baselineWindows[p.MainWindowHandle] == p.MainWindowTitle)
                                {
                                    continue;
                                }

                                detected = true;
                                bool isTitleChanged = knownWindows.ContainsKey(p.MainWindowHandle) && knownWindows[p.MainWindowHandle] != p.MainWindowTitle;
                                bool isNewWindow = !knownWindows.ContainsKey(p.MainWindowHandle);

                                if (isNewWindow || isTitleChanged)
                                {
                                    knownWindows[p.MainWindowHandle] = p.MainWindowTitle;
                                    isNew = true;
                                    if (string.IsNullOrEmpty(newReason))
                                    {
                                        newReason = isTitleChanged
                                            ? string.Format("同一主視窗載入新同意書分頁: '{0}' (PID: {1}, 程序: {2})",
                                                p.MainWindowTitle, p.Id, p.ProcessName)
                                            : string.Format("主視窗標題符合同意書特徵: '{0}' (PID: {1}, 程序: {2})",
                                                p.MainWindowTitle, p.Id, p.ProcessName);
                                    }
                                }
                                else if (string.IsNullOrEmpty(detectedReason))
                                {
                                    detectedReason = string.Format("主視窗標題符合同意書特徵: '{0}' (PID: {1}, 程序: {2})",
                                        p.MainWindowTitle, p.Id, p.ProcessName);
                                }
                            }
                        }
                        catch { }
                        finally
                        {
                            try { p.Dispose(); } catch { }
                        }
                    }
                }
                catch { }
            }

            result.Detected = detected;
            result.IsNew = isNew;
            result.Reason = isNew ? newReason : detectedReason;
            return result;
        }

        private static void StopConsentProcesses(Process[] procs, int waitSec)
        {
            foreach (Process p in procs)
            {
                try
                {
                    if (p.HasExited) continue;
                    int pid = p.Id;
                    Log("ACTION", string.Format("發送視窗關閉指令 (WM_CLOSE) 至 {0}.exe (PID: {1})...", _config.ProcessName, pid));
                    p.CloseMainWindow();

                    double waited = 0.0;
                    while (!p.HasExited && waited < waitSec)
                    {
                        Thread.Sleep(500);
                        waited += 0.5;
                        p.Refresh();
                    }

                    if (!p.HasExited)
                    {
                        Log("WARN", string.Format("{0}.exe (PID: {1}) 未在 {2} 秒內退出，執行強制終止...", _config.ProcessName, pid, waitSec));
                        p.Kill();
                        Log("SUCCESS", string.Format("{0}.exe (PID: {1}) 已強制終止完成。", _config.ProcessName, pid));
                    }
                    else
                    {
                        Log("SUCCESS", string.Format("{0}.exe (PID: {1}) 已優雅關閉完成。", _config.ProcessName, pid));
                    }
                }
                catch (Exception ex)
                {
                    Log("ERROR", string.Format("關閉 {0} 時發生例外: {1}", _config.ProcessName, ex.Message));
                }
                finally
                {
                    try { p.Dispose(); } catch { }
                }
            }
        }

        public static void Log(string level, string message)
        {
            string ts = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string line = string.Format("[{0}] [{1}] {2}", ts, level, message);

            lock (_logLock)
            {
                try
                {
                    if (File.Exists(_config.LogFile))
                    {
                        FileInfo fi = new FileInfo(_config.LogFile);
                        if (fi.Length > _config.MaxLogSizeBytes)
                        {
                            string bak = string.Format("{0}.{1}.bak", _config.LogFile, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                            try { File.Move(_config.LogFile, bak); } catch { }
                        }
                    }
                    File.AppendAllText(_config.LogFile, line + Environment.NewLine, Encoding.UTF8);
                }
                catch { }

                if (_consoleAttached)
                {
                    try
                    {
                        ConsoleColor orig = Console.ForegroundColor;
                        if (level == "TRIGGER" || level == "REFRESH" || level == "COUNTDOWN")
                            Console.ForegroundColor = ConsoleColor.Yellow;
                        else if (level == "SUCCESS")
                            Console.ForegroundColor = ConsoleColor.Green;
                        else if (level == "ERROR" || level == "TIMEOUT")
                            Console.ForegroundColor = ConsoleColor.Red;
                        else if (level == "ACTION")
                            Console.ForegroundColor = ConsoleColor.Magenta;
                        else if (level == "DETECT" || level == "INFO")
                            Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine(line);
                        Console.ForegroundColor = orig;
                    }
                    catch
                    {
                        _consoleAttached = false;
                    }
                }
            }
        }

        private static void TrimMemory()
        {
            try
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1);
            }
            catch { }
        }

        private static void StopExistingInstances()
        {
            int myPid = Process.GetCurrentProcess().Id;
            Process[] all = Process.GetProcesses();
            int stopped = 0;
            foreach (var p in all)
            {
                try
                {
                    if (p.Id != myPid && string.Equals(p.ProcessName, "ConsentFormAutoCloser", StringComparison.OrdinalIgnoreCase))
                    {
                        p.Kill();
                        stopped++;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(string.Format("[成功] 已停止監控程序 ConsentFormAutoCloser.exe (PID: {0})", p.Id));
                        Console.ResetColor();
                    }
                }
                catch { }
                finally
                {
                    try { p.Dispose(); } catch { }
                }
            }
            if (stopped == 0)
            {
                Console.WriteLine("[資訊] 目前沒有執行中的 ConsentFormAutoCloser.exe 程序。");
            }
        }

        private static void ShowStatus()
        {
            Console.WriteLine("============================================================");
            Console.WriteLine("   KMUGH ConsentForm 自動關閉監控系統 - 狀態檢查 (原生 WinExe)");
            Console.WriteLine("============================================================");

            // 1. 監控程序狀態
            int myPid = Process.GetCurrentProcess().Id;
            Process[] all = Process.GetProcessesByName("ConsentFormAutoCloser");
            List<Process> closers = new List<Process>();
            foreach (var p in all)
            {
                if (p.Id != myPid)
                {
                    closers.Add(p);
                }
                else
                {
                    try { p.Dispose(); } catch { }
                }
            }

            if (closers.Count > 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("[監控狀態] 正在背景執行中 (NORMAL)");
                Console.ResetColor();
                foreach (var p in closers)
                {
                    try
                    {
                        double wsMB = Math.Round((double)p.WorkingSet64 / (1024 * 1024), 1);
                        Console.WriteLine(string.Format("  - PID: {0} | 記憶體: {1} MB | 啟動時間: {2}", p.Id, wsMB, p.StartTime));
                    }
                    catch { }
                    finally { try { p.Dispose(); } catch { } }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("[監控狀態] 未在執行中 (STOPPED)");
                Console.ResetColor();
                Console.WriteLine("  (可執行 Start-Background.bat 或點擊桌面【啟動】捷徑啟動背景監控)");
            }

            Console.WriteLine();

            // 2. ConsentForm.exe 狀態
            Process[] consents = Process.GetProcessesByName(_config.ProcessName);
            if (consents.Length > 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(string.Format("[同意書系統] 偵測到 {0}.exe 執行中 (RUNNING)", _config.ProcessName));
                Console.ResetColor();
                foreach (var cp in consents)
                {
                    try
                    {
                        Console.WriteLine(string.Format("  - PID: {0} | 視窗標題: {1}", cp.Id, cp.MainWindowTitle));
                    }
                    catch { }
                    finally { try { cp.Dispose(); } catch { } }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(string.Format("[同意書系統] {0}.exe 目前未開啟 (IDLE)", _config.ProcessName));
                Console.ResetColor();
            }

            Console.WriteLine();

            // 3. 伺服器連線狀態
            try
            {
                IPGlobalProperties props = IPGlobalProperties.GetIPGlobalProperties();
                TcpConnectionInformation[] conns = props.GetActiveTcpConnections();
                List<TcpConnectionInformation> active = new List<TcpConnectionInformation>();
                foreach (var c in conns)
                {
                    if (_targetIps.Contains(c.RemoteEndPoint.Address.ToString()))
                    {
                        active.Add(c);
                    }
                }
                if (active.Count > 0)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine(string.Format("[伺服器連線] 偵測到與 {0} 之活躍連線 (CONNECTED)", string.Join(", ", _targetIps.ToArray())));
                    Console.ResetColor();
                    foreach (var tc in active)
                    {
                        Console.WriteLine(string.Format("  - 本地埠: {0} -> 遠端: {1}:{2} ({3})",
                            tc.LocalEndPoint.Port, tc.RemoteEndPoint.Address, tc.RemoteEndPoint.Port, tc.State));
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(string.Format("[伺服器連線] 目前無活躍連線至 {0} (STANDBY)", string.Join(", ", _targetIps.ToArray())));
                    Console.ResetColor();
                }
            }
            catch
            {
                Console.WriteLine("[伺服器連線] 無法取得網路狀態。");
            }

            Console.WriteLine();

            // 4. 最近日誌 (最後 15 行)
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("------------------ 最近日誌 (" + Path.GetFileName(_config.LogFile) + ") ------------------");
            Console.ResetColor();

            if (File.Exists(_config.LogFile))
            {
                try
                {
                    string[] allLines = File.ReadAllLines(_config.LogFile, Encoding.UTF8);
                    int start = Math.Max(0, allLines.Length - 15);
                    for (int i = start; i < allLines.Length; i++)
                    {
                        string line = allLines[i];
                        if (line.Contains("TRIGGER") || line.Contains("REFRESH") || line.Contains("ACTION") || line.Contains("COUNTDOWN"))
                            Console.ForegroundColor = ConsoleColor.Yellow;
                        else if (line.Contains("SUCCESS"))
                            Console.ForegroundColor = ConsoleColor.Green;
                        else if (line.Contains("ERROR") || line.Contains("TIMEOUT") || line.Contains("WARN"))
                            Console.ForegroundColor = ConsoleColor.Red;
                        else
                            Console.ForegroundColor = ConsoleColor.Gray;

                        Console.WriteLine(line);
                        Console.ResetColor();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("讀取日誌失敗: " + ex.Message);
                }
            }
            else
            {
                Console.WriteLine("(尚無日誌檔案)");
            }

            Console.WriteLine("============================================================");
        }
    }
}
