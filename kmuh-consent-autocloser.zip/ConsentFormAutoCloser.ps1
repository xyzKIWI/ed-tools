﻿<#
.SYNOPSIS
    KMUGH 數位簽名同意書系統 (ConsentForm.exe) 自動關閉背景監控服務
.DESCRIPTION
    1. 當醫師開啟 ConsentForm.exe 時，完全保留勾選同意書、完成卡簽或開其他診斷書的作業時間，絕不提早關閉。
    2. 唯有在偵測到同意書網頁開啟 (連線至 svs.kmugh.org.tw / 10.122.120.6，或視窗標題包含 SelfieSign / signDoc) 時，才開始倒數 45 秒。
    3. 倒數期間若醫師開啟另一份同意書網頁，自動展延/重設倒數為 45 秒，避免中斷連續作業。
    4. 倒數 45 秒結束後，先送出優雅關閉 MainWindow 請求，若未關閉則強制終止，還原乾淨工作環境。
    5. 具備充裕的無網頁保底防呆機制 (預設 15 分鐘，可自訂或關閉)。
#>

[CmdletBinding()]
param(
    [int]$WebDelaySeconds,
    [int]$FallbackTimeoutSeconds,
    [string]$TargetHost,
    [string]$TargetIp,
    [string]$ProcessName,
    [switch]$Interactive,
    [string]$ConfigFile = "$PSScriptRoot\config.json"
)

# 載入設定檔預設值
$config = @{
    WebDelaySeconds           = 60
    FallbackTimeoutSeconds    = 300
    TargetHost                = "svs.kmugh.org.tw"
    TargetIp                  = "10.122.120.6"
    ProcessName               = "ConsentForm"
    CheckIntervalMilliseconds = 1000
    GracefulWaitSeconds       = 5
    LogFile                   = "$PSScriptRoot\closer.log"
    MaxLogSizeBytes           = 2097152
}

if (Test-Path $ConfigFile) {
    try {
        $json = Get-Content $ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($json.WebDelaySeconds) { $config.WebDelaySeconds = [int]$json.WebDelaySeconds }
        if ($json.FallbackTimeoutSeconds -ne $null) { $config.FallbackTimeoutSeconds = [int]$json.FallbackTimeoutSeconds }
        if ($json.TargetHost) { $config.TargetHost = [string]$json.TargetHost }
        if ($json.TargetIp) { $config.TargetIp = [string]$json.TargetIp }
        if ($json.ProcessName) { $config.ProcessName = [string]$json.ProcessName }
        if ($json.CheckIntervalMilliseconds) { $config.CheckIntervalMilliseconds = [int]$json.CheckIntervalMilliseconds }
        if ($json.GracefulWaitSeconds) { $config.GracefulWaitSeconds = [int]$json.GracefulWaitSeconds }
        if ($json.LogFile) {
            if ([System.IO.Path]::IsPathRooted($json.LogFile)) {
                $config.LogFile = $json.LogFile
            } else {
                $config.LogFile = Join-Path $PSScriptRoot $json.LogFile
            }
        }
        if ($json.MaxLogSizeBytes) { $config.MaxLogSizeBytes = [long]$json.MaxLogSizeBytes }
    } catch {
        Write-Warning "解析設定檔 $ConfigFile 失敗，使用預設值: $_"
    }
}

# 覆蓋參數
if ($PSBoundParameters.ContainsKey('WebDelaySeconds')) { $config.WebDelaySeconds = $WebDelaySeconds }
if ($PSBoundParameters.ContainsKey('FallbackTimeoutSeconds')) { $config.FallbackTimeoutSeconds = $FallbackTimeoutSeconds }
if ($PSBoundParameters.ContainsKey('TargetHost')) { $config.TargetHost = $TargetHost }
if ($PSBoundParameters.ContainsKey('TargetIp')) { $config.TargetIp = $TargetIp }
if ($PSBoundParameters.ContainsKey('ProcessName')) { $config.ProcessName = $ProcessName }

# 單一執行個體保護 (Mutex)
$mutexName = "ConsentFormAutoCloser_SingleInstance_Mutex"
$createdNew = $false
$mutex = $null
try {
    $mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
} catch {
    Write-Warning "建立 Mutex 失敗: $_"
}

if (-not $createdNew) {
    $msg = "[WARNING] ConsentFormAutoCloser 已經在執行中，跳過重複啟動。"
    if ($Interactive) { Write-Host $msg -ForegroundColor Yellow }
    exit 0
}

# 日誌函式
function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Level,
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Color = "White"
    )
    $ts = [DateTime]::Now.ToString("yyyy-MM-dd HH:mm:ss")
    $logLine = "[$ts] [$Level] $Message"

    # 檢查並循環日誌檔案
    try {
        if (Test-Path $config.LogFile) {
            $item = Get-Item $config.LogFile -ErrorAction SilentlyContinue
            if ($item -and $item.Length -gt $config.MaxLogSizeBytes) {
                $bak = "$($config.LogFile).$([DateTime]::Now.ToString('yyyyMMdd_HHmmss')).bak"
                Move-Item -Path $config.LogFile -Destination $bak -Force -ErrorAction SilentlyContinue
            }
        }
        [System.IO.File]::AppendAllText($config.LogFile, $logLine + [Environment]::NewLine, [System.Text.Encoding]::UTF8)
    } catch { }

    if ($Interactive) {
        Write-Host "[$ts] " -NoNewline -ForegroundColor DarkGray
        Write-Host "[$Level] " -NoNewline -ForegroundColor $Color
        Write-Host $Message -ForegroundColor $Color
    }
}

# 註冊 Win32 API 跨桌面視窗枚舉
$pinvokeCode = @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace KMUGH.ConsentHelper
{
    public class WindowHelper
    {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr OpenDesktop(string lpszDesktop, uint dwFlags, bool fInherit, uint dwDesiredAccess);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool CloseDesktop(IntPtr hDesktop);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool EnumDesktopWindows(IntPtr hDesktop, EnumWindowsProc lpfn, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder strText, int maxCount);

        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        public class WindowItem
        {
            public IntPtr Handle { get; set; }
            public uint ProcessId { get; set; }
            public string Title { get; set; }
        }

        public static List<WindowItem> GetDesktopWindows()
        {
            var list = new List<WindowItem>();
            IntPtr hDesk = OpenDesktop("Default", 0, false, 0x0100 | 0x0001);
            if (hDesk == IntPtr.Zero)
            {
                return list;
            }
            try
            {
                EnumDesktopWindows(hDesk, (hWnd, lParam) =>
                {
                    if (IsWindowVisible(hWnd))
                    {
                        int len = GetWindowTextLength(hWnd);
                        if (len > 0)
                        {
                            StringBuilder sb = new StringBuilder(len + 1);
                            GetWindowText(hWnd, sb, sb.Capacity);
                            uint pid;
                            GetWindowThreadProcessId(hWnd, out pid);
                            list.Add(new WindowItem { Handle = hWnd, ProcessId = pid, Title = sb.ToString() });
                        }
                    }
                    return true;
                }, IntPtr.Zero);
            }
            finally
            {
                CloseDesktop(hDesk);
            }
            return list;
        }
    }
}
'@

try {
    if (-not ([System.Management.Automation.PSTypeName]'KMUGH.ConsentHelper.WindowHelper').Type) {
        Add-Type -TypeDefinition $pinvokeCode -Language CSharp -ErrorAction Stop
    }
} catch {
    Write-Log "WARN" "註冊 Win32 視窗輔助元件失敗，將使用 Get-Process 備援方案: $_" "Yellow"
}

# 動態解析目標伺服器 IP
$targetIps = @($config.TargetIp)
try {
    $dnsAddrs = [System.Net.Dns]::GetHostAddresses($config.TargetHost)
    foreach ($addr in $dnsAddrs) {
        $ipStr = $addr.ToString()
        if ($ipStr -and -not ($targetIps -contains $ipStr)) {
            $targetIps += $ipStr
        }
    }
} catch { }

# 優雅與強制關閉函式
function Stop-ConsentProcess {
    param(
        [Parameter(Mandatory=$true)]$Procs,
        [int]$WaitSec = 5
    )
    foreach ($p in $Procs) {
        try {
            if ($p.HasExited) { continue }
            $pidVal = $p.Id
            Write-Log "ACTION" "發送視窗關閉指令 (WM_CLOSE) 至 $($config.ProcessName).exe (PID: $pidVal)..." "Magenta"
            [void]$p.CloseMainWindow()
            
            $waited = 0.0
            while (-not $p.HasExited -and $waited -lt $WaitSec) {
                Start-Sleep -Milliseconds 500
                $waited += 0.5
                $p.Refresh()
            }
            
            if (-not $p.HasExited) {
                Write-Log "WARN" "$($config.ProcessName).exe (PID: $pidVal) 未在 $WaitSec 秒內退出，執行強制終止..." "Yellow"
                Stop-Process -Id $pidVal -Force -ErrorAction SilentlyContinue
                Write-Log "SUCCESS" "$($config.ProcessName).exe (PID: $pidVal) 已強制終止完成。" "Green"
            } else {
                Write-Log "SUCCESS" "$($config.ProcessName).exe (PID: $pidVal) 已優雅關閉完成。" "Green"
            }
        } catch {
            Write-Log "ERROR" "關閉 $($config.ProcessName) 時發生例外: $_" "Red"
        }
    }
}

# 擷取歷史基線快照函式 (記錄視窗標題，支援同一視窗開新分頁展延)
function Get-ConsentBaseline {
    param([string[]]$Ips)
    $bPorts = New-Object 'System.Collections.Generic.HashSet[int]'
    $bWindows = @{} # [IntPtr] -> [string]Title

    try {
        $conns = Get-NetTCPConnection -RemoteAddress $Ips -ErrorAction SilentlyContinue |
                 Where-Object { $_.State -in 'Established', 'SynSent' }
        if ($conns) {
            foreach ($c in $conns) {
                [void]$bPorts.Add($c.LocalPort)
            }
        }
    } catch { }

    try {
        if (([System.Management.Automation.PSTypeName]'KMUGH.ConsentHelper.WindowHelper').Type) {
            $windows = [KMUGH.ConsentHelper.WindowHelper]::GetDesktopWindows()
            foreach ($w in $windows) {
                if ($w.Title -match 'SelfieSign|signDoc') {
                    $bWindows[$w.Handle] = $w.Title
                }
            }
        }
    } catch { }

    return [PSCustomObject]@{
        Ports = $bPorts
        Windows = $bWindows
    }
}

# 網頁開啟偵測函式
function Test-ConsentWebOpened {
    param(
        [string[]]$Ips,
        [System.Collections.Generic.HashSet[int]]$BaselinePorts,
        [hashtable]$BaselineWindows,
        [System.Collections.Generic.HashSet[int]]$KnownPorts,
        [hashtable]$KnownWindows
    )
    $det = [PSCustomObject]@{
        Detected = $false
        IsNew = $false
        Reason = ""
    }
    $detected = $false
    $isNew = $false
    $detectedReason = ""
    $newReason = ""

    # 1. TCP 連線偵測 (僅限 Established / SynSent，排除歷史基線)
    try {
        $conns = Get-NetTCPConnection -RemoteAddress $Ips -ErrorAction SilentlyContinue |
                 Where-Object { $_.State -in 'Established', 'SynSent' }
        if ($conns) {
            foreach ($c in $conns) {
                $port = $c.LocalPort
                if ($null -ne $BaselinePorts -and $BaselinePorts.Contains($port)) {
                    continue # 歷史既存連線，忽略
                }

                $detected = $true
                if ($null -ne $KnownPorts -and -not $KnownPorts.Contains($port)) {
                    $isNew = $true
                    [void]$KnownPorts.Add($port)
                    if (-not $newReason) {
                        $newReason = "網路連線至同意書伺服器 $($c.RemoteAddress):$($c.RemotePort) (本地埠: $port, 狀態: $($c.State))"
                    }
                } elseif (-not $detectedReason) {
                    $detectedReason = "網路連線至同意書伺服器 $($c.RemoteAddress):$($c.RemotePort) (本地埠: $port, 狀態: $($c.State))"
                }
            }
        }
    } catch { }

    # 2. 視窗標題偵測 (包含 SelfieSign 或 signDoc，支援同視窗新分頁展延)
    try {
        if (([System.Management.Automation.PSTypeName]'KMUGH.ConsentHelper.WindowHelper').Type) {
            $windows = [KMUGH.ConsentHelper.WindowHelper]::GetDesktopWindows()
            foreach ($w in $windows) {
                if ($w.Title -match 'SelfieSign|signDoc') {
                    # 若此視窗在 ConsentForm 開啟前就存在，且標題完全沒變，才視為歷史視窗忽略
                    if ($null -ne $BaselineWindows -and $BaselineWindows.ContainsKey($w.Handle) -and $BaselineWindows[$w.Handle] -eq $w.Title) {
                        continue
                    }

                    $detected = $true
                    $isTitleChanged = $KnownWindows.ContainsKey($w.Handle) -and $KnownWindows[$w.Handle] -ne $w.Title
                    $isNewWindow = -not $KnownWindows.ContainsKey($w.Handle)

                    if ($isNewWindow -or $isTitleChanged) {
                        $KnownWindows[$w.Handle] = $w.Title
                        $isNew = $true
                        if (-not $newReason) {
                            $newReason = if ($isTitleChanged) {
                                "同一瀏覽器視窗載入新同意書分頁: '$($w.Title)' (PID: $($w.ProcessId))"
                            } else {
                                "桌面視窗標題符合同意書特徵: '$($w.Title)' (PID: $($w.ProcessId))"
                            }
                        }
                    } elseif (-not $detectedReason) {
                        $detectedReason = "桌面視窗標題符合同意書特徵: '$($w.Title)' (PID: $($w.ProcessId))"
                    }
                }
            }
        }
    } catch { }

    # 3. 備援：Get-Process 視窗標題偵測 (支援排除歷史視窗與展延判定)
    if (-not $detected) {
        try {
            $procs = Get-Process -ErrorAction SilentlyContinue |
                     Where-Object { $_.MainWindowTitle -match 'SelfieSign|signDoc' }
            foreach ($p in $procs) {
                if ($null -ne $BaselineWindows -and $BaselineWindows.ContainsKey($p.MainWindowHandle) -and $BaselineWindows[$p.MainWindowHandle] -eq $p.MainWindowTitle) {
                    continue
                }

                $detected = $true
                $isTitleChanged = $KnownWindows.ContainsKey($p.MainWindowHandle) -and $KnownWindows[$p.MainWindowHandle] -ne $p.MainWindowTitle
                $isNewWindow = -not $KnownWindows.ContainsKey($p.MainWindowHandle)

                if ($isNewWindow -or $isTitleChanged) {
                    $KnownWindows[$p.MainWindowHandle] = $p.MainWindowTitle
                    $isNew = $true
                    if (-not $newReason) {
                        $newReason = if ($isTitleChanged) {
                            "同一主視窗載入新同意書分頁: '$($p.MainWindowTitle)' (PID: $($p.Id), 程序: $($p.ProcessName))"
                        } else {
                            "主視窗標題符合同意書特徵: '$($p.MainWindowTitle)' (PID: $($p.Id), 程序: $($p.ProcessName))"
                        }
                    }
                } elseif (-not $detectedReason) {
                    $detectedReason = "主視窗標題符合同意書特徵: '$($p.MainWindowTitle)' (PID: $($p.Id), 程序: $($p.ProcessName))"
                }
            }
        } catch { }
    }

    $det.Detected = $detected
    $det.IsNew = $isNew
    $det.Reason = if ($isNew) { $newReason } else { $detectedReason }
    return $det
}

# 狀態管理
$standbyPorts = New-Object 'System.Collections.Generic.HashSet[int]'
$standbyWindows = @{}

$baselinePorts = New-Object 'System.Collections.Generic.HashSet[int]'
$baselineWindows = @{}
$knownPorts = New-Object 'System.Collections.Generic.HashSet[int]'
$knownWindows = @{} # [IntPtr] -> [string]Title

$hasLoggedStart = $false
$lastConsentProcs = @()
$consentStartTime = $null
$countdownEndTime = $null
$webTriggerTime = $null
$lastLoggedSecond = -1

Write-Log "INFO" "=== KMUGH ConsentForm 自動關閉監控服務已啟動 ===" "Cyan"
Write-Log "INFO" "設定參數: 網頁觸發倒數=$($config.WebDelaySeconds)秒, 無網頁保底=$($config.FallbackTimeoutSeconds)秒, 目標伺服器=$($config.TargetHost) ($($targetIps -join ', '))" "Cyan"

try {
    while ($true) {
        $procs = @(Get-Process -Name $config.ProcessName -ErrorAction SilentlyContinue)
        
        if ($procs.Count -eq 0) {
            # ConsentForm 未開啟，處於待命狀態
            if ($lastConsentProcs.Count -gt 0) {
                Write-Log "INFO" "$($config.ProcessName).exe 已關閉，重設監控待命狀態。" "DarkGray"
                $baselinePorts.Clear()
                $baselineWindows.Clear()
                $knownPorts.Clear()
                $knownWindows.Clear()
                $consentStartTime = $null
                $countdownEndTime = $null
                $webTriggerTime = $null
                $lastLoggedSecond = -1
                $hasLoggedStart = $false
                if ($Interactive) { Write-Host "" }
            }
            $lastConsentProcs = @()

            # 待命期間每輪維護前置基線 (ConsentForm 開啟前最後一刻之快照)
            $st = Get-ConsentBaseline -Ips $targetIps
            $standbyPorts = $st.Ports
            $standbyWindows = $st.Windows

            Start-Sleep -Milliseconds $config.CheckIntervalMilliseconds
            continue
        }

        # 偵測到 ConsentForm.exe 執行中
        $lastConsentProcs = $procs
        if (-not $hasLoggedStart) {
            $pids = ($procs | ForEach-Object { $_.Id }) -join ', '
            Write-Log "DETECT" "偵測到 $($config.ProcessName).exe 執行中 (PID: $pids)。" "Cyan"

            # 使用程式開啟前一刻的待命快照作為基線，絕不漏抓與程式同步開啟的新網頁
            $baselinePorts = New-Object 'System.Collections.Generic.HashSet[int]' ($standbyPorts)
            $baselineWindows = $standbyWindows.Clone()
            $knownPorts.Clear()
            $knownWindows.Clear()
            if ($baselinePorts.Count -gt 0 -or $baselineWindows.Count -gt 0) {
                Write-Log "INFO" "已載入前置歷史快照 (視窗: $($baselineWindows.Count) 個, 連線: $($baselinePorts.Count) 個)，歷史分頁將不會誤觸發關閉。" "DarkGray"
            }

            Write-Log "INFO" "保留醫師勾選同意書、完成卡簽或開其他診斷書作業時間，等待開啟簽名網頁..." "Cyan"
            $consentStartTime = [DateTime]::Now
            $countdownEndTime = $null
            $webTriggerTime = $null
            $lastLoggedSecond = -1
            $hasLoggedStart = $true
        }

        # 檢查同意書網頁 (SelfieSign / svs) 是否開啟 (支援同一視窗開新分頁標題變化展延)
        $det = Test-ConsentWebOpened -Ips $targetIps -BaselinePorts $baselinePorts -BaselineWindows $baselineWindows -KnownPorts $knownPorts -KnownWindows $knownWindows

        if ($det.Detected) {
            # 情況 1：尚未開始倒數，首次偵測到網頁開啟
            if ($countdownEndTime -eq $null) {
                $countdownEndTime = [DateTime]::Now.AddSeconds($config.WebDelaySeconds)
                $webTriggerTime = [DateTime]::Now
                $lastLoggedSecond = -1
                Write-Log "TRIGGER" "【網頁開啟觸發】$($det.Reason)" "Yellow"
                Write-Log "TRIGGER" "開始執行 $($config.WebDelaySeconds) 秒關閉倒數 (保留最後簽名與作業時間)..." "Yellow"
            }
            # 情況 2：倒數進行中，又偵測到開啟新的同意書/連線
            elseif ($det.IsNew) {
                $countdownEndTime = [DateTime]::Now.AddSeconds($config.WebDelaySeconds)
                $lastLoggedSecond = -1
                Write-Log "REFRESH" "【偵測到新同意書連線/視窗】重設倒數為 $($config.WebDelaySeconds) 秒！" "Yellow"
            }
        }

        # 處理倒數計時 (依據真實系統時間戳判定)
        if ($countdownEndTime -ne $null) {
            $remainingExact = ($countdownEndTime - [DateTime]::Now).TotalSeconds
            $remainingSeconds = [math]::Ceiling($remainingExact)

            if ($remainingSeconds -gt 0) {
                if ($remainingSeconds -ne $lastLoggedSecond) {
                    $lastLoggedSecond = $remainingSeconds
                    if ($Interactive) {
                        Write-Host "`r[COUNTDOWN] 同意書網頁已開啟，將於 $remainingSeconds 秒後自動關閉 $($config.ProcessName).exe... " -NoNewline -ForegroundColor Yellow
                    }
                    if ($remainingSeconds % 15 -eq 0 -or $remainingSeconds -le 5) {
                        Write-Log "COUNTDOWN" "剩餘 $remainingSeconds 秒自動關閉 $($config.ProcessName).exe..." "Yellow"
                    }
                }
            } else {
                if ($Interactive) { Write-Host "" }
                Write-Log "ACTION" "倒數 $($config.WebDelaySeconds) 秒已結束，執行自動關閉 $($config.ProcessName).exe..." "Magenta"
                Stop-ConsentProcess -Procs $procs -WaitSec $config.GracefulWaitSeconds
                $countdownEndTime = $null
                $lastLoggedSecond = -1
                $hasLoggedStart = $false
                $knownPorts.Clear()
                $knownWindows.Clear()
            }
        }
        # 無網頁開啟之保底機制
        elseif ($config.FallbackTimeoutSeconds -gt 0 -and $consentStartTime -ne $null) {
            $elapsed = ([DateTime]::Now - $consentStartTime).TotalSeconds
            if ($elapsed -ge $config.FallbackTimeoutSeconds) {
                if ($Interactive) { Write-Host "" }
                Write-Log "TIMEOUT" "ConsentForm.exe 開啟已滿保底時間 $($config.FallbackTimeoutSeconds) 秒且未偵測到簽名網頁，執行保底關閉。" "Red"
                Stop-ConsentProcess -Procs $procs -WaitSec $config.GracefulWaitSeconds
                $countdownEndTime = $null
                $lastLoggedSecond = -1
                $hasLoggedStart = $false
                $knownPorts.Clear()
                $knownWindows.Clear()
            }
        }

        Start-Sleep -Milliseconds $config.CheckIntervalMilliseconds
    }
}
finally {
    if ($mutex) {
        try { [void]$mutex.ReleaseMutex() } catch { }
        $mutex.Dispose()
    }
    Write-Log "INFO" "ConsentForm 自動關閉監控服務已結束。" "DarkGray"
}
