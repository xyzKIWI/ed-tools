﻿<#
.SYNOPSIS
    KMUGH ConsentForm 自動關閉監控系統 - 狀態檢查腳本
#>

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   KMUGH ConsentForm 自動關閉監控系統 - 狀態檢查" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# 1. 監控程序狀態
$monProcs = Get-CimInstance Win32_Process | Where-Object {
    ($_.CommandLine -like '*ConsentFormAutoCloser.ps1*' -and $_.ProcessId -ne $PID) -or
    ($_.Name -eq 'ConsentFormAutoCloser.exe' -and $_.ProcessId -ne $PID)
}
if ($monProcs) {
    Write-Host "[監控狀態] 正在背景執行中 (NORMAL)" -ForegroundColor Green
    foreach ($m in $monProcs) {
        $p = Get-Process -Id $m.ProcessId -ErrorAction SilentlyContinue
        $wsMB = if ($p) { [math]::Round($p.WorkingSet64 / 1MB, 1) } else { 0 }
        Write-Host "  - PID: $($m.ProcessId) | 記憶體: $wsMB MB | 啟動時間: $($m.CreationDate)" -ForegroundColor Gray
    }
} else {
    Write-Host "[監控狀態] 未在執行中 (STOPPED)" -ForegroundColor Yellow
    Write-Host "  (可執行 Start-Background.bat 啟動背景監控)" -ForegroundColor DarkGray
}

Write-Host ""
# 2. ConsentForm.exe 狀態
$cProcs = Get-Process -Name ConsentForm -ErrorAction SilentlyContinue
if ($cProcs) {
    Write-Host "[同意書系統] 偵測到 ConsentForm.exe 執行中 (RUNNING)" -ForegroundColor Yellow
    foreach ($cp in $cProcs) {
        Write-Host "  - PID: $($cp.Id) | 視窗標題: $($cp.MainWindowTitle)" -ForegroundColor Gray
    }
} else {
    Write-Host "[同意書系統] ConsentForm.exe 目前未開啟 (IDLE)" -ForegroundColor Green
}

Write-Host ""
# 3. 同意書伺服器連線狀態 (svs.kmugh.org.tw / 10.122.120.6)
$tcpConns = Get-NetTCPConnection -RemoteAddress 10.122.120.6 -ErrorAction SilentlyContinue
if ($tcpConns) {
    Write-Host "[伺服器連線] 偵測到與 10.122.120.6 之活躍連線 (CONNECTED)" -ForegroundColor Yellow
    foreach ($tc in $tcpConns) {
        Write-Host "  - 本地埠: $($tc.LocalPort) -> 遠端: $($tc.RemoteAddress):$($tc.RemotePort) ($($tc.State))" -ForegroundColor Gray
    }
} else {
    Write-Host "[伺服器連線] 目前無活躍連線至 10.122.120.6 (STANDBY)" -ForegroundColor Green
}

Write-Host ""
# 4. 最近日誌 (最後 15 行)
Write-Host "------------------ 最近日誌 (closer.log) ------------------" -ForegroundColor DarkCyan
$logPath = Join-Path $PSScriptRoot 'closer.log'
if (Test-Path $logPath) {
    Get-Content $logPath -Tail 15 -Encoding UTF8 | ForEach-Object {
        if ($_ -match 'TRIGGER|REFRESH|ACTION') {
            Write-Host $_ -ForegroundColor Yellow
        } elseif ($_ -match 'SUCCESS') {
            Write-Host $_ -ForegroundColor Green
        } elseif ($_ -match 'ERROR|TIMEOUT') {
            Write-Host $_ -ForegroundColor Red
        } else {
            Write-Host $_ -ForegroundColor Gray
        }
    }
} else {
    Write-Host "(尚無日誌檔案)" -ForegroundColor DarkGray
}
Write-Host "============================================================" -ForegroundColor Cyan
