@echo off
chcp 65001 >nul
cd /d "%~dp0"
title KMUGH ConsentForm 監控日誌
echo ============================================================
echo   KMUGH ConsentForm 監控日誌檢視器
echo   [1] 即時追蹤模式 (Live Stream, 按 Ctrl+C 退出)
echo   [2] 使用 記事本 (Notepad) 開啟完整記錄
echo ============================================================
set /p opt="請選擇模式 [預設 1]: "
if "%opt%"=="2" (
    start notepad.exe "%~dp0closer.log"
    exit /b
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0View-Log.ps1"
echo.
pause
