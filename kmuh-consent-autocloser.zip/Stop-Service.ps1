﻿<#
.SYNOPSIS
    停止 KMUGH ConsentFormAutoCloser 背景監控服務
#>

Write-Host "[資訊] 正在停止 KMUGH ConsentForm 自動關閉背景監控..." -ForegroundColor Cyan

$procs = Get-CimInstance Win32_Process | Where-Object {
    ($_.CommandLine -like '*ConsentFormAutoCloser.ps1*' -and $_.ProcessId -ne $PID) -or
    ($_.Name -eq 'ConsentFormAutoCloser.exe')
}

if ($procs) {
    foreach ($p in $procs) {
        try {
            Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
            Write-Host "[成功] 已停止監控程序 (PID: $($p.ProcessId))" -ForegroundColor Green
        } catch {
            Write-Host "[失敗] 無法停止 PID $($p.ProcessId): $_" -ForegroundColor Red
        }
    }
} else {
    Write-Host "[資訊] 目前沒有執行中的 ConsentFormAutoCloser 監控程序。" -ForegroundColor Cyan
}
