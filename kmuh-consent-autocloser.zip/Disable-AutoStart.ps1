﻿<#
.SYNOPSIS
    一鍵停用開機自動啟動 (自 Windows 啟動資料夾移除)
#>

$startup = [Environment]::GetFolderPath('Startup')
$lnkPath = Join-Path $startup "KMUGH ConsentForm AutoCloser.lnk"

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   KMUGH ConsentFormAutoCloser 開機自啟設定" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

if (Test-Path $lnkPath) {
    Remove-Item $lnkPath -Force -ErrorAction SilentlyContinue
    Write-Host "[成功] 已停用開機自動啟動 (已自啟動資料夾移除)。" -ForegroundColor Yellow
} else {
    Write-Host "[資訊] 目前未設定開機自動啟動。" -ForegroundColor DarkGray
}
Write-Host "============================================================" -ForegroundColor Cyan
