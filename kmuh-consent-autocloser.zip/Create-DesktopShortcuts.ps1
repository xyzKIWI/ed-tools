﻿param(
    [string]$TargetDir = $PSScriptRoot
)

$desktop = [Environment]::GetFolderPath("Desktop")
if (-not $TargetDir) { $TargetDir = "C:\Users\User\.gemini\antigravity\scratch\ConsentFormAutoCloser" }

$ws = New-Object -ComObject WScript.Shell

# Remove obsolete shortcuts
$obsolete = Join-Path $desktop "同意書自動關閉工具.lnk"
if (Test-Path $obsolete) {
    Remove-Item $obsolete -Force -ErrorAction SilentlyContinue
    Write-Host "已移除過期捷徑: 同意書自動關閉工具.lnk" -ForegroundColor DarkGray
}

$exePath = Join-Path $TargetDir "ConsentFormAutoCloser.exe"
$startTarget = if (Test-Path $exePath) { $exePath } else { Join-Path $TargetDir "Start-Background.bat" }

$shortcuts = @(
    @{
        Name = "【啟動】同意書自動關閉"
        Target = $startTarget
        Icon = if (Test-Path $exePath) { "$exePath,0" } else { "shell32.dll,24" }
        Desc = "啟動 KMUGH 數位簽名同意書自動關閉背景監控"
    },
    @{
        Name = "【狀態】同意書自動關閉"
        Target = Join-Path $TargetDir "Check-Status.bat"
        Icon = "shell32.dll,277"
        Desc = "檢查 ConsentForm 自動關閉狀態與最近日誌"
    },
    @{
        Name = "【停止】同意書自動關閉"
        Target = Join-Path $TargetDir "Stop-Service.bat"
        Icon = "shell32.dll,131"
        Desc = "停止 ConsentForm 自動關閉背景監控"
    }
)

foreach ($s in $shortcuts) {
    $lnkPath = Join-Path $desktop "$($s.Name).lnk"
    $lnk = $ws.CreateShortcut($lnkPath)
    $lnk.TargetPath = $s.Target
    $lnk.WorkingDirectory = $TargetDir
    $lnk.Description = $s.Desc
    $lnk.IconLocation = $s.Icon
    $lnk.Save()
    Write-Host "已建立桌面捷徑: $($s.Name) -> $($s.Target)" -ForegroundColor Green
}
