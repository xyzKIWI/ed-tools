/* CXR 重新標註：純函式。頁面腳本與 Node 測試共用，不碰 DOM、不碰 chrome.*。 */
(function (root) {
  'use strict';

  // 類別名稱沿用既有 LabelMe 資料集的寫法（小寫 *_fx、lung_infil）。
  // main: true ＝ 目前部署的 7 類；false ＝ 資料集有、但目前模型沒在用的類別。
  const CLASSES = [
    { name: 'rib_fx', zh: '肋骨骨折', color: '#ff5252', main: true },
    { name: 'cla_fx', zh: '鎖骨骨折', color: '#ffb300', main: true },
    { name: 'hum_fx', zh: '肱骨骨折', color: '#ff7043', main: true },
    { name: 'sca_fx', zh: '肩胛骨骨折', color: '#ec407a', main: true },
    { name: 'occ_fx', zh: '隱性骨折', color: '#ba68c8', main: true },
    { name: 'old_fx', zh: '陳舊骨折', color: '#bcaaa4', main: true },
    { name: 'lung_infil', zh: '肺浸潤', color: '#29b6f6', main: true },
    { name: 'PTX', zh: '氣胸', color: '#7986cb', main: false },
    { name: 'PLE', zh: '肋膜積液', color: '#26a69a', main: false },
    { name: 'SCE', zh: '皮下氣腫', color: '#d4e157', main: false },
  ];
  const CLASS_NAMES = CLASSES.map((c) => c.name);

  /** 把模型輸出的類別（例如 LUNG_INFIL）對到資料集的寫法；對不到回傳 ''。 */
  function normalizeLabel(raw) {
    const k = String(raw || '').trim().toLowerCase();
    const hit = CLASSES.find((c) => c.name.toLowerCase() === k);
    return hit ? hit.name : '';
  }

  /** 解析結果頁的「Class:XXX Score:0.71」文字，可以有很多組。 */
  function parseDetections(text) {
    const out = [];
    const re = /Class\s*[:：]\s*([A-Za-z_]+)\s*Score\s*[:：]\s*([0-9.]+)/g;
    let m;
    while ((m = re.exec(String(text || '')))) out.push({ class: m[1], score: Number(m[2]) });
    return out;
  }

  /**
   * 從影像像素找出「畫在影像上的彩色框」。
   * X 光是灰階，飽和度高的像素一定是後來畫上去的；框的上下邊是長的水平線，
   * 文字筆畫很短，所以只認長度 >= minRun 的水平線，再配成上下一對並檢查左右邊。
   * data ＝ RGBA 位元組（canvas getImageData().data）。
   * 回傳 [{x1,y1,x2,y2}]，座標是影像像素、取線條中心。
   */
  function findOverlayBoxes(data, width, height, opts) {
    const o = Object.assign(
      { minRun: 24, saturation: 100, minBright: 150, tol: 4, minSide: 12, maxThick: 12, edgeFill: 0.8 },
      opts
    );
    const n = width * height;
    const ov = new Uint8Array(n);
    for (let p = 0, i = 0; p < n; p++, i += 4) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const mx = r > g ? (r > b ? r : b) : g > b ? g : b;
      const mn = r < g ? (r < b ? r : b) : g < b ? g : b;
      if (mx - mn > o.saturation && mx > o.minBright) ov[p] = 1;
    }

    // 1) 每一列找長的水平線段，上下相鄰且左右端一致的併成一條「線」
    const lines = [];
    for (let y = 0; y < height; y++) {
      const row = y * width;
      let x = 0;
      while (x < width) {
        if (!ov[row + x]) { x++; continue; }
        const s = x;
        while (x < width && ov[row + x]) x++;
        const e = x - 1;
        if (e - s + 1 < o.minRun) continue;
        let hit = null;
        for (let k = lines.length - 1; k >= 0; k--) {
          const l = lines[k];
          if (l.y2 < y - 1) continue;
          if (l.y2 === y - 1 && Math.abs(l.x1 - s) <= o.tol && Math.abs(l.x2 - e) <= o.tol) { hit = l; break; }
        }
        if (hit) hit.y2 = y;
        else lines.push({ x1: s, x2: e, y1: y, y2: y, used: false });
      }
    }

    // 2) 檢查某一欄附近、上下兩條線之間，是不是幾乎每一列都有彩色像素（＝直的邊）
    const columnFilled = (xa, xb, ya, yb) => {
      const lo = Math.max(0, xa), hi = Math.min(width - 1, xb);
      let rows = 0, hitRows = 0;
      for (let y = ya; y <= yb; y++) {
        rows++;
        const row = y * width;
        for (let x = lo; x <= hi; x++) if (ov[row + x]) { hitRows++; break; }
      }
      return rows > 0 && hitRows / rows >= o.edgeFill;
    };

    // 3) 上邊配最近的下邊
    const boxes = [];
    const cand = lines.filter((l) => l.y2 - l.y1 + 1 <= o.maxThick).sort((a, b) => a.y1 - b.y1);
    for (let i = 0; i < cand.length; i++) {
      const top = cand[i];
      if (top.used) continue;
      for (let j = i + 1; j < cand.length; j++) {
        const bot = cand[j];
        if (bot.used) continue;
        if (bot.y1 - top.y2 < o.minSide) continue;
        if (Math.abs(top.x1 - bot.x1) > o.tol * 2 || Math.abs(top.x2 - bot.x2) > o.tol * 2) continue;
        const t = top.y2 - top.y1 + 1;
        const xl = Math.min(top.x1, bot.x1), xr = Math.max(top.x2, bot.x2);
        const ya = top.y2 + 1, yb = bot.y1 - 1;
        if (!columnFilled(xl - 1, xl + t + 1, ya, yb)) continue;
        if (!columnFilled(xr - t - 1, xr + 1, ya, yb)) continue;
        top.used = bot.used = true;
        boxes.push({ x1: xl + t / 2, y1: top.y1 + t / 2, x2: xr + 1 - t / 2, y2: bot.y2 + 1 - t / 2 });
        break;
      }
    }
    return boxes;
  }

  /**
   * 把畫在影像上的彩色框與字抹掉：彩色像素（往外多擴 grow 圈，蓋住邊緣的殘色）
   * 用周圍的灰階像素由外往內一圈一圈補回去，最後再抹平幾次；其餘帶一點顏色的像素轉回灰階。
   * 補的是「估計值」，不是原圖；線條只有幾個像素寬，補完肉眼幾乎看不出來。
   * 只在影像上真的有畫東西（有明顯彩色像素）時才會動；否則原樣回傳。
   * 回傳 { data: 新的 RGBA（不動原資料）, repaired: 被補的像素數 }。
   */
  function removeOverlay(data, width, height, opts) {
    const o = Object.assign({ chroma: 40, grow: 2, smooth: 6 }, opts);
    const n = width * height;
    const out = new Uint8ClampedArray(data);
    let mask = new Uint8Array(n);
    let any = 0;
    for (let p = 0, i = 0; p < n; p++, i += 4) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const mx = r > g ? (r > b ? r : b) : g > b ? g : b;
      const mn = r < g ? (r < b ? r : b) : g < b ? g : b;
      if (mx - mn > o.chroma) { mask[p] = 1; any++; }
    }
    if (!any) return { data: out, repaired: 0 };

    for (let k = 0; k < o.grow; k++) {
      const m2 = new Uint8Array(mask);
      for (let y = 0; y < height; y++)
        for (let x = 0; x < width; x++) {
          if (!mask[y * width + x]) continue;
          for (let dy = -1; dy <= 1; dy++)
            for (let dx = -1; dx <= 1; dx++) {
              const nx = x + dx, ny = y + dy;
              if (nx >= 0 && ny >= 0 && nx < width && ny < height) m2[ny * width + nx] = 1;
            }
        }
      mask = m2;
    }

    // 沒被遮到的像素：取亮度當已知值。線條附近常有一圈壓縮造成的淡淡色暈，
    // 顏色跑掉但亮度大致還在，所以直接轉回灰階就好，不必用猜的。
    const val = new Float32Array(n);
    const known = new Uint8Array(n);
    let todo = [];
    for (let p = 0, i = 0; p < n; p++, i += 4) {
      if (mask[p]) { todo.push(p); continue; }
      const r = data[i], g = data[i + 1], b = data[i + 2];
      val[p] = 0.299 * r + 0.587 * g + 0.114 * b;
      known[p] = 1;
      if (r !== g || g !== b) { const v = Math.round(val[p]); out[i] = out[i + 1] = out[i + 2] = v; }
    }
    const NB = [[-1, 0, 1], [1, 0, 1], [0, -1, 1], [0, 1, 1], [-1, -1, 0.7], [1, -1, 0.7], [-1, 1, 0.7], [1, 1, 0.7]];
    const filled = [];
    while (todo.length) {
      const next = [], done = [], vals = [];
      for (const p of todo) {
        const x = p % width, y = (p - x) / width;
        let s = 0, w = 0;
        for (const [dx, dy, wt] of NB) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
          const q = ny * width + nx;
          if (known[q]) { s += val[q] * wt; w += wt; }
        }
        if (w > 0) { done.push(p); vals.push(s / w); } else next.push(p);
      }
      if (!done.length) break; // 四周完全沒有可參考的像素（整張都是彩色），補不了
      for (let k = 0; k < done.length; k++) { val[done[k]] = vals[k]; known[done[k]] = 1; filled.push(done[k]); }
      todo = next;
    }

    for (let it = 0; it < o.smooth; it++) {
      const nv = new Float32Array(filled.length);
      for (let k = 0; k < filled.length; k++) {
        const p = filled[k], x = p % width, y = (p - x) / width;
        let s = 0, w = 0;
        if (x > 0 && known[p - 1]) { s += val[p - 1]; w++; }
        if (x < width - 1 && known[p + 1]) { s += val[p + 1]; w++; }
        if (y > 0 && known[p - width]) { s += val[p - width]; w++; }
        if (y < height - 1 && known[p + width]) { s += val[p + width]; w++; }
        nv[k] = w ? s / w : val[p];
      }
      for (let k = 0; k < filled.length; k++) val[filled[k]] = nv[k];
    }
    for (const p of filled) { const i = p * 4, v = Math.round(val[p]); out[i] = out[i + 1] = out[i + 2] = v; }
    return { data: out, repaired: filled.length };
  }

  /** 把框整理成 x1<x2、y1<y2，並限制在影像範圍內。 */
  function normBox(b, width, height) {
    const cl = (v, hi) => Math.min(hi, Math.max(0, v));
    const xa = cl(Math.min(b.x1, b.x2), width), xb = cl(Math.max(b.x1, b.x2), width);
    const ya = cl(Math.min(b.y1, b.y2), height), yb = cl(Math.max(b.y1, b.y2), height);
    return { x1: xa, y1: ya, x2: xb, y2: yb };
  }

  /** 字串 → 8 碼十六進位（FNV-1a）。用來把很長的影像識別碼縮成檔名用的短碼。 */
  function hash8(s) {
    let h = 0x811c9dc5;
    const str = String(s);
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(16).padStart(8, '0');
  }

  /**
   * 檔名主幹：<檢查單號>_<8 碼>，跟既有資料集的「單號_8 碼」同一個樣子。
   * 8 碼：從 AI 平台來的用 caseid 前 8 碼；直接從 PACS 來的用影像識別碼算出的短碼。
   */
  function fileBase(page) {
    const acc = String(page.accession_no || '').replace(/[^0-9A-Za-z]/g, '') || 'noacc';
    const cid = String(page.caseid || '').replace(/[^0-9A-Za-z]/g, '').slice(0, 8).toLowerCase();
    return acc + '_' + (cid || (page.object_uid ? hash8(page.object_uid) : 'nocase'));
  }

  /** 把框從一張影像的座標換到另一張（同一張圖的不同解析度）。 */
  function scaleBox(b, sx, sy) {
    return Object.assign({}, b, { x1: b.x1 * sx, y1: b.y1 * sy, x2: b.x2 * sx, y2: b.y2 * sy });
  }

  /** 兩組等長灰階值的相似度（去平均後的相關係數，-1 到 1）。用來從多張 PACS 影像裡挑出跟結果頁同一張的。 */
  function similarity(a, b) {
    const n = Math.min(a.length, b.length);
    if (!n) return 0;
    let ma = 0, mb = 0;
    for (let i = 0; i < n; i++) { ma += a[i]; mb += b[i]; }
    ma /= n; mb /= n;
    let sab = 0, saa = 0, sbb = 0;
    for (let i = 0; i < n; i++) { const x = a[i] - ma, y = b[i] - mb; sab += x * y; saa += x * x; sbb += y * y; }
    return saa && sbb ? sab / Math.sqrt(saa * sbb) : 0;
  }

  /**
   * 從多張候選影像挑一張：先看長寬比（結果頁的影像是原圖等比例縮小，差超過 3% 就不是同一張），
   * 再看相似度最高的。cands: [{ aspect, sim }]。回傳 { index, aspectOk }；沒有候選回傳 index -1。
   */
  function pickCandidate(aspect, cands) {
    let best = -1, bestOk = false;
    cands.forEach((c, i) => {
      const ok = Math.abs(c.aspect - aspect) / aspect <= 0.03;
      const better = best < 0 || (ok && !bestOk) || (ok === bestOk && c.sim > cands[best].sim);
      if (better) { best = i; bestOk = ok; }
    });
    return { index: best, aspectOk: bestOk };
  }

  /**
   * 組出 LabelMe 格式的 JSON 物件（矩形＝兩個點）。
   * LabelMe 不認得的最上層鍵（cxr_relabel）它會原樣保留，不影響用桌面版開啟。
   */
  function buildLabelme(a) {
    const r1 = (v) => Math.round(v * 10) / 10;
    const r5 = (v) => Math.round(v * 1e5) / 1e5;
    const W = a.width, H = a.height;
    const boxes = (a.boxes || []).map((b) => Object.assign({ label: b.label, source: b.source || 'manual' }, normBox(b, W, H)));
    const page = a.page || {};
    const overlay = a.overlay || {};
    const pacs = a.pacs || null; // 影像是從 WebPACS 下載的原圖時才有
    const note = pacs
      ? '影像是從 WebPACS 下載的原始解析度 JPEG（伺服器轉檔）。' +
        (page.caseid ? '模型的框是從 AI 平台結果頁的影像按比例換算過來的；結果頁原本的影像在 image_with_model_boxes。' : '')
      : overlay.removed
        ? '影像取自 AI 平台結果頁（不是原始檔）。模型畫在影像上的框與字已用周圍像素補掉，補的地方是估計值；沒處理過的版本在 image_with_model_boxes。要用原始檔重訓時，以 accession_no 取原圖、座標用 shapes_normalized 的比例值換算。'
        : '影像取自 AI 平台結果頁（不是原始檔），影像上沒有找到模型畫的框與字。要用原始檔重訓時，以 accession_no 取原圖、座標用 shapes_normalized 的比例值換算。';
    return {
      version: '5.2.1',
      flags: { no_finding: !!a.noFinding },
      shapes: boxes.map((b) => ({
        label: b.label,
        points: [[r1(b.x1), r1(b.y1)], [r1(b.x2), r1(b.y2)]],
        group_id: null,
        description: '',
        shape_type: 'rectangle',
        flags: {},
      })),
      imagePath: a.imagePath,
      imageData: null,
      imageHeight: H,
      imageWidth: W,
      cxr_relabel: {
        tool: 'cxr-relabel ' + (a.toolVersion || ''),
        saved_at: a.savedAt || '',
        reviewer: page.empcode || '',
        caseid: page.caseid || '',
        accession_no: page.accession_no || '',
        patient_id: page.patient_id || '',
        exam_date: page.date || '',
        module: page.module || '',
        inferred_at: page.inferredAt || '',
        image_source: pacs ? 'webpacs' : 'aiplatform',
        image_note: note,
        pacs: pacs
          ? { object_uid: pacs.object_uid || '', study_date: pacs.study_date || '', body_part: pacs.body_part || '', images_in_study: pacs.images_in_study || 0,
              similarity_to_ai_image: pacs.similarity == null ? null : r5(pacs.similarity), dicom_file: pacs.dicomPath || '' }
          : null,
        overlay_removed: !!overlay.removed,
        overlay_pixels_repaired: overlay.repaired || 0,
        image_with_model_boxes: overlay.withBoxPath || '',
        model: {
          risk_text: page.riskText || '',
          detections: page.detections || [],
          boxes: (a.modelBoxes || []).map((b) => ({ x1: r1(b.x1), y1: r1(b.y1), x2: r1(b.x2), y2: r1(b.y2) })), // 已換算成存檔影像的座標
          ai_image_size: a.aiImageSize || null, // 結果頁那張影像的 [寬, 高]
        },
        shapes_normalized: boxes.map((b) => ({
          label: b.label,
          source: b.source,
          x1: r5(b.x1 / W), y1: r5(b.y1 / H), x2: r5(b.x2 / W), y2: r5(b.y2 / H),
        })),
        note: a.note || '',
      },
    };
  }

  // 院區：AI 平台結果頁在哪個主機，就只去同一院區的 WebPACS 查。
  // 兩院的檢查單號格式相同，跨院查可能撞號拿到別人的影像。
  const SITES = [
    { id: 'kmuh', name: '附院', ai: 'intraweb.server.kmuh.org.tw', pacs: 'webpacs.kmuh.org.tw' },
    { id: 'kmugh', name: '岡山', ai: 'intraweb.kmugh.org.tw', pacs: 'webpacs.kmugh.org.tw' },
  ];
  function siteByHost(host) {
    const h = String(host || '').toLowerCase();
    return SITES.find((s) => s.ai === h || s.pacs === h) || null;
  }
  /** 病歷號比對用：只留數字、去掉開頭的 0。 */
  function chartKey(v) {
    return String(v == null ? '' : v).replace(/\D/g, '').replace(/^0+/, '');
  }

  // ---------- 免登入接上 WebPACS（0.7.0）：借用體系病歷「檢查」頁的 PACS 連結 ----------
  /** 急診清單的 GetMRNUrl 回覆 → 體系病歷連結。只收 https、而且和急診清單同一個主機；認不得回 ''。 */
  function recordLink(text, origin) {
    let host = '';
    try { host = new URL(origin).hostname.toLowerCase(); } catch (e) { return ''; }
    const norm = (v) => {
      const s = String(v == null ? '' : v).trim().replace(/^["']+|["']+$/g, '');
      if (!/^(https?:\/\/|\/|web\/)/i.test(s)) return '';
      try { const u = new URL(s, origin + '/'); return u.protocol === 'https:' && u.hostname.toLowerCase() === host ? u.href : ''; } catch (e) { return ''; }
    };
    const t = String(text == null ? '' : text);
    const direct = norm(t);
    if (direct) return direct;
    try {
      const d = JSON.parse(t);
      for (const v of typeof d === 'string' ? [d] : Object.values(d || {})) { const u = norm(typeof v === 'string' ? v : ''); if (u) return u; }
    } catch (e) { /* 不是 JSON */ }
    const m = t.match(/["']([^"']*(?:\/WEB\/|https?:\/\/)[^"']*)["']/i);
    return m ? norm(m[1]) : '';
  }
  /** 體系病歷連結 → 同一位病人的「檢查」頁（只換路徑；連結上的 id、LoginID 照舊）。 */
  function examReportUrl(link) {
    try { const u = new URL(link); u.pathname = '/WEB/MRN/ExamReport'; u.hash = ''; return u.href; } catch (e) { return ''; }
  }
  /** 檢查頁「開啟」按鈕的 onclick → WebPACS 開圖連結。
   *  只收：https、這個院區的 WebPACS 主機、OpenImage、剛好 SN／E／E1 三個參數而且長相對；其餘回 ''。 */
  function pacsOpenLink(onclick, pacsHost) {
    for (const m of String(onclick || '').matchAll(/https:\/\/[^'"\s)<>]+/g)) {
      let u;
      try { u = new URL(m[0].replace(/&amp;/g, '&')); } catch (e) { continue; }
      if (u.hostname.toLowerCase() !== pacsHost || u.port || u.username || u.pathname !== '/DicomWeb/DicomWeb.dll/OpenImage') continue;
      const q = u.searchParams;
      if ([...q.keys()].sort().join() !== 'E,E1,SN') continue;
      if (!/^-?\d{1,12}$/.test(q.get('SN')) || !/^[0-9a-f]{16,64}$/i.test(q.get('E')) || !/^[0-9a-f]{32,512}$/i.test(q.get('E1'))) continue;
      return u.href;
    }
    return '';
  }

  const DEFAULT_DIR = 'CXR_relabel';
  /**
   * 整理使用者填的存檔資料夾（瀏覽器「下載」資料夾底下的相對路徑，可以多層）。
   * 合法就回傳整理過的寫法（用 / 分隔），不合法回傳 ''。
   * 外掛只能寫進「下載」底下，所以不接受磁碟代號、開頭的斜線、.. 這類會跳出去的寫法。
   */
  function cleanDir(input) {
    const parts = String(input == null ? '' : input).trim().split(/[\\/]+/).map((s) => s.trim()).filter(Boolean);
    if (!parts.length || parts.length > 5) return '';
    for (const p of parts) {
      if (p.length > 60 || /[<>:"|?*\u0000-\u001f]/.test(p) || /^\.+$/.test(p) || /[. ]$/.test(p)) return '';
    }
    return parts.join('/');
  }

  /** 物件 → JSON 的 data: 網址（UTF-8），給下載用。 */
  function jsonDataUrl(obj) {
    const bytes = new TextEncoder().encode(JSON.stringify(obj, null, 2));
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return 'data:application/json;base64,' + btoa(bin);
  }

  /** data: 網址 → 副檔名（jpeg→jpg）。 */
  function extOf(dataUrl, fallback) {
    const m = /^data:[a-z]+\/([a-z0-9+.-]+)/i.exec(String(dataUrl || ''));
    const t = m ? m[1].toLowerCase() : '';
    if (t === 'jpeg' || t === 'pjpeg') return 'jpg';
    return t.replace(/[^a-z0-9]/g, '') || fallback || 'bin';
  }

  // ---------- PACS 回顧（急診清單 → 這位病人的檢查） ----------
  /** 急診清單的時間 'YYYY/MM/DD HH:MM'（也收 '-' 分隔、帶秒）→ 本地時間的毫秒；讀不懂回 null。 */
  function parseErTime(s) {
    const m = /^\s*(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?:[ T]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*$/.exec(String(s == null ? '' : s));
    if (!m) return null;
    const d = new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
    return isNaN(d) || d.getDate() !== +m[3] ? null : d.getTime();
  }
  /** WebPACS 的檢查日期 'YYYYMMDD'（或 'YYYY/MM/DD'）＋時間 'HH:MM:SS'／'HHMMSS' → { day, at }。
   *  day＝那天 0 點的毫秒；at＝有時間才有（沒有就 null）。日期讀不懂兩個都是 null。 */
  function studyMoment(date, time) {
    const dm = /^(\d{4})[/-]?(\d{2})[/-]?(\d{2})$/.exec(String(date == null ? '' : date).trim());
    if (!dm) return { day: null, at: null };
    const d = new Date(+dm[1], +dm[2] - 1, +dm[3]);
    if (isNaN(d) || d.getDate() !== +dm[3]) return { day: null, at: null };
    const tm = /^(\d{2}):?(\d{2})(?::?(\d{2}))?/.exec(String(time == null ? '' : time).trim());
    const at = tm && +tm[1] < 24 && +tm[2] < 60 ? new Date(+dm[1], +dm[2] - 1, +dm[3], +tm[1], +tm[2], +(tm[3] || 0)).getTime() : null;
    return { day: d.getTime(), at };
  }
  /**
   * 這筆檢查是不是在這次急診期間（入院 since 到出院 until，毫秒；until 沒有就是還在院）。
   * 有檢查時間就比時間（前後各留 graceMin 分鐘，機器時鐘可能不準）；只有日期就比日期。
   * since 讀不到時一律算「是」（沒辦法分，就不要藏起來）。
   */
  function inVisit(m, since, until, graceMin) {
    if (since == null) return true;
    if (!m || m.day == null) return false;
    const g = (graceMin == null ? 60 : graceMin) * 60000;
    if (m.at != null) return m.at >= since - g && (until == null || m.at <= until + g);
    const sinceDay = new Date(since); sinceDay.setHours(0, 0, 0, 0);
    if (m.day < sinceDay.getTime()) return false;
    if (until == null) return true;
    const untilDay = new Date(until); untilDay.setHours(0, 0, 0, 0);
    return m.day <= untilDay.getTime();
  }
  /** 檢查清單排序：新的在前；同一天沒時間的排在有時間的後面。 */
  function sortStudies(list) {
    const key = (s) => { const m = studyMoment(s.date, s.time); return m.at != null ? m.at : m.day != null ? m.day : -Infinity; };
    return list.slice().sort((a, b) => key(b) - key(a));
  }

  const api = { parseErTime, studyMoment, inVisit, sortStudies, SITES, siteByHost, chartKey, recordLink, examReportUrl, pacsOpenLink,DEFAULT_DIR, cleanDir, jsonDataUrl, extOf, CLASSES, CLASS_NAMES, normalizeLabel, parseDetections, findOverlayBoxes, removeOverlay, normBox, hash8, fileBase, scaleBox, similarity, pickCandidate, buildLabelme };
  root.CXRCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
