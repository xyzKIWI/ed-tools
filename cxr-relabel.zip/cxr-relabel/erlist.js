/* CXR 重新標註：急診清單（ipdNote ER_Main，附院與岡山）的頁面腳本。
 * 滑鼠移到清單上某一位病人，那一列右邊會浮出「🩻 PACS」按鈕（那一列被蓋住時不出現）；點選過的病人則在
 * 一顆固定的「🩻 PACS 床號」按鈕上（0.6.1：預設右下角，可以拖到別處，位置會記住）。
 * 按下去開外掛的「PACS 回顧」小視窗（0.6.0：整個瀏覽器只開一個；開著時點選別的病人，內容自動跟著換），
 * 列出這位病人在同院區 WebPACS 的檢查。
 * 按鈕不放進表格裡（放在頁面最外層、蓋在那一列上），不動清單本身，也不會觸發點選病人。
 * 對院內系統唯讀：只讀清單每一列本來就帶著的資料（td[data-erinfo]），不存清單。 */
(function () {
  'use strict';
  if (window.top !== window || !/^\/WEB\/ipdNote\/ER_Main(?:\/Index)?\/?$/i.test(location.pathname)) return;
  if (window.__cxrReviewLoaded) return;
  window.__cxrReviewLoaded = true;

  const ROW = '#ERPatientListTable tr';
  const FONT = 'font:12px/1.5 "Microsoft JhengHei",system-ui,sans-serif;';
  // 1. 滑鼠停在哪一列，那一列右端臨時出現的按鈕（那一列被病歷區之類蓋住時不出現）
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.id = 'cxr-relabel-pacs-btn';
  btn.textContent = '🩻 PACS';
  btn.title = '在 PACS 回顧小視窗列出這位病人的 WebPACS 影像（CXR 重新標註外掛）';
  btn.style.cssText = 'position:fixed;z-index:2147483000;display:none;padding:2px 8px;' + FONT +
    'border:1px solid #0277bd;border-radius:4px;background:#e1f5fe;color:#01579b;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.25);';
  // 2. 固定的那一顆（0.6.1）：點選過的病人，固定在視窗同一個位置（預設右下角，可以拖到別處，位置會記住）
  const dock = document.createElement('button');
  dock.type = 'button';
  dock.id = 'cxr-relabel-pacs-dock';
  dock.style.cssText = 'position:fixed;z-index:2147483000;display:none;right:16px;bottom:16px;padding:5px 12px;' + FONT.replace('12px', '13px') +
    'border:1px solid #0277bd;border-radius:16px;background:#e1f5fe;color:#01579b;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.3);white-space:nowrap;touch-action:none;user-select:none;';
  // current：臨時按鈕畫在哪一列。hover：滑鼠停著的那一列。pinned：點選過的病人（固定按鈕用）。
  let current = null, hover = null, pinnedChart = '', pinnedEl = null, pinnedInfo = null, hideTimer = 0;

  const infoOf = (row) => { try { return JSON.parse(row.querySelector('td[data-erinfo]').textContent); } catch (e) { return null; } };
  // 交給回顧小視窗的：這一列本來就帶著的欄位（只在按下或點選的當下讀）
  function jobOf(info) {
    const outRadio = document.getElementById('ERSTATUSout');
    return {
      chart: chartOf(info), name: info.PTNAME, bed: info['床號'], seq: info['檢傷序號'], status: info.STATUSNAME,
      since: info.CHECKINTIME, until: info.CHECKOUTTIME, aiurl: info.AIURL || '', listOut: !!(outRadio && outRadio.checked),
    };
  }
  const chartOf = (info) => { const c = String((info && info['病歷號']) || '').trim(); return /^\d{4,12}$/.test(c) ? c : ''; };

  // 清單放在可以捲動的框裡（真頁面：#ControlERPatientListTable，overflow:auto），打開病歷區後只剩半邊寬。
  // 按鈕要放在「框裡看得到的那一段列」的右端，不能用整列的右端（會跑到病歷區上面或框外）。
  function visibleBox(row) {
    const r = row.getBoundingClientRect();
    let left = Math.max(0, r.left), right = Math.min(innerWidth, r.right), top = Math.max(0, r.top), bottom = Math.min(innerHeight, r.bottom);
    for (let e = row.parentElement; e && e !== document.documentElement; e = e.parentElement) {
      const cs = getComputedStyle(e);
      if (cs.overflowX === 'visible' && cs.overflowY === 'visible') continue;
      const b = e.getBoundingClientRect();
      left = Math.max(left, b.left + e.clientLeft); right = Math.min(right, b.left + e.clientLeft + e.clientWidth);
      top = Math.max(top, b.top + e.clientTop); bottom = Math.min(bottom, b.top + e.clientTop + e.clientHeight);
    }
    return { left, right, top, bottom, rowTop: r.top, rowHeight: r.height };
  }
  function place(row) {
    const v = visibleBox(row);
    btn.style.visibility = 'hidden';
    btn.style.display = 'block';
    const w = btn.offsetWidth, h = btn.offsetHeight;
    // 看得到的部分太小（捲到框外、框太窄）就先不顯示；捲回來會再出現
    if (!v.rowHeight || v.bottom - v.top < h * 0.6 || v.right - v.left < w + 12) { btn.style.display = 'none'; return; }
    const left = Math.round(v.right - w - 6), top = Math.round(Math.min(Math.max(v.rowTop + (v.rowHeight - h) / 2, v.top), v.bottom - h));
    btn.style.left = left + 'px';
    btn.style.top = top + 'px';
    // 那個位置真的是這一列嗎（有沒有被浮動的病歷區、對話框蓋住）——被蓋住就不顯示，免得浮在別的東西上
    const under = document.elementFromPoint(left + w / 2, top + h / 2);
    if (!under || !row.contains(under)) { btn.style.display = 'none'; return; }
    btn.style.visibility = 'visible';
  }
  const patientRow = (row) => !!(row && row.isConnected && row.querySelector('td[data-erinfo]') && chartOf(infoOf(row)));
  // 點選過的病人那一列。清單重新載入後列會換新，用病歷號找回來。
  // 還沒點選過時，跟著頁面自己標起來的那一列（class="highlight"）。
  function pinnedRow() {
    if (!pinnedChart) { const h = document.querySelector('#ERPatientListTable tr.highlight'); return patientRow(h) ? h : null; }
    if (patientRow(pinnedEl) && chartOf(infoOf(pinnedEl)) === pinnedChart) return pinnedEl;
    pinnedEl = [...document.querySelectorAll(ROW)].find((r) => patientRow(r) && chartOf(infoOf(r)) === pinnedChart) || null;
    return pinnedEl;
  }
  // 固定按鈕要開的病人：清單上找得到那一列就用那一列現在的資料，找不到（換到另一張清單）就用點選當下記的
  function pinnedNow() { const r = pinnedRow(); return r ? infoOf(r) : pinnedInfo; }
  function update() {
    if (hover && !patientRow(hover)) hover = null;
    current = hover;
    if (current) place(current); else btn.style.display = 'none';
    const info = pinnedNow();
    if (info && chartOf(info)) {
      const bed = String(info['床號'] || '').trim();
      dock.textContent = '🩻 PACS　' + (bed || '病人');
      dock.title = '開 PACS 回顧：目前點選的病人' + (bed ? '（' + bed + '）' : '') + '。可以拖曳移到別的位置。';
      dock.style.display = 'block';
    } else dock.style.display = 'none';
  }

  document.addEventListener('mouseover', (e) => {
    const t = e.target instanceof Element ? e.target : null;
    if (!t || t === btn) { clearTimeout(hideTimer); return; }
    const row = t.closest(ROW);
    clearTimeout(hideTimer);
    if (patientRow(row)) { hover = row; return update(); }
    hideTimer = setTimeout(() => { hover = null; update(); }, 250);
  }, true);
  // 點選病人（頁面自己用 mousedown 選病人）：記住是誰，固定按鈕換成這位
  document.addEventListener('mousedown', (e) => {
    const t = e.target instanceof Element ? e.target : null;
    const row = t && t !== btn && t !== dock ? t.closest(ROW) : null;
    if (!patientRow(row)) return;
    const info = infoOf(row);
    pinnedChart = chartOf(info); pinnedEl = row; pinnedInfo = info;
    update();
    // PACS 回顧小視窗開著的話，跟著換成這位（沒開就什麼都不做；不搶焦點）
    try { chrome.runtime.sendMessage({ type: 'review-follow', job: jobOf(info) }).catch(() => {}); } catch (err) { /* 外掛剛更新過 */ }
  }, true);
  addEventListener('scroll', update, true);
  addEventListener('resize', () => { clampDock(); update(); });
  // 清單重新查詢、版面切換（打開病歷區）之後重新找位置；按鈕自己動的不算，免得自己觸發自己
  let moTimer = 0;
  new MutationObserver((recs) => { if (recs.every((r) => r.target === btn || dock.contains(r.target))) return; clearTimeout(moTimer); moTimer = setTimeout(update, 150); })
    .observe(document.body || document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });

  async function openReview(info) {
    if (!chartOf(info)) return alert('讀不到這位病人的病歷號，請重新整理清單後再試。');
    try {
      const r = await chrome.runtime.sendMessage({ type: 'review-open', job: jobOf(info) });
      if (!r || !r.ok) alert('無法開啟 PACS 回顧視窗' + (r && r.reason ? '（' + r.reason + '）' : '') + '。');
    } catch (err) {
      alert('無法開啟 PACS 回顧視窗：' + String((err && err.message) || err) + '\n（外掛剛更新過的話，請重新整理這一頁）');
    }
  }

  // ----- 固定按鈕：拖曳移動（位置記在外掛裡，下次照樣），沒拖就是按下去 -----
  let dockPos = null, drag = null;
  function applyDock() {
    if (!dockPos) { dock.style.left = dock.style.top = ''; dock.style.right = dock.style.bottom = '16px'; return; }
    dock.style.right = dock.style.bottom = '';
    clampDock();
  }
  function clampDock() {
    if (!dockPos) return;
    const w = dock.offsetWidth || 120, h = dock.offsetHeight || 30;
    dock.style.left = Math.max(0, Math.min(innerWidth - w, dockPos.left)) + 'px';
    dock.style.top = Math.max(0, Math.min(innerHeight - h, dockPos.top)) + 'px';
  }
  try { chrome.storage.local.get('dockPos').then((g) => { const p = g && g.dockPos; if (p && Number.isFinite(p.left) && Number.isFinite(p.top)) { dockPos = p; applyDock(); } }).catch(() => {}); } catch (e) { /* 用預設位置 */ }
  for (const t of ['mousedown', 'mouseup', 'click']) dock.addEventListener(t, (e) => e.stopPropagation());
  dock.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    const r = dock.getBoundingClientRect();
    drag = { x: e.clientX, y: e.clientY, left: r.left, top: r.top, moved: false };
    try { dock.setPointerCapture(e.pointerId); } catch (err) { /* 合成的事件沒有指標 */ }
    e.preventDefault();
  });
  dock.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) < 5) return;
    drag.moved = true;
    dockPos = { left: Math.round(drag.left + dx), top: Math.round(drag.top + dy) };
    applyDock();
  });
  dock.addEventListener('pointerup', () => {
    const d = drag; drag = null;
    if (!d) return;
    if (d.moved) { try { chrome.storage.local.set({ dockPos }).catch(() => {}); } catch (e) { /* 只記這一頁 */ } return; }
    openReview(pinnedNow());
  });

  // 不讓頁面自己的滑鼠處理（選病人、開病歷）接到這顆按鈕的事件
  for (const t of ['mousedown', 'mouseup', 'dblclick']) btn.addEventListener(t, (e) => e.stopPropagation());
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const row = current;
    openReview(row && row.isConnected ? infoOf(row) : null); // 按下去的當下才讀，清單換過也不會拿到上一位
  });
  // ---------- 免登入接上 WebPACS（0.7.0） ----------
  // 體系病歷的「檢查」頁上，院內系統替每筆影像檢查現做一條「開啟 PACS」連結：用使用者當下的身分產生、
  // 只能用一次，打開就有 WebPACS 的通行碼，不用輸入帳密（2026-11-21 真系統查證）。這裡在使用者要看影像、
  // 而 WebPACS 還沒接上的時候，替「這一位病人」要一條來用：
  //   1. 向這一頁所在的系統要這位病人的體系病歷連結（GetMRNUrl，急診工作台的 K／T 用的同一支）。
  //   2. 在隱藏的獨立框架裡開這位病人的「檢查」頁，讀出一條開圖連結。
  //   3. 馬上在另一個隱藏框架打開那條連結；框架裡的 pacs.js 之後替外掛向 WebPACS 查詢。
  // 兩個框架都是 credentialless（自己一套 cookie）：體系病歷把「目前是哪位病人」記在登入狀態裡，這樣不會
  // 動到使用者自己開著的病歷分頁，也不會動到使用者自己登入的 WebPACS 分頁。連結與通行碼只在記憶體裡，
  // 不存、不記錄；這一頁關掉或重新整理，框架就沒了（WebPACS 那一頁自己會登出）。
  const C = globalThis.CXRCore;
  const site = C.siteByHost(location.hostname);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const refuse = (reason, detail) => Object.assign(new Error(detail || reason), { reason });
  // 瀏覽器真的給了這個框架自己的一套 cookie 嗎（沒有的話，裡面的頁面會用到使用者的登入狀態：不做）
  const isolated = (f) => { try { return f.credentialless === true && f.contentWindow.credentialless === true; } catch (e) { return false; } };
  function hiddenFrame(name) {
    const f = document.createElement('iframe');
    f.credentialless = true; // 要在放進頁面之前設
    f.name = name;
    // 不給 allow-popups／allow-modals／allow-top-navigation：框架裡的頁面不能開視窗、跳對話框、把這一頁導走
    f.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms');
    f.setAttribute('aria-hidden', 'true');
    f.tabIndex = -1;
    f.style.cssText = 'position:fixed;left:-12000px;top:0;width:1100px;height:800px;border:0;visibility:hidden;pointer-events:none';
    return f;
  }
  // 等框架載入下一頁（中間的空白頁不算）
  const nextLoad = (f, ms) => new Promise((resolve, reject) => {
    const on = () => {
      let href = 'x';
      try { href = f.contentWindow.location.href; } catch (e) { /* 別的網域：也算載入了 */ }
      if (href === 'about:blank') return;
      clearTimeout(timer); f.removeEventListener('load', on); resolve();
    };
    const timer = setTimeout(() => { f.removeEventListener('load', on); reject(refuse('timeout', '體系病歷頁面載入逾時')); }, ms);
    f.addEventListener('load', on);
  });
  const loginUser = () => { const m = /inLoginUser\s*[:=]\s*["']([^"']+)["']/i.exec([...document.scripts].map((s) => s.textContent || '').join('\n')); return m ? m[1].trim() : ''; };

  // 第 1、2 步：這位病人的一條開圖連結
  async function examLink(chart) {
    const user = loginUser();
    if (!user) throw refuse('no-user');
    const r = await fetch('/WEB/ipdNote/Common/GetMRNUrl', {
      method: 'POST', credentials: 'include', signal: AbortSignal.timeout(20000),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ inChartno: chart, inLoginUser: user }),
    });
    let ended = null;
    try { ended = new URL(r.url); } catch (e) { /* 當成被導走 */ }
    if (!ended || ended.origin !== location.origin || /\/AuthServerMVC\//i.test(ended.pathname)) throw refuse('er-login');
    if (!r.ok) throw refuse('error', '院內連結 HTTP ' + r.status);
    const url = C.examReportUrl(C.recordLink(await r.text(), location.origin));
    if (!url) throw refuse('no-record-link');
    const f = hiddenFrame('cxr-relabel-mrn');
    document.documentElement.appendChild(f);
    try {
      if (!isolated(f)) throw refuse('unsupported');
      const ready = async () => {
        for (let i = 0; i < 100; i++) {
          let doc = null;
          try { doc = f.contentDocument; } catch (e) { /* 讀不到 */ }
          if (!doc || !isolated(f)) throw refuse('blocked');
          if (!/^\/web\/mrn\/examreport\/?$/i.test(doc.location.pathname)) throw refuse('mrn-landing');
          if (doc.readyState === 'complete' && doc.querySelector('#examReportTable')) return doc;
          await sleep(100);
        }
        throw refuse('mrn-landing', '檢查頁沒有載入完成');
      };
      const pick = (doc) => {
        // 頁面上寫的病歷號要是這一位，才用它的連結
        const cur = doc.querySelector('#CurrentChartno');
        if (!cur || !C.chartKey(cur.value) || C.chartKey(cur.value) !== C.chartKey(chart)) throw refuse('wrong-patient');
        for (const b of doc.querySelectorAll('#examReportTable [onclick]')) { const u = C.pacsOpenLink(b.getAttribute('onclick'), site.pacs); if (u) return u; }
        return '';
      };
      let loaded = nextLoad(f, 20000);
      f.src = url;
      await loaded;
      let doc = await ready();
      let link = pick(doc);
      if (!link) {
        // 預設只列最近三個月：沒有影像檢查的話，用頁面自己的「全部」再查一次
        const sel = doc.querySelector('#searchDate');
        if (sel && sel.value !== 'ALL' && [...sel.options].some((o) => o.value === 'ALL')) {
          loaded = nextLoad(f, 20000);
          sel.value = 'ALL';
          sel.dispatchEvent(new Event('change', { bubbles: true }));
          await loaded;
          doc = await ready();
          link = pick(doc);
        }
      }
      if (!link) throw refuse('no-link');
      return link;
    } finally { f.remove(); }
  }

  // pacsFrame：接上的那個隱藏框架。refusals：WebPACS 連續不接受連結的次數——到 2 次就不再自動試，
  // 免得一直被 WebPACS 記成登入失敗（重新整理這一頁才會再試）。
  let pacsFrame = null, connecting = null, refusals = 0;
  const ping = async () => { try { return await chrome.runtime.sendMessage({ type: 'er-pacs-ping' }); } catch (e) { return null; } };
  async function connect(chart) {
    if (!site) throw refuse('no-site');
    if (!/^\d{4,12}$/.test(chart)) throw refuse('bad-chart');
    if (!('credentialless' in HTMLIFrameElement.prototype)) throw refuse('unsupported');
    if (refusals >= 2) throw refuse('auth-stopped');
    const link = await examLink(chart);
    if (pacsFrame) { pacsFrame.remove(); pacsFrame = null; }
    const f = hiddenFrame('cxr-relabel-pacs');
    document.documentElement.appendChild(f);
    if (!isolated(f)) { f.remove(); throw refuse('unsupported'); }
    f.src = link; // 第 3 步：要到就用
    let heard = false, refused = false;
    for (let i = 0; i < 40 && !refused; i++) {
      await sleep(300);
      const r = await ping();
      if (!r || !r.ok) continue;
      heard = true;
      if (r.key) { pacsFrame = f; refusals = 0; return { ok: true }; }
      refused = !!r.refused;
    }
    f.remove();
    if (!heard) throw refuse('blocked');   // 框架裡的頁面沒有載入（院方不讓它放在框架裡，或網路不通）
    refusals++;
    throw refuse('auth-failed');
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'er-pacs-connect') return;
    // 同時只做一次：通行碼是這個帳號的，不分病人，後到的請求用同一個結果
    if (!connecting) {
      connecting = connect(String(msg.chart || ''))
        .catch((e) => ({ ok: false, reason: (e && e.reason) || 'error', detail: e && e.reason ? '' : String((e && e.message) || e) }))
        .finally(() => { connecting = null; });
    }
    connecting.then(sendResponse);
    return true; // 非同步回覆
  });

  (document.body || document.documentElement).append(btn, dock);
  update();
})();
