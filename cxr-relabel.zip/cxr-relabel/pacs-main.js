/* CXR 重新標註：在 WebPACS「頁面自己的環境」裡跑的一小段（manifest 的 world: MAIN，document_start）。
 * 外掛的頁面腳本（pacs.js）在隔離環境裡，讀不到頁面的程式變數；這裡替它做兩件事。
 *
 * 1. 查詢框架（Queryfrm，使用者自己登入的 WebPACS 分頁）：登入後的通行碼（AccKey）只放在程式變數裡，
 *    頁面要到使用者按「查詢」時才把它填進查詢表單。pacs.js 要用之前發一個事件，這裡做頁面按「查詢」時
 *    本來就會做的那一步：把通行碼填進查詢表單的隱藏欄位。
 *
 * 2. 外掛自己的隱藏框架（名字 cxr-relabel-pacs，0.7.0 免登入接上 WebPACS）：框架裡開的是體系病歷
 *    「檢查」頁那條開圖連結（OpenImage）。那一頁原本會去連本機的看片程式（ws://127.0.0.1）把檢查打開；
 *    外掛只要它的通行碼，所以在「這個框架裡」把 WebSocket 換成不會連線的空殼，看片程式不會被叫出來。
 *    另外在 pacs.js 發事件時，把頁面變數裡的通行碼抄到這個框架自己的網頁屬性上給 pacs.js 讀。
 *
 * 不存、不外傳；使用者自己開的 WebPACS 分頁與看片程式完全不受影響。 */
(function () {
  'use strict';
  var attr = function (name, value) { try { document.documentElement.setAttribute(name, value); } catch (e) { /* 頁面還沒有根元素 */ } };

  if (window.name === 'cxr-relabel-pacs' && window.top !== window) {
    var Quiet = function () { this.readyState = 3; this.url = ''; this.send = function () {}; this.close = function () {}; };
    Quiet.CONNECTING = 0; Quiet.OPEN = 1; Quiet.CLOSING = 2; Quiet.CLOSED = 3;
    try { Object.defineProperty(window, 'WebSocket', { configurable: true, writable: true, value: Quiet }); } catch (e) { window.WebSocket = Quiet; }
    document.addEventListener('cxr-relabel-acckey', function () {
      var key = '', user = '', failed = '';
      try { if (typeof window.AccKey === 'string') key = window.AccKey; } catch (e) { /* 留空 */ }
      try { if (typeof window.UName === 'string') user = window.UName; } catch (e) { /* 留空 */ }
      try { if (!key && typeof window.msg === 'string' && window.msg) failed = '1'; } catch (e) { /* 留空 */ }
      attr('data-cxr-acckey', key);
      attr('data-cxr-user', user);
      attr('data-cxr-refused', failed); // WebPACS 回了錯誤訊息（例如連結已失效），沒有發通行碼
    });
    return;
  }

  if (window.name !== 'Queryfrm') return;
  document.addEventListener('cxr-relabel-acckey', function () {
    try {
      var form = document.getElementById('QueryPatient');
      var key = window.AccKey;
      if (form && form.AccKey && typeof key === 'string' && key) form.AccKey.value = key;
    } catch (e) { /* 讀不到就照舊，pacs.js 會說「沒登入」 */ }
  });
})();
