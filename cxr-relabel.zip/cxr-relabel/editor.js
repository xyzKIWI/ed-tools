/* CXR 重新標註：共用的標註畫面。
 * AI 平台結果頁（蓋在原分頁上）與外掛自己的分頁（從 WebPACS 開）都用這一份。
 * 只管畫框與存檔流程；影像從哪裡來、要存哪些檔，由呼叫的人決定（opts）。 */
(function (root) {
  'use strict';
  const C = root.CXRCore;

  const TEMPLATE = `
<style>
:host{all:initial}
*{box-sizing:border-box;font-family:"Microsoft JhengHei","PingFang TC",system-ui,sans-serif}
.wrap{position:absolute;inset:0;display:flex;background:#0b1620;color:#e3eef6;font-size:14px}
.stage{flex:1;position:relative;min-width:0;background:#000;overflow:hidden}
canvas{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none}
.tip{position:absolute;left:10px;bottom:8px;right:10px;font-size:12px;color:#b6c8d5;background:rgba(0,0,0,.6);padding:4px 8px;border-radius:4px;pointer-events:none;width:fit-content}
aside{width:310px;flex:none;display:flex;flex-direction:column;gap:12px;padding:14px;overflow-y:auto;border-left:1px solid #1f3547;background:#0f2231}
h1{font-size:17px;margin:0}
h2{font-size:13px;margin:0 0 5px;color:#8fb6cf;font-weight:600}
.meta{font-size:12px;color:#9fb3c2;line-height:1.7;word-break:break-all}
button{font:inherit;color:inherit;cursor:pointer}
.classes{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.cls{display:flex;align-items:center;gap:6px;padding:5px 6px;border:1px solid #2a4860;border-radius:5px;background:#132c3f;text-align:left;line-height:1.2}
.cls.on{border-color:#fff;background:#1d4a69}
.cls.minor{opacity:.8}
.cls i,.item i{width:10px;height:10px;border-radius:2px;flex:none;display:inline-block}
.cls kbd{font:11px Consolas,monospace;color:#8fb6cf}
.cls small{display:block;font-size:10px;color:#8fb6cf}
.list{display:flex;flex-direction:column;gap:4px}
.item{display:flex;align-items:center;gap:6px;padding:4px 6px;border:1px solid #2a4860;border-radius:5px;background:#132c3f;cursor:pointer}
.item.sel{border-color:#fff}
.item.bad{border-color:#ff8a80}
.item select{flex:1;min-width:0;background:#0b1620;color:inherit;border:1px solid #2a4860;border-radius:4px;padding:2px;font:inherit}
.item .src{font-size:11px;color:#8fb6cf;flex:none}
.item .del{border:0;background:none;color:#ff8a80;font-size:15px;padding:0 4px}
.empty{font-size:12px;color:#7d93a3}
label.chk{display:flex;gap:6px;align-items:center;cursor:pointer}
textarea{width:100%;min-height:52px;background:#0b1620;color:inherit;border:1px solid #2a4860;border-radius:5px;padding:5px;font:inherit;resize:vertical}
input[type=text]{width:100%;background:#0b1620;color:inherit;border:1px solid #2a4860;border-radius:5px;padding:5px;font:inherit}
input[type=range]{width:100%;accent-color:#1976d2;margin:0}
.win{display:flex;flex-direction:column;gap:7px}
.win label{display:flex;align-items:center;gap:8px;font-size:12px;color:#b6c8d5;margin:0}
.win label span{flex:none;width:30px}
.win .val{color:#8fb6cf;flex:none;width:38px;text-align:right}
.pbtns{display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px}
.pbtn{display:flex;flex-direction:column;align-items:flex-start;padding:5px 7px;border:1px solid #2a4860;border-radius:5px;background:#132c3f;color:inherit;line-height:1.15;text-align:left}
.pbtn.on{border-color:#fff;background:#1d4a69}
.pbtn small{font-size:10px;color:#8fb6cf}
.tiny{font-size:11px;color:#7d93a3;line-height:1.5;margin-top:2px}
.btn:active,.cls:active,.pbtn:active{transform:translateY(1px)}
.footer{position:sticky;bottom:0;background:#0f2231;padding-top:8px;border-top:1px solid #1f3547;display:flex;flex-direction:column;gap:8px}
.actions{display:flex;gap:6px;flex-wrap:wrap}
.btn{padding:7px 12px;border:1px solid #2a4860;border-radius:5px;background:#132c3f}
.btn.primary{background:#1976d2;border-color:#1976d2;color:#fff;font-weight:600;flex:1 1 100%}
.status{font-size:12px;line-height:1.5;min-height:18px;word-break:break-all}
.status.err{color:#ff8a80}.status.ok{color:#a5d6a7}
[hidden]{display:none!important}
</style>
<div class="wrap">
  <div class="stage"><canvas></canvas><div class="tip" id="tip"></div></div>
  <aside>
    <h1 id="title">CXR 重新標註</h1>
    <div class="meta" id="meta"></div>
    <div><h2>類別（數字鍵切換；選取框時會改那個框）</h2><div class="classes" id="classes"></div></div>
    <div><h2>影像顯示（預設是亮度／對比近似，非真 HU 窗位）</h2>
      <div class="pbtns" id="wins"></div>
      <div class="win">
        <label><span>亮度</span><input type="range" id="bright" min="20" max="300" value="100"><span class="val" id="brightv">100%</span></label>
        <label><span>對比</span><input type="range" id="contrast" min="20" max="300" value="100"><span class="val" id="contrastv">100%</span></label>
      </div>
      <div class="tiny">右鍵在影像上拖曳也可調（左右＝對比、上下＝亮度）；W 換預設、I 反白、R 重設</div>
    </div>
    <div><h2>框</h2><div class="list" id="list"></div></div>
    <label class="chk"><input type="checkbox" id="nofinding">這張沒有任何病灶</label>
    <label class="chk" id="dicomrow" hidden><input type="checkbox" id="dicom">同時存 DICOM 原檔（檔頭含姓名、病歷號）</label>
    <div><h2>備註（選填）</h2><textarea id="note"></textarea></div>
    <div><h2>存檔資料夾（在瀏覽器的「下載」底下，設一次就會記住）</h2><input type="text" id="dir" spellcheck="false"></div>
    <div class="footer">
      <div class="actions">
        <button class="btn primary" id="save">儲存影像與標註（Ctrl+S）</button>
        <button class="btn" id="reset">還原成模型的框</button>
        <span id="extra" style="display:contents"></span>
        <button class="btn" id="close">關閉（Esc）</button>
      </div>
      <div class="status" id="status"></div>
    </div>
  </aside>
</div>`;

  let current = null;
  // Ctrl+C 複製的框（同一個頁面裡跨影像也能貼）：座標存成影像寬高的比例
  let clip = null;

  /**
   * opts:
   *   title, metaLines[], intro           畫面上的文字
   *   image, width, height                要標註的影像（canvas 能畫的東西）與它的像素大小；框的座標以它為準
   *   compare                             （選填）按 O 對照用的另一張影像，會拉成同樣大小顯示
   *   boxes, resetBoxes()                 一開始的框；「還原成模型的框」要還原成什麼（沒有就不顯示那顆按鈕）
   *   defaultLabel, storeKey              預設類別；記住上次標註用的鍵
   *   dicomOption                         顯示「同時存 DICOM」勾選
   *   extraButtons[{label,onClick}]       額外按鈕
   *   makeFiles({boxes,noFinding,note,savedAt,wantDicom}) → [{filename,url}]（filename 不含資料夾）
   *   onSaved(savedAtText), onClose()
   */
  async function open(opts) {
    if (current) return current;
    const W = opts.width, H = opts.height;
    let uid = 0;
    const withId = (list) => (list || []).map((b) => ({ id: ++uid, label: b.label || '', source: b.source || 'manual', x1: b.x1, y1: b.y1, x2: b.x2, y2: b.y2 }));
    const st = { boxes: withId(opts.boxes), sel: null, cur: opts.defaultLabel || C.CLASSES[0].name, hide: false, showCompare: false, noFinding: false, note: '', dirty: false, wantDicom: false, dir: C.DEFAULT_DIR };

    let loadedSaved = false;
    try {
      const got = await chrome.storage.local.get([opts.storeKey, 'opt:dicom', 'opt:dir']);
      st.wantDicom = !!got['opt:dicom'];
      st.dir = C.cleanDir(got['opt:dir']) || C.DEFAULT_DIR;
      const s = got[opts.storeKey];
      if (s && Array.isArray(s.boxes)) {
        // 上次可能是在另一種解析度的影像上標的（例如當時拿不到 PACS 原圖），按比例換過來
        const kx = s.w ? W / s.w : 1, ky = s.h ? H / s.h : 1;
        st.boxes = withId(s.boxes.map((b) => C.scaleBox(b, kx, ky)));
        st.noFinding = !!s.noFinding;
        st.note = s.note || '';
        loadedSaved = true;
      }
    } catch (e) { /* 沒有上次紀錄 */ }

    const host = document.createElement('div');
    host.id = 'cxr-relabel-editor';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;';
    const sh = host.attachShadow({ mode: 'open' });
    sh.innerHTML = TEMPLATE;
    document.documentElement.appendChild(host);
    const prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';

    const $ = (s) => sh.querySelector(s);
    const cv = $('canvas'), ctx = cv.getContext('2d'), stage = $('.stage');
    const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
    const classOf = (name) => C.CLASSES.find((c) => c.name === name);
    const colorOf = (name) => (classOf(name) ? classOf(name).color : '#ffffff');
    const status = (msg, kind) => { const s = $('#status'); s.textContent = msg; s.className = 'status' + (kind ? ' ' + kind : ''); };
    const touch = () => { st.dirty = true; };

    if (opts.title) $('#title').textContent = opts.title;
    $('#tip').textContent = '拖曳空白處＝畫新框｜拖框的邊＝移動｜拖角落＝改大小｜滾輪＝縮放（Ctrl 細調）、+／-＝縮放｜右鍵拖曳＝亮度/對比（窗寬窗位）、W＝換預設、I＝反白、R＝重設｜中鍵或空白+左鍵拖曳＝平移｜F＝回到全圖｜H＝暫時隱藏框' +
      (opts.compare ? '｜O＝對照結果頁原本的影像' : '') + '｜Delete＝刪除選取的框｜Ctrl+Z／Y＝復原／重做｜Ctrl+C／V＝複製貼上框｜方向鍵＝微調框（Shift 移多一點）';
    const meta = $('#meta');
    (opts.metaLines || []).concat('影像大小：' + W + ' × ' + H).forEach((t) => meta.appendChild(el('div', '', t)));

    function renderClasses() {
      const box = $('#classes');
      box.textContent = '';
      C.CLASSES.forEach((c, i) => {
        const b = el('button', 'cls' + (c.main ? '' : ' minor') + (st.cur === c.name ? ' on' : ''));
        b.type = 'button';
        const dot = el('i'); dot.style.background = c.color;
        const txt = el('span'); txt.appendChild(document.createTextNode(c.zh)); txt.appendChild(el('small', '', c.name));
        b.append(el('kbd', '', String((i + 1) % 10)), dot, txt);
        b.addEventListener('click', () => setClass(c.name));
        box.appendChild(b);
      });
    }

    function renderList() {
      const box = $('#list');
      box.textContent = '';
      if (!st.boxes.length) { box.appendChild(el('div', 'empty', '還沒有框。在影像上拖曳就能畫一個。')); return; }
      st.boxes.forEach((b) => {
        const known = !!classOf(b.label);
        const row = el('div', 'item' + (st.sel === b.id ? ' sel' : '') + (known ? '' : ' bad'));
        const dot = el('i'); dot.style.background = colorOf(b.label);
        const sel = el('select');
        if (!known) { const o = el('option', '', '？請選類別'); o.value = ''; sel.appendChild(o); }
        C.CLASSES.forEach((c) => { const o = el('option', '', c.zh + ' ' + c.name); o.value = c.name; sel.appendChild(o); });
        sel.value = known ? b.label : '';
        sel.addEventListener('change', () => { remember('改類別'); b.label = sel.value; touch(); renderList(); draw(); });
        sel.addEventListener('click', (e) => e.stopPropagation());
        const del = el('button', 'del', '✕'); del.type = 'button'; del.title = '刪除這個框';
        del.addEventListener('click', (e) => { e.stopPropagation(); removeBox(b.id); });
        row.append(dot, sel, el('span', 'src', b.source === 'model' ? '模型' : '手動'), del);
        row.addEventListener('click', () => { st.sel = b.id; renderList(); draw(); });
        box.appendChild(row);
      });
    }

    // ----- 復原／重做（Ctrl+Z／Ctrl+Y）：每個會改框的動作之前先記一份狀態 -----
    const hist = { undo: [], redo: [], nudgeAt: 0 };
    const snap = () => ({ boxes: st.boxes.map((b) => Object.assign({}, b)), noFinding: st.noFinding, sel: st.sel });
    function remember(what, s) {
      hist.undo.push({ s: s || snap(), what });
      if (hist.undo.length > 200) hist.undo.shift();
      hist.redo.length = 0;
      hist.nudgeAt = 0;
    }
    function restore(s) {
      st.boxes = s.boxes.map((b) => Object.assign({}, b));
      st.noFinding = s.noFinding;
      st.sel = st.boxes.some((b) => b.id === s.sel) ? s.sel : null;
      $('#nofinding').checked = st.noFinding;
      touch(); renderList(); draw();
    }
    function undo() {
      const h = hist.undo.pop();
      if (!h) return status('沒有可以復原的動作。');
      hist.redo.push({ s: snap(), what: h.what });
      hist.nudgeAt = 0;
      restore(h.s);
      status('已復原：' + h.what + '（Ctrl+Y 取消復原）');
    }
    function redo() {
      const h = hist.redo.pop();
      if (!h) return status('沒有可以重做的動作。');
      hist.undo.push({ s: snap(), what: h.what });
      hist.nudgeAt = 0;
      restore(h.s);
      status('已重做：' + h.what);
    }

    function setClass(name) {
      st.cur = name;
      const b = st.boxes.find((x) => x.id === st.sel);
      if (b && b.label !== name) { remember('改類別'); b.label = name; touch(); }
      renderClasses(); renderList(); draw();
    }
    function removeBox(id) {
      remember('刪除框');
      st.boxes = st.boxes.filter((x) => x.id !== id);
      if (st.sel === id) st.sel = null;
      touch(); renderList(); draw();
    }

    // ----- 畫布 -----
    const v = { s: 1, tx: 0, ty: 0, fitS: 1, bright: 100, contrast: 100, invert: false };
    // 真 HU 窗位是 CT 的概念，平片（CR/DX）只有 JPEG；這幾組用亮度/對比近似「看骨／看肺／看軟組織」的觀感，反白另外切
    const WINS = [
      { key: 'normal', zh: '一般', en: 'Default', b: 100, c: 100 },
      { key: 'bone', zh: '骨窗', en: 'Bone', b: 105, c: 170 },
      { key: 'lung', zh: '肺窗', en: 'Lung', b: 92, c: 140 },
      { key: 'soft', zh: '軟組織', en: 'Soft', b: 115, c: 82 },
    ];
    let cw = 1, ch = 1;

    function renderWins() {
      const box = $('#wins'); if (!box) return;
      box.textContent = '';
      WINS.forEach((w) => {
        const b = el('button', 'pbtn'); b.type = 'button'; b.dataset.win = w.key;
        b.append(el('span', '', w.zh), el('small', '', w.en));
        b.addEventListener('click', () => setWin(w.b, w.c, v.invert));
        box.appendChild(b);
      });
      const inv = el('button', 'pbtn'); inv.type = 'button'; inv.id = 'invbtn';
      inv.append(el('span', '', '反白'), el('small', '', 'Invert'));
      inv.addEventListener('click', () => setWin(v.bright, v.contrast, !v.invert));
      box.appendChild(inv);
      const rs = el('button', 'pbtn'); rs.type = 'button';
      rs.append(el('span', '', '重設'), el('small', '', 'Reset'));
      rs.addEventListener('click', () => setWin(100, 100, false));
      box.appendChild(rs);
      markWin();
    }
    function markWin() {
      const box = $('#wins'); if (!box) return;
      box.querySelectorAll('.pbtn[data-win]').forEach((b) => {
        const w = WINS.find((x) => x.key === b.dataset.win);
        b.classList.toggle('on', !!w && v.bright === w.b && v.contrast === w.c && !v.invert);
      });
      const inv = $('#invbtn'); if (inv) inv.classList.toggle('on', v.invert);
    }
    function setWin(b, c, inv, quiet) {
      v.bright = Math.round(Math.min(300, Math.max(20, b)));
      v.contrast = Math.round(Math.min(300, Math.max(20, c)));
      v.invert = !!inv;
      const bi = $('#bright'), ci = $('#contrast'), bv = $('#brightv'), cvv = $('#contrastv');
      if (bi) bi.value = v.bright; if (ci) ci.value = v.contrast;
      if (bv) bv.textContent = v.bright + '%'; if (cvv) cvv.textContent = v.contrast + '%';
      markWin();
      draw();
      if (!quiet) status('亮度 ' + v.bright + '%、對比 ' + v.contrast + '%' + (v.invert ? '、反白' : ''));
    }
    function cycleWin() {
      let i = WINS.findIndex((w) => v.bright === w.b && v.contrast === w.c);
      i = (i + 1) % WINS.length;
      const w = WINS[i];
      setWin(w.b, w.c, v.invert, true);
      status('視窗：' + w.zh + '（' + w.en + '）亮度 ' + v.bright + '%、對比 ' + v.contrast + '%' + (v.invert ? '、反白' : ''));
    }
    function zoomAt(ns, mx, my) {
      ns = Math.min(12, Math.max(v.fitS * 0.5, ns));
      v.tx = mx - ((mx - v.tx) / v.s) * ns;
      v.ty = my - ((my - v.ty) / v.s) * ns;
      v.s = ns;
      draw();
    }

    function fit() {
      v.fitS = Math.min(cw / W, ch / H) * 0.97;
      v.s = v.fitS;
      v.tx = (cw - W * v.s) / 2;
      v.ty = (ch - H * v.s) / 2;
    }
    function resize() {
      const r = stage.getBoundingClientRect();
      cw = Math.max(1, r.width); ch = Math.max(1, r.height);
      const dpr = window.devicePixelRatio || 1;
      cv.width = Math.round(cw * dpr); cv.height = Math.round(ch * dpr);
      fit(); draw();
    }
    const sx = (x) => x * v.s + v.tx, sy = (y) => y * v.s + v.ty;
    let drag = null;

    function draw() {
      const dpr = window.devicePixelRatio || 1;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.filter = 'none';
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, cw, ch);
      ctx.imageSmoothingEnabled = v.s < 3;
      // 亮度/對比/反相只套在影像上，框與文字不受影響
      ctx.filter = 'brightness(' + v.bright + '%) contrast(' + v.contrast + '%)' + (v.invert ? ' invert(1)' : '');
      ctx.drawImage(st.showCompare && opts.compare ? opts.compare : opts.image, v.tx, v.ty, W * v.s, H * v.s);
      ctx.filter = 'none';
      if (!st.hide) {
        ctx.font = '12px "Microsoft JhengHei",sans-serif';
        ctx.textBaseline = 'bottom';
        for (const b of st.boxes) {
          const known = !!classOf(b.label), selected = st.sel === b.id, col = colorOf(b.label);
          const x = sx(Math.min(b.x1, b.x2)), y = sy(Math.min(b.y1, b.y2));
          const w = Math.abs(b.x2 - b.x1) * v.s, h = Math.abs(b.y2 - b.y1) * v.s;
          ctx.setLineDash(known ? [] : [6, 4]);
          ctx.lineWidth = selected ? 3 : 2;
          ctx.strokeStyle = col;
          ctx.strokeRect(x, y, w, h);
          ctx.setLineDash([]);
          const tag = known ? b.label : '？未選類別';
          const tw = ctx.measureText(tag).width + 8;
          const ty = y >= 16 ? y : y + h + 16;
          ctx.fillStyle = col;
          ctx.fillRect(x - 1, ty - 16, tw, 16);
          ctx.fillStyle = '#000';
          ctx.fillText(tag, x + 3, ty - 1);
          if (selected) {
            ctx.fillStyle = '#fff';
            for (const [hx, hy] of [[x, y], [x + w, y], [x, y + h], [x + w, y + h]]) ctx.fillRect(hx - 4, hy - 4, 8, 8);
          }
        }
      }
      if (drag && drag.mode === 'draw') {
        ctx.setLineDash([5, 4]);
        ctx.lineWidth = 2;
        ctx.strokeStyle = colorOf(st.cur);
        ctx.strokeRect(sx(Math.min(drag.x1, drag.x2)), sy(Math.min(drag.y1, drag.y2)), Math.abs(drag.x2 - drag.x1) * v.s, Math.abs(drag.y2 - drag.y1) * v.s);
        ctx.setLineDash([]);
      }
    }

    const clampX = (x) => Math.min(W, Math.max(0, x)), clampY = (y) => Math.min(H, Math.max(0, y));
    const toImg = (e) => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left - v.tx) / v.s, y: (e.clientY - r.top - v.ty) / v.s }; };

    function hit(p) {
      if (st.hide) return null;
      const tol = 7 / v.s;
      const order = st.boxes.slice().reverse().sort((a, b) => (b.id === st.sel) - (a.id === st.sel));
      for (const b of order)
        for (const xk of ['x1', 'x2'])
          for (const yk of ['y1', 'y2'])
            if (Math.abs(p.x - b[xk]) <= tol && Math.abs(p.y - b[yk]) <= tol) return { type: 'corner', box: b, xk, yk };
      for (const b of order) {
        const outer = p.x >= b.x1 - tol && p.x <= b.x2 + tol && p.y >= b.y1 - tol && p.y <= b.y2 + tol;
        const inner = p.x > b.x1 + tol && p.x < b.x2 - tol && p.y > b.y1 + tol && p.y < b.y2 - tol;
        if (outer && !inner) return { type: 'edge', box: b };
      }
      return null;
    }

    let spaceDown = false;
    cv.addEventListener('contextmenu', (e) => e.preventDefault());
    cv.addEventListener('pointerdown', (e) => {
      cv.setPointerCapture(e.pointerId);
      if (e.button === 1 || (e.button === 0 && spaceDown)) {
        e.preventDefault();
        drag = { mode: 'pan', cx: e.clientX, cy: e.clientY, tx: v.tx, ty: v.ty };
        return;
      }
      if (e.button === 2) { // 右鍵拖曳＝窗寬窗位（亮度/對比）
        e.preventDefault();
        drag = { mode: 'window', cx: e.clientX, cy: e.clientY, b0: v.bright, c0: v.contrast };
        return;
      }
      if (e.button !== 0) return;
      const p = toImg(e), h = hit(p);
      const before = snap(); // 拖曳結束時框有變，才把這份記進復原
      if (h && h.type === 'corner') { st.sel = h.box.id; drag = { mode: 'resize', box: h.box, xk: h.xk, yk: h.yk, before, o: Object.assign({}, h.box) }; }
      else if (h) { st.sel = h.box.id; drag = { mode: 'move', box: h.box, px: p.x, py: p.y, o: Object.assign({}, h.box), before }; }
      else { st.sel = null; drag = { mode: 'draw', x1: clampX(p.x), y1: clampY(p.y), x2: clampX(p.x), y2: clampY(p.y), before }; }
      renderList(); draw();
    });
    cv.addEventListener('pointermove', (e) => {
      const p = toImg(e);
      if (!drag) {
        const h = hit(p);
        cv.style.cursor = !h ? 'crosshair' : h.type === 'edge' ? 'move' : (h.xk === 'x1') === (h.yk === 'y1') ? 'nwse-resize' : 'nesw-resize';
        return;
      }
      if (drag.mode === 'pan') { v.tx = drag.tx + e.clientX - drag.cx; v.ty = drag.ty + e.clientY - drag.cy; }
      else if (drag.mode === 'window') { setWin(drag.b0 - (e.clientY - drag.cy) * 0.5, drag.c0 + (e.clientX - drag.cx) * 0.5, v.invert); return; }
      else if (drag.mode === 'draw') { drag.x2 = clampX(p.x); drag.y2 = clampY(p.y); }
      else if (drag.mode === 'resize') { drag.box[drag.xk] = clampX(p.x); drag.box[drag.yk] = clampY(p.y); touch(); }
      else if (drag.mode === 'move') {
        const o = drag.o;
        const dx = Math.min(W - o.x2, Math.max(-o.x1, p.x - drag.px)), dy = Math.min(H - o.y2, Math.max(-o.y1, p.y - drag.py));
        Object.assign(drag.box, { x1: o.x1 + dx, x2: o.x2 + dx, y1: o.y1 + dy, y2: o.y2 + dy });
        touch();
      }
      draw();
    });
    const endDrag = () => {
      if (!drag) return;
      const d = drag;
      drag = null;
      if (d.mode === 'draw') {
        const nb = C.normBox(d, W, H);
        const min = Math.max(4, Math.min(W, H) / 300); // 太小的當成誤觸
        if (nb.x2 - nb.x1 >= min && nb.y2 - nb.y1 >= min) {
          remember('新增框', d.before);
          const b = Object.assign({ id: ++uid, label: st.cur, source: 'manual' }, nb);
          st.boxes.push(b); st.sel = b.id; touch();
        }
      } else if (d.mode === 'resize' || d.mode === 'move') {
        if (d.mode === 'resize') Object.assign(d.box, C.normBox(d.box, W, H));
        if (['x1', 'y1', 'x2', 'y2'].some((k) => d.box[k] !== d.o[k])) remember(d.mode === 'resize' ? '改大小' : '移動框', d.before);
      }
      renderList(); draw();
    };
    cv.addEventListener('pointerup', endDrag);
    cv.addEventListener('pointercancel', endDrag);
    cv.addEventListener('dblclick', () => { fit(); draw(); });
    cv.addEventListener('wheel', (e) => {
      e.preventDefault();
      const r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top;
      const rate = e.ctrlKey ? 0.0006 : 0.0015; // 按住 Ctrl 縮放細一點
      zoomAt(v.s * Math.exp(-e.deltaY * rate), mx, my);
    }, { passive: false });

    // ----- 複製／貼上（Ctrl+C／Ctrl+V）、方向鍵微調 -----
    function copyBox() {
      const b = st.boxes.find((x) => x.id === st.sel);
      if (!b) return status('先點選一個框，再按 Ctrl+C 複製。');
      clip = { label: b.label, key: opts.storeKey, x1: b.x1 / W, y1: b.y1 / H, x2: b.x2 / W, y2: b.y2 / H };
      status('已複製這個框（' + (b.label || '未選類別') + '），按 Ctrl+V 貼上。');
    }
    function pasteBox() {
      if (!clip) return status('還沒有複製框：先點選一個框，按 Ctrl+C。');
      // 貼回同一張影像時往右下錯開一點，才看得出多了一個；貼到別張影像就放在同樣的相對位置
      const off = clip.key === opts.storeKey ? 0.02 : 0;
      const w = clip.x2 - clip.x1, h = clip.y2 - clip.y1;
      const x1 = Math.min(1 - w, clip.x1 + off), y1 = Math.min(1 - h, clip.y1 + off);
      remember('貼上框');
      const b = Object.assign({ id: ++uid, label: clip.label, source: 'manual' }, C.normBox({ x1: x1 * W, y1: y1 * H, x2: (x1 + w) * W, y2: (y1 + h) * H }, W, H));
      st.boxes.push(b); st.sel = b.id;
      if (clip.key === opts.storeKey) clip = Object.assign({}, clip, { x1, y1, x2: x1 + w, y2: y1 + h }); // 連續貼上會一路錯開
      touch(); renderList(); draw();
      status('已貼上（Ctrl+Z 可以復原）。');
    }
    function nudge(key, big) {
      const b = st.boxes.find((x) => x.id === st.sel);
      if (!b) return false;
      const step = (big ? 10 : 1) / v.s; // 螢幕上 1（或 10）個像素
      let dx = key === 'ArrowLeft' ? -step : key === 'ArrowRight' ? step : 0, dy = key === 'ArrowUp' ? -step : key === 'ArrowDown' ? step : 0;
      dx = Math.min(W - b.x2, Math.max(-b.x1, dx)); dy = Math.min(H - b.y2, Math.max(-b.y1, dy));
      if (!dx && !dy) return true;
      // 連續按方向鍵算同一個動作，Ctrl+Z 一次退回按之前的位置
      const now = Date.now();
      if (!(hist.nudgeAt && now - hist.nudgeAt < 1500 && hist.nudgeId === b.id)) { remember('微調位置'); }
      hist.nudgeAt = now; hist.nudgeId = b.id;
      Object.assign(b, { x1: b.x1 + dx, x2: b.x2 + dx, y1: b.y1 + dy, y2: b.y2 + dy });
      touch(); draw();
      return true;
    }

    // ----- 鍵盤 -----
    const onKeyDown = (e) => {
      const t = e.composedPath()[0];
      const typing = t && (t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || (t.tagName === 'INPUT' && t.type === 'text'));
      const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      const mod = (e.ctrlKey || e.metaKey) && !e.altKey;
      let used = true;
      if (mod && k === 's') save();
      else if (e.key === 'Escape') close();
      // 在備註、資料夾欄位打字時，Ctrl+Z／C／V 照瀏覽器原本的（改文字），不動框
      else if (mod && !typing && k === 'z' && !e.shiftKey) undo();
      else if (mod && !typing && (k === 'y' || (k === 'z' && e.shiftKey))) redo();
      else if (mod && !typing && k === 'c') copyBox();
      else if (mod && !typing && k === 'v') pasteBox();
      else if (!typing && !mod && !e.altKey && /^Arrow/.test(e.key)) { if (!nudge(e.key, e.shiftKey)) used = false; }
      else if (typing || e.ctrlKey || e.metaKey || e.altKey) used = false;
      else if (k === ' ') spaceDown = true;
      else if (/^[0-9]$/.test(k)) { const c = C.CLASSES[k === '0' ? 9 : Number(k) - 1]; if (c) setClass(c.name); }
      else if (e.key === 'Delete' || e.key === 'Backspace') { if (st.sel != null) removeBox(st.sel); }
      else if (k === 'h') { st.hide = !st.hide; draw(); }
      else if (k === 'o' && opts.compare) { st.showCompare = !st.showCompare; draw(); status(st.showCompare ? '現在顯示的是結果頁原本的影像（有模型的框）。再按 O 切回來。' : '已切回要存檔的影像。'); }
      else if (k === 'f') { fit(); draw(); }
      else if (k === '+' || k === '=') zoomAt(v.s * 1.2, cw / 2, ch / 2);
      else if (k === '-' || k === '_') zoomAt(v.s / 1.2, cw / 2, ch / 2);
      else if (k === 'w') cycleWin();
      else if (k === 'i') setWin(v.bright, v.contrast, !v.invert);
      else if (k === 'r') setWin(100, 100, false);
      else used = false;
      e.stopPropagation(); // 標註畫面開著時，按鍵不交給底下的頁面
      if (used) e.preventDefault();
    };
    const onKeyUp = (e) => { if (e.key === ' ') spaceDown = false; e.stopPropagation(); };
    window.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('keyup', onKeyUp, true);

    // ----- 儲存 -----
    const pad = (n) => String(n).padStart(2, '0');
    let saving = false;
    async function save() {
      if (saving) return;
      const bad = st.boxes.filter((b) => !classOf(b.label));
      if (bad.length) { st.sel = bad[0].id; renderList(); draw(); return status('有 ' + bad.length + ' 個框還沒選類別。', 'err'); }
      if (!st.boxes.length && !st.noFinding) return status('目前沒有任何框。如果這張確實沒有病灶，請勾選「這張沒有任何病灶」再儲存。', 'err');
      if (st.boxes.length && st.noFinding) return status('已勾選「這張沒有任何病灶」，但畫面上還有框，請擇一。', 'err');
      if (!applyDir()) return;
      saving = true;
      status('儲存中…');
      try {
        const d = new Date();
        const off = -d.getTimezoneOffset();
        const savedAt = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) +
          (off >= 0 ? '+' : '-') + pad(Math.floor(Math.abs(off) / 60)) + ':' + pad(Math.abs(off) % 60);
        const plain = st.boxes.map((b) => ({ label: b.label, source: b.source, x1: b.x1, y1: b.y1, x2: b.x2, y2: b.y2 }));
        const made = await opts.makeFiles({ boxes: plain, noFinding: st.noFinding, note: st.note, savedAt, wantDicom: !!opts.dicomOption && st.wantDicom });
        const files = made.map((f) => ({ filename: st.dir + '/' + f.filename, url: f.url }));
        const res = await chrome.runtime.sendMessage({ type: 'cxr-save', files });
        if (!res || !res.ok) throw new Error((res && res.error) || '背景程式沒有回應');
        const savedAtText = pad(d.getMonth() + 1) + '/' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
        st.dirty = false;
        try {
          await chrome.storage.local.set({ [opts.storeKey]: { boxes: plain, w: W, h: H, noFinding: st.noFinding, note: st.note, savedAtText } });
        } catch (e) { /* 記不住上次標註不影響已存的檔 */ }
        if (opts.onSaved) opts.onSaved(savedAtText);
        const first = (res.paths && res.paths[0]) || '';
        status('已儲存 ' + files.length + ' 個檔（' + st.boxes.length + ' 個框）：' + first.replace(/[\\/][^\\/]*$/, ''), 'ok');
      } catch (e) {
        const msg = String((e && e.message) || e);
        status('儲存失敗：' + msg + (/context invalidated/i.test(msg) ? '（外掛剛更新過，請重新整理這一頁再試）' : ''), 'err');
      } finally {
        saving = false;
      }
    }

    const ro = new ResizeObserver(resize);
    function close(force) {
      if (!force && st.dirty && !confirm('標註還沒儲存，確定要關閉嗎？')) return false;
      window.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('keyup', onKeyUp, true);
      ro.disconnect();
      host.remove();
      document.documentElement.style.overflow = prevOverflow;
      current = null;
      if (opts.onClose) opts.onClose();
      return true;
    }
    const api = { close, status, isDirty: () => st.dirty };

    $('#save').addEventListener('click', save);
    $('#close').addEventListener('click', () => close(false));
    const resetBtn = $('#reset');
    if (opts.resetBoxes) resetBtn.addEventListener('click', () => { remember('還原成模型的框'); st.boxes = withId(opts.resetBoxes()); st.sel = null; touch(); renderList(); draw(); status('已還原成模型的 ' + st.boxes.length + ' 個框。'); });
    else resetBtn.hidden = true;
    (opts.extraButtons || []).forEach((x) => { const b = el('button', 'btn', x.label); b.type = 'button'; b.addEventListener('click', () => x.onClick(api)); $('#extra').appendChild(b); });
    const nf = $('#nofinding');
    nf.checked = st.noFinding;
    nf.addEventListener('change', () => { const was = snap(); was.noFinding = !nf.checked; remember('勾選「沒有病灶」', was); st.noFinding = nf.checked; touch(); });
    if (opts.dicomOption) {
      $('#dicomrow').hidden = false;
      const dc = $('#dicom');
      dc.checked = st.wantDicom;
      dc.addEventListener('change', () => { st.wantDicom = dc.checked; chrome.storage.local.set({ 'opt:dicom': st.wantDicom }).catch(() => {}); });
    }
    const note = $('#note');
    note.value = st.note;
    note.addEventListener('input', () => { st.note = note.value; touch(); });
    // 存檔資料夾：填的是「下載」底下的相對路徑；合法才採用並記住，不合法就說明、不存檔
    const dirInput = $('#dir');
    dirInput.value = st.dir;
    function applyDir() {
      const clean = C.cleanDir(dirInput.value);
      if (!clean) {
        status('存檔資料夾的寫法不能用。請填「下載」底下的資料夾名稱，例如 CXR_relabel 或 CXR_relabel/2026-11（不能有磁碟代號、..，或 < > : " | ? * 這些字元）。', 'err');
        return false;
      }
      if (clean !== st.dir) { st.dir = clean; chrome.storage.local.set({ 'opt:dir': clean }).catch(() => {}); }
      dirInput.value = clean;
      return true;
    }
    dirInput.addEventListener('change', () => { if (applyDir()) status('之後都會存到「下載\\' + st.dir.replace(/\//g, '\\') + '」。'); });

    // 顯示（亮度／對比／反白）控制項
    renderWins();
    $('#bright').addEventListener('input', (e) => setWin(Number(e.target.value), v.contrast, v.invert, true));
    $('#contrast').addEventListener('input', (e) => setWin(v.bright, Number(e.target.value), v.invert, true));

    renderClasses();
    renderList();
    ro.observe(stage);
    resize();
    status((loadedSaved ? '已載入上次存檔的標註，可以接著改。' : '') + (opts.intro || ''));
    current = api;
    return api;
  }

  root.CXREditor = { open };
})(globalThis);
