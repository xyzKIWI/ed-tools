// 背景程式：
//   1. 把標註畫面交來的檔案存進「下載」資料夾底下的 CXR_relabel（url 一律是 data:，不連網路）。
//   2. 在分頁之間轉送：AI 結果頁／標註分頁／回顧小視窗 ⇄ 已登入的 WebPACS 分頁，
//      或急診清單分頁裡免登入接上 WebPACS 的隱藏框架（0.7.0）。
//      取圖的請求是 WebPACS 分頁自己發的（pacs.js），背景程式只傳話，不碰通行碼。

importScripts('core.js'); // 用到 CXRCore.cleanDir（檢查存檔資料夾）與 CXRCore.siteByHost（院區對應）

const waitDone = (id) =>
  new Promise((resolve) => {
    const t0 = Date.now();
    const tick = async () => {
      const [it] = await chrome.downloads.search({ id });
      if (it && it.state === 'complete') return resolve({ ok: true, path: it.filename });
      if (it && it.state === 'interrupted') return resolve({ ok: false, error: it.error || 'interrupted' });
      if (Date.now() - t0 > 60000) return resolve({ ok: false, error: '等待存檔逾時' });
      setTimeout(tick, 150);
    };
    tick();
  });

async function save(files) {
  const paths = [];
  for (const f of files) {
    // 檔名＝「下載」底下的資料夾／檔案。資料夾要過 cleanDir（不能跳出「下載」），檔案只收這幾種。
    const cut = String(f.filename).lastIndexOf('/');
    const dir = f.filename.slice(0, cut), name = f.filename.slice(cut + 1);
    if (!/^data:/.test(f.url) || cut < 1 || CXRCore.cleanDir(dir) !== dir || !/^[\w.-]+\.(png|jpg|json|dcm)$/.test(name)) throw new Error('不接受的檔案：' + f.filename);
    const id = await chrome.downloads.download({ url: f.url, filename: f.filename, conflictAction: 'overwrite', saveAs: false });
    const r = await waitDone(id);
    if (!r.ok) throw new Error(f.filename + '：' + r.error);
    paths.push(r.path);
  }
  return { ok: true, paths };
}

// 只問「同一院區」開著的 WebPACS 分頁；第一個查得到的就用它。
// 院區由發問的結果頁網址決定（sender.url），不跨院查。
async function pacsFind(accession, patientId, fromUrl) {
  let host = '';
  try { host = new URL(fromUrl).hostname; } catch (e) { /* 讀不到就當不認得的院區 */ }
  const site = CXRCore.siteByHost(host);
  if (!site) return { ok: false, reason: 'no-site', detail: host };
  const tabs = await chrome.tabs.query({ url: 'https://' + site.pacs + '/*' });
  if (!tabs.length) return { ok: false, reason: 'no-tab', site: site.name };
  let last = { ok: false, reason: 'no-session', site: site.name };
  const rank = { 'no-session': 0, 'not-found': 1, 'patient-mismatch': 2 };
  for (const tab of tabs) {
    let r;
    try { r = await chrome.tabs.sendMessage(tab.id, { type: 'pacs-lookup', accession, patientId }); }
    catch (e) { r = null; } // 那個分頁沒有查詢框架（登入頁），或是外掛安裝前開的
    if (r && r.ok) return Object.assign(r, { tabId: tab.id, site: site.name });
    if (r && (rank[r.reason] || 0) >= (rank[last.reason] || 0)) last = Object.assign(r, { site: site.name });
  }
  return last;
}

async function pacsImage(tabId, uid, kind) {
  try { return (await chrome.tabs.sendMessage(tabId, { type: 'pacs-fetch', uid, kind })) || { ok: false, reason: 'no-session' }; }
  catch (e) { return { ok: false, reason: 'no-session' }; }
}

// 從 WebPACS 的「標註」按鈕來：把這次要標的影像記在記憶體（關瀏覽器就消失），開標註分頁
// （PACS 回顧小視窗的「標註」不經過這裡，直接在小視窗裡開標註畫面）
async function openEditor(job, tab) {
  const id = crypto.randomUUID();
  await chrome.storage.session.set({ ['job:' + id]: { uid: String(job.uid || ''), meta: job.meta || {}, tabId: tab.id } });
  await chrome.tabs.create({ url: chrome.runtime.getURL('editor.html') + '#' + id, index: tab.index + 1, openerTabId: tab.id });
  return { ok: true };
}

// ---------- PACS 回顧：急診清單 → 外掛的回顧分頁 ⇄ 同院區的 WebPACS 分頁 ----------
// 院區：清單送來時看清單頁的網址；回顧分頁之後的請求帶著當時記下的院區代號。
const siteById = (id) => CXRCore.SITES.find((s) => s.id === id) || null;
const siteOfSender = (sender) => { try { return CXRCore.siteByHost(new URL(sender.url || (sender.tab && sender.tab.url) || '').hostname); } catch (e) { return null; } };

// 回顧固定用一個小視窗（0.6.0）：第一次開時建立，之後換病人就把那個視窗換成新的病人。
// follow：清單上點選了別的病人——只在小視窗已經開著時換內容，而且不搶焦點（使用者還在清單上操作）。
async function reviewWindow() {
  const w = (await chrome.storage.session.get('reviewWin')).reviewWin;
  if (!w) return null;
  try { const tab = await chrome.tabs.get(w.tabId); return tab.windowId === w.windowId ? w : null; } catch (e) { return null; }
}
async function openReview(job, sender, follow) {
  const site = siteOfSender(sender);
  if (!site || !sender.tab) return { ok: false, reason: 'no-site' };
  const chart = String(job.chart || '');
  if (!/^\d{4,12}$/.test(chart)) return { ok: false, reason: 'bad-chart' };
  const win = await reviewWindow();
  if (follow && !win) return { ok: true, skipped: true };
  const focus = async (w) => { if (!follow) await chrome.windows.update(w.windowId, { focused: true }).catch(() => {}); };
  if (win && win.chart === chart && win.site === site.id && win.listOut === !!job.listOut) {
    if (win.erTabId !== sender.tab.id) await chrome.storage.session.set({ reviewWin: Object.assign({}, win, { erTabId: sender.tab.id }) });
    await focus(win);
    return { ok: true, same: true };
  }
  const keep = {};
  for (const k of ['name', 'bed', 'seq', 'since', 'until', 'status']) keep[k] = String(job[k] == null ? '' : job[k]).slice(0, 40);
  // AI 判讀結果頁：只收同一個院內主機上的 AI 平台網址
  let aiurl = '';
  try { const u = new URL(String(job.aiurl || '')); if (u.protocol === 'https:' && u.hostname === site.ai && /^\/web\/aiplatform\//i.test(u.pathname)) aiurl = u.href; } catch (e) { /* 沒有就不顯示 */ }
  const id = crypto.randomUUID();
  await chrome.storage.session.set({ ['review:' + id]: Object.assign(keep, { site: site.id, chart, aiurl, listOut: !!job.listOut }) });
  const url = chrome.runtime.getURL('review.html') + '#' + id;
  // erTabId：開回顧的那個急診清單分頁——免登入接上 WebPACS 的隱藏框架在那一頁裡（0.7.0）
  const info = { chart, site: site.id, listOut: !!job.listOut, jobId: id, erTabId: sender.tab.id };
  if (win) {
    await chrome.tabs.update(win.tabId, { url }); // 只換 # 後面：回顧頁自己決定什麼時候換（標註還沒存時會先等）
    if (win.jobId) await chrome.storage.session.remove('review:' + win.jobId);
    await chrome.storage.session.set({ reviewWin: Object.assign({}, win, info) });
    await focus(win);
  } else {
    const b = (await chrome.storage.local.get('reviewBounds')).reviewBounds || { width: 1000, height: 900 };
    const w = await chrome.windows.create(Object.assign({ url, type: 'popup', focused: true }, b));
    await chrome.storage.session.set({ reviewWin: Object.assign({ windowId: w.id, tabId: w.tabs[0].id }, info) });
  }
  return { ok: true };
}
// 小視窗的位置與大小記起來，下次照樣開
chrome.windows.onBoundsChanged.addListener(async (w) => {
  const r = await reviewWindow();
  if (r && r.windowId === w.id && w.state === 'normal') chrome.storage.local.set({ reviewBounds: { left: w.left, top: w.top, width: w.width, height: w.height } });
});

// 開回顧的那個急診清單分頁（同院區才算）：裡面可能有免登入接上 WebPACS 的隱藏框架（0.7.0）
async function erTab(siteId) {
  const w = await reviewWindow();
  return w && w.site === siteId && Number.isInteger(w.erTabId) ? w.erTabId : null;
}
// 先問同院區每一個開著的 WebPACS 分頁（使用者自己登入的），再問急診清單分頁裡的隱藏框架；
// 第一個答得出來的就用它（回覆裡帶 tabId，之後的縮圖、原圖都找它）。
// 都不行時，auto＝可以試免登入接上（有急診清單分頁可以去要連結）。
async function pacsStudies(siteId, chart, er = null, deadline = Infinity, bridge = false, hiddenOnly = false) {
  const site = siteById(siteId);
  if (!site) return { ok: false, reason: 'no-site' };
  const query = async (tabId, hidden) => {
    const wait = bridge ? Math.min(4000, deadline - Date.now()) : Infinity;
    if (wait <= 0) return null;
    let timer;
    try {
      const response = chrome.tabs.sendMessage(tabId, { type: 'pacs-studies', chart, pacsHost: site.pacs, hidden, bridge });
      if (!bridge) return await response;
      const timeout = new Promise((resolve) => { timer = setTimeout(resolve, wait, null); });
      return await Promise.race([response, timeout]);
    } catch (e) {
      return null;
    } finally {
      clearTimeout(timer);
    }
  };
  const tabs = hiddenOnly ? [] : await chrome.tabs.query({ url: 'https://' + site.pacs + '/*' });
  let last = { ok: false, reason: hiddenOnly || tabs.length ? 'no-session' : 'no-tab', site: site.name };
  for (const tab of tabs) {
    const r = await query(tab.id, false);
    if (r && r.ok) return Object.assign(r, { tabId: tab.id, site: site.name });
    if (r && r.reason !== 'no-session') last = Object.assign(r, { site: site.name });
  }
  er ??= await erTab(siteId);
  if (er != null) {
    const r = await query(er, true);
    if (r && r.ok) return Object.assign(r, { tabId: er, site: site.name, hidden: true });
    if (r && r.reason !== 'no-session') last = Object.assign(r, { site: site.name });
  }
  return Object.assign(last, { auto: er != null });
}

// 急診工作台的查詢以發出請求的急診清單分頁為準，不靠回顧小視窗的狀態。
async function bridgeStudies(chart, sender, deadline, hiddenOnly) {
  const site = siteOfSender(sender);
  if (!site || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id)) return { ok: false, reason: 'error' };
  const r = await pacsStudies(site.id, chart, sender.tab.id, deadline, true, hiddenOnly);
  if (!r.ok) return { ok: false, reason: r.reason };
  return CXRCore.pacsBridgeStudyResult(r, Date.now());
}

// 急診工作台的配對只記外掛編號與提示時間。背景程式依序更新，避免同時請求或操作設定頁時蓋掉其他編號。
const ERW_PROMPT_INTERVAL = 10 * 60 * 1000;
const isExtensionId = (id) => typeof id === 'string' && /^[a-p]{32}$/.test(id);
let erwPermissionQueue = Promise.resolve();
function withErwPermissions(update) {
  const job = erwPermissionQueue.then(async () => {
    const { erwAllowed = [], erwRequests = {} } = await chrome.storage.local.get(['erwAllowed', 'erwRequests']);
    return update(erwAllowed, erwRequests);
  });
  erwPermissionQueue = job.catch(() => {});
  return job;
}
function allowErwSender(id) {
  if (!isExtensionId(id)) return Promise.resolve(false);
  return withErwPermissions(async (allowed, requests) => {
    if (allowed.includes(id)) return true;
    const now = Date.now();
    if (requests[id] && now - requests[id].at < ERW_PROMPT_INTERVAL) return false;
    for (const [otherId, request] of Object.entries(requests)) {
      if (!request.pending && now - request.at >= ERW_PROMPT_INTERVAL) delete requests[otherId];
    }
    requests[id] = { at: now, pending: true };
    await chrome.storage.local.set({ erwRequests: requests });
    chrome.runtime.openOptionsPage().catch(() => {});
    return false;
  });
}
function changeErwPermission({ id, action }) {
  if (!isExtensionId(id) || !['allow', 'deny', 'remove'].includes(action)) return Promise.resolve({ ok: false });
  return withErwPermissions(async (allowed, requests) => {
    if (action === 'remove') allowed = allowed.filter((entry) => entry !== id);
    else {
      if (!requests[id]?.pending) return { ok: false, reason: 'already-decided' };
      requests[id].pending = false;
      if (action === 'allow' && !allowed.includes(id)) allowed.push(id);
    }
    await chrome.storage.local.set({ erwAllowed: allowed, erwRequests: requests });
    return { ok: true };
  });
}

async function handleErwRequest(msg, sender, started) {
  if (!(await allowErwSender(sender.id))) return { ok: false, reason: 'not-allowed' };
  const req = CXRCore.parsePacsBridgeRequest(msg);
  if (!req) return { ok: false, reason: 'bad-request' };

  const studies = req.op === 'studies';
  const deadline = started + (studies ? 13000 : 4500);
  const expired = { ok: false, reason: studies ? 'no-session' : 'error' };
  if (Date.now() >= deadline) return expired;
  let timer;
  const timeout = new Promise((resolve) => {
    // 讓 ER_Main 先結束逾時的查詢並解除忙碌狀態，背景仍在 14 秒內保證回覆。
    timer = setTimeout(resolve, deadline - Date.now() + (studies ? 500 : 0), expired);
  });
  try {
    const job = chrome.tabs.sendMessage(req.tabId, { type: 'er-pacs-bridge', op: req.op, site: req.site, chart: req.chart, deadline }, { frameId: 0 });
    const reply = await Promise.race([job, timeout]);
    if (!reply) return { ok: false, reason: 'no-er-tab' };
    if (!reply.ok) return { ok: false, reason: reply.reason };
    return studies ? { ok: true, studies: reply.studies, incomplete: reply.incomplete } : { ok: true };
  } catch (e) {
    return { ok: false, reason: 'no-er-tab' };
  } finally {
    clearTimeout(timer);
  }
}

chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'erw-pacs') return;
  handleErwRequest(msg, sender, Date.now()).then(
    (reply) => sendResponse({ v: 2, ...reply }),
    () => sendResponse({ v: 2, ok: false, reason: 'error' }),
  );
  return true;
});

// 免登入接上 WebPACS：請那個急診清單分頁（erlist.js）去要這位病人的開圖連結並打開
async function pacsConnect(siteId, chart) {
  const er = await erTab(siteId);
  if (er == null) return { ok: false, reason: 'no-er-tab' };
  try { return (await chrome.tabs.sendMessage(er, { type: 'er-pacs-connect', chart }, { frameId: 0 })) || { ok: false, reason: 'no-er-tab' }; }
  catch (e) { return { ok: false, reason: 'no-er-tab' }; } // 那個分頁關掉了、離開清單了，或是外掛更新前開的
}
async function toPacsTab(tabId, message) {
  try {
    const w = await reviewWindow();
    if (!(w && w.erTabId === tabId)) {
      const tab = await chrome.tabs.get(tabId);
      if (!CXRCore.SITES.some((s) => new URL(tab.url).hostname === s.pacs)) return { ok: false, reason: 'no-session' }; // 那個分頁已經不是 WebPACS
    }
    return (await chrome.tabs.sendMessage(tabId, message)) || { ok: false, reason: 'no-session' };
  }
  catch (e) { return { ok: false, reason: 'no-session' }; }
}
async function pacsShow(tabId, chart) {
  const r = await toPacsTab(tabId, { type: 'pacs-show', chart });
  if (r.ok) {
    const tab = await chrome.tabs.update(tabId, { active: true });
    if (tab && tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  }
  return r;
}
// 到 WebPACS 登入：已經有這個院區的 WebPACS 分頁（登入過期、或外掛更新前開的）就用那一個，不另開；
// 沒有就在一般的瀏覽器視窗開一個（回顧小視窗是彈出視窗，不能放分頁）。帳號密碼由使用者自己輸入。
async function openPacsLogin(siteId) {
  const site = siteById(siteId);
  if (!site) return { ok: false, reason: 'no-site' };
  const url = 'https://' + site.pacs + '/DicomWeb/';
  const [tab] = await chrome.tabs.query({ url: 'https://' + site.pacs + '/*' });
  let target;
  if (tab) target = await chrome.tabs.update(tab.id, { url, active: true });
  else {
    const wins = await chrome.windows.getAll({ windowTypes: ['normal'] });
    const win = wins.find((w) => w.focused) || wins[0];
    target = win ? await chrome.tabs.create({ windowId: win.id, url, active: true }) : (await chrome.windows.create({ url, type: 'normal' })).tabs[0];
  }
  await chrome.windows.update(target.windowId, { focused: true }).catch(() => {});
  return { ok: true };
}
// WebPACS 分頁每次載入完成（例如登入後進到查詢畫面）就通知回顧小視窗；在等的話它會自己再查一次。
chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.status !== 'complete' || !tab.url) return;
  let host = '';
  try { host = new URL(tab.url).hostname; } catch (e) { return; }
  const site = CXRCore.SITES.find((s) => s.pacs === host);
  if (site) chrome.runtime.sendMessage({ type: 'pacs-tab-ready', site: site.id }).catch(() => {}); // 沒有回顧小視窗開著就沒人收
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;
  let job;
  if (msg.type === 'cxr-save') job = save(msg.files || []);
  else if (msg.type === 'pacs-find') job = pacsFind(String(msg.accession || ''), String(msg.patientId || ''), sender.url || (sender.tab && sender.tab.url) || '');
  else if (msg.type === 'pacs-image') job = pacsImage(msg.tabId, String(msg.uid || ''), msg.kind);
  else if (msg.type === 'pacs-open-editor' && sender.tab) job = openEditor(msg.job || {}, sender.tab);
  else if (msg.type === 'review-open') job = openReview(msg.job || {}, sender, false);
  else if (msg.type === 'review-follow') job = openReview(msg.job || {}, sender, true);
  else if (msg.type === 'review-studies') job = pacsStudies(String(msg.site || ''), String(msg.chart || ''));
  else if (msg.type === 'er-pacs-studies') job = bridgeStudies(String(msg.chart || ''), sender, msg.deadline, msg.hiddenOnly === true);
  else if (msg.type === 'review-thumbs') job = toPacsTab(msg.tabId, { type: 'pacs-thumbs', studyId: String(msg.studyId || '') });
  else if (msg.type === 'review-show') job = pacsShow(msg.tabId, String(msg.chart || ''));
  else if (msg.type === 'review-login') job = openPacsLogin(String(msg.site || ''));
  else if (msg.type === 'review-connect') job = pacsConnect(String(msg.site || ''), String(msg.chart || ''));
  else if (msg.type === 'erw-permission' && sender.url === chrome.runtime.getURL('options.html')) job = changeErwPermission(msg);
  // 急診清單問它自己那一頁裡的隱藏框架「接上了沒」（頁面腳本之間不能直接傳話，經過這裡轉）
  else if (msg.type === 'er-pacs-ping' && sender.tab) job = chrome.tabs.sendMessage(sender.tab.id, { type: 'pacs-ping', pacsHost: siteOfSender(sender)?.pacs }).then((r) => r || { ok: false }, () => ({ ok: false }));
  else return;
  job.then(sendResponse, (e) => sendResponse({ ok: false, reason: 'error', error: String((e && e.message) || e), detail: String((e && e.message) || e) }));
  return true; // 非同步回覆
});
