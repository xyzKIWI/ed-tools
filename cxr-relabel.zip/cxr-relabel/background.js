// 背景程式：
//   1. 把標註畫面交來的檔案存進「下載」資料夾底下的 CXR_relabel（url 一律是 data:，不連網路）。
//   2. 在分頁之間轉送：AI 結果頁／標註分頁 ⇄ 已登入的 WebPACS 分頁。
//      取圖的請求是 WebPACS 分頁自己發的（pacs.js），背景程式只傳話，不碰通行碼。

importScripts('core.js'); // 用到 CXRCore.cleanDir（檢查存檔資料夾）與 CXRCore.siteByHost（院區對應）

const waitDone = (id) =>
  new Promise((resolve) => {
    const t0 = Date.now();
    const tick = async () => {
      const [it] = await chrome.downloads.search({ id });
      if (it && it.state === 'complete') return resolve({ ok: true, path: it.filename });
      if (it && it.state === 'interrupted') return resolve({ ok: false, error: it.error || 'interrupted' });
      if (Date.now() - t0 > 60000) return resolve({ ok: false, error: '等待存檔逾時' });
      setTimeout(tick, 150);
    };
    tick();
  });

async function save(files) {
  const paths = [];
  for (const f of files) {
    // 檔名＝「下載」底下的資料夾／檔案。資料夾要過 cleanDir（不能跳出「下載」），檔案只收這幾種。
    const cut = String(f.filename).lastIndexOf('/');
    const dir = f.filename.slice(0, cut), name = f.filename.slice(cut + 1);
    if (!/^data:/.test(f.url) || cut < 1 || CXRCore.cleanDir(dir) !== dir || !/^[\w.-]+\.(png|jpg|json|dcm)$/.test(name)) throw new Error('不接受的檔案：' + f.filename);
    const id = await chrome.downloads.download({ url: f.url, filename: f.filename, conflictAction: 'overwrite', saveAs: false });
    const r = await waitDone(id);
    if (!r.ok) throw new Error(f.filename + '：' + r.error);
    paths.push(r.path);
  }
  return { ok: true, paths };
}

// 只問「同一院區」開著的 WebPACS 分頁；第一個查得到的就用它。
// 院區由發問的結果頁網址決定（sender.url），不跨院查。
async function pacsFind(accession, patientId, fromUrl) {
  let host = '';
  try { host = new URL(fromUrl).hostname; } catch (e) { /* 讀不到就當不認得的院區 */ }
  const site = CXRCore.siteByHost(host);
  if (!site) return { ok: false, reason: 'no-site', detail: host };
  const tabs = await chrome.tabs.query({ url: 'https://' + site.pacs + '/*' });
  if (!tabs.length) return { ok: false, reason: 'no-tab', site: site.name };
  let last = { ok: false, reason: 'no-session', site: site.name };
  const rank = { 'no-session': 0, 'not-found': 1, 'patient-mismatch': 2 };
  for (const tab of tabs) {
    let r;
    try { r = await chrome.tabs.sendMessage(tab.id, { type: 'pacs-lookup', accession, patientId }); }
    catch (e) { r = null; } // 那個分頁沒有查詢框架（登入頁），或是外掛安裝前開的
    if (r && r.ok) return Object.assign(r, { tabId: tab.id, site: site.name });
    if (r && (rank[r.reason] || 0) >= (rank[last.reason] || 0)) last = Object.assign(r, { site: site.name });
  }
  return last;
}

async function pacsImage(tabId, uid, kind) {
  try { return (await chrome.tabs.sendMessage(tabId, { type: 'pacs-fetch', uid, kind })) || { ok: false, reason: 'no-session' }; }
  catch (e) { return { ok: false, reason: 'no-session' }; }
}

// 從 WebPACS 的「標註」按鈕來：把這次要標的影像記在記憶體（關瀏覽器就消失），開標註分頁
async function openEditor(job, tab) {
  const id = crypto.randomUUID();
  await chrome.storage.session.set({ ['job:' + id]: { uid: String(job.uid || ''), meta: job.meta || {}, tabId: tab.id } });
  await chrome.tabs.create({ url: chrome.runtime.getURL('editor.html') + '#' + id, index: tab.index + 1, openerTabId: tab.id });
  return { ok: true };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;
  let job;
  if (msg.type === 'cxr-save') job = save(msg.files || []);
  else if (msg.type === 'pacs-find') job = pacsFind(String(msg.accession || ''), String(msg.patientId || ''), sender.url || (sender.tab && sender.tab.url) || '');
  else if (msg.type === 'pacs-image') job = pacsImage(msg.tabId, String(msg.uid || ''), msg.kind);
  else if (msg.type === 'pacs-open-editor' && sender.tab) job = openEditor(msg.job || {}, sender.tab);
  else return;
  job.then(sendResponse, (e) => sendResponse({ ok: false, reason: 'error', error: String((e && e.message) || e), detail: String((e && e.message) || e) }));
  return true; // 非同步回覆
});
