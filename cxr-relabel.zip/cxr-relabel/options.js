/* global chrome */
'use strict';

const labels = { allow: '允許', deny: '不允許', remove: '移除' };
const status = document.getElementById('status');
let rendering = 0;

function renderList(name, ids, actions) {
  const list = document.getElementById(name);
  const focus = document.activeElement;
  const restoreFocus = list.contains(focus);
  let replacement;
  list.replaceChildren();
  document.getElementById(name + '-empty').hidden = ids.length > 0;
  for (const id of ids) {
    const li = document.createElement('li');
    const code = document.createElement('code');
    code.textContent = id;
    const label = document.createElement('p');
    if (name === 'pending') label.append('一支外掛（編號 ', code, '）想查詢病人的 PACS 影像狀態與開 PACS 回顧。請到 chrome://extensions 核對這個編號是不是「急診工作台」，是才按允許。');
    else label.append(code);
    const buttons = document.createElement('div');
    buttons.className = 'actions';
    for (const action of actions) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = labels[action];
      button.dataset.action = action;
      button.dataset.id = id;
      button.setAttribute('aria-label', labels[action] + '外掛 ' + id);
      if (restoreFocus && focus.dataset.id === id && focus.dataset.action === action) replacement = button;
      buttons.append(button);
    }
    li.append(label, buttons);
    list.append(li);
  }
  if (restoreFocus) (replacement || document.getElementById(name + '-title')).focus();
}

async function render() {
  const revision = ++rendering;
  const { erwAllowed = [], erwRequests = {} } = await chrome.storage.local.get(['erwAllowed', 'erwRequests']);
  if (revision !== rendering) return;
  const pending = Object.keys(erwRequests).filter((id) => erwRequests[id].pending && !erwAllowed.includes(id));
  renderList('pending', pending, ['allow', 'deny']);
  renderList('allowed', erwAllowed, ['remove']);
}

document.querySelector('main').addEventListener('click', async (event) => {
  const button = event.target.closest('button[data-action]');
  if (!button) return;
  const { action, id } = button.dataset;
  try {
    const reply = await chrome.runtime.sendMessage({ type: 'erw-permission', action, id });
    if (reply?.reason === 'already-decided') {
      await render();
      status.textContent = '這個請求已經在別的分頁處理過了。';
      return;
    }
    if (!reply?.ok) throw new Error();
    status.textContent = { allow: '已允許存取。', deny: '已拒絕這次請求。', remove: '已移除存取權。' }[action];
  } catch (e) {
    status.textContent = '無法更新設定，請再試一次。';
  }
});

function refresh() {
  render().catch(() => { status.textContent = '無法讀取設定，請重新載入此頁。'; });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.erwAllowed || changes.erwRequests)) refresh();
});
refresh();
