/* CXR 重新標註：外掛自己的標註分頁（從 WebPACS 的「標註」按鈕開）。
 * 要標哪一張記在 chrome.storage.session（只在記憶體，關瀏覽器就消失），網址上只有一組隨機代號。
 * 取圖與存檔的做法在 pacs-editor.js（PACS 回顧小視窗也用同一份）。 */
(async function () {
  'use strict';
  const msg = document.getElementById('msg');
  const stop = (t) => { msg.hidden = false; msg.textContent = t; };

  const key = 'job:' + location.hash.slice(1);
  const job = (await chrome.storage.session.get(key))[key];
  if (!job || !job.uid) return stop('找不到這次要標註的影像（瀏覽器重開過，或這個分頁是舊的）。請回 WebPACS 重新按「標註」。');

  await globalThis.CXRPacsEditor.open(job, {
    onError: stop,
    onReady: (page) => { msg.hidden = true; document.title = 'CXR 標註 ' + (page.accession_no || ''); },
    onClose: () => chrome.tabs.getCurrent((t) => (t ? chrome.tabs.remove(t.id) : window.close())),
  });
})();
