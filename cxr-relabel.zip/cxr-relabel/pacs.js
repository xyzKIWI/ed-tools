/* CXR 重新標註：WebPACS（SoliPACS Web Server）的頁面腳本，每個框架都會載入。
 * 兩個角色：
 *   1. 查詢框架（Queryfrm）：替外掛「用檢查單號找影像」與「下載影像」。登入後的通行碼（AccKey）
 *      就在這個框架的查詢表單裡，只在這裡當場使用，不存、不外傳。
 *   2. 有影像縮圖的框架：每張影像下面加一顆「標註」按鈕，按下去開外掛的標註分頁。
 * 對 PACS 唯讀：只發查詢與下載的 GET，不改任何資料。 */
(function () {
  'use strict';
  const BASE = '/DicomWeb/DicomWeb.dll/';
  const MAX_IMAGES = 8;     // 一筆檢查最多列幾張給外掛挑
  const MAX_DECORATE = 12;  // 一個框架裡超過這麼多張（CT 之類）就不加按鈕

  const text = (el) => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');
  const fail = (reason, detail) => ({ ok: false, reason, detail: detail || '' });

  // ---------- 共用：欄位位置 ----------
  // 檢查清單的欄位沒有名字，只能從表頭的排序動作認：onclick 裡有 SortPatient('AccNo') 的那一欄就是檢查單號。
  function columnIndex(row) {
    const out = {};
    const table = row && row.closest('table');
    const head = table && table.rows[0];
    if (head) [...head.cells].forEach((td, i) => { const m = /SortPatient\('(\w+)'\)/.exec(td.getAttribute('onclick') || ''); if (m) out[m[1]] = i; });
    return out;
  }
  function studyInfo(row) {
    const col = columnIndex(row);
    const cell = (name) => (col[name] != null ? text(row.cells[col[name]]) : '');
    return { accession_no: cell('AccNo'), patient_id: cell('PatientID'), date: row.getAttribute('studydate') || '', body_part: row.getAttribute('bodypart') || '', hasAccColumn: col.AccNo != null };
  }

  // ---------- 角色 1：查詢與下載（只在查詢框架） ----------
  function accKey() {
    const f = document.forms['QueryPatient'];
    return (f && f.AccKey && f.AccKey.value) || '';
  }
  async function getDoc(path, params) {
    const r = await fetch(BASE + path + '?' + new URLSearchParams(params), { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { reason: 'no-session' });
    return new DOMParser().parseFromString(await r.text(), 'text/html');
  }
  async function wado(uid, key, extra) {
    const r = await fetch(BASE + 'WADO?' + new URLSearchParams(Object.assign({ requestType: 'WADO', objectUID: uid }, extra, { AccKey: key })), { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { reason: 'no-session' });
    return r.blob();
  }
  const toDataUrl = (blob) => new Promise((resolve, reject) => { const fr = new FileReader(); fr.onload = () => resolve(fr.result); fr.onerror = () => reject(fr.error); fr.readAsDataURL(blob); });

  // 病歷號比對用：只留數字、去掉開頭的 0（和 core.js 的 chartKey 同一個規則；這支腳本不載入 core.js）
  const chartKey = (v) => String(v == null ? '' : v).replace(/\D/g, '').replace(/^0+/, '');

  async function lookup(accession, patientId) {
    const key = accKey();
    if (!key) return fail('no-session');
    const sd = await getDoc('QueryPatientStudy', { AID: accession, AccKey: key });
    let rows = [...sd.querySelectorAll('tr[study_uid_id]')];
    if (!rows.length) return fail(sd.querySelector('form[name="QuerySeries"],form#QuerySeries,form[name="ViewImage"],form#ViewImage') ? 'not-found' : 'no-session');
    // 查詢可能不是完全比對：認得出檢查單號那一欄就只留完全相同的；認不出來時只接受「剛好一筆」
    if (studyInfo(rows[0]).hasAccColumn) rows = rows.filter((r) => studyInfo(r).accession_no === accession);
    else if (rows.length > 1) rows = [];
    if (!rows.length) return fail('not-found');
    // 結果頁有給病歷號、PACS 也讀得到病歷號時，兩邊要一致；不一致就不用（寧可退回，也不要標到別人的影像）
    const want = chartKey(patientId);
    if (want) {
      const known = rows.filter((r) => chartKey(studyInfo(r).patient_id));
      const same = known.filter((r) => chartKey(studyInfo(r).patient_id) === want);
      if (known.length && !same.length) return fail('patient-mismatch');
      if (same.length) rows = same;
    }
    const row = rows[0];
    const images = [];
    const ser = await getDoc('QuerySeriesImage', { STUDY_UID_ID: row.getAttribute('study_uid_id'), AccKey: key });
    for (const s of ser.querySelectorAll('tr[series_uid_id]')) {
      if (s.getAttribute('prko') === '1' || images.length >= MAX_IMAGES) continue; // prko=1 是標記／呈現狀態，不是影像
      const idoc = await getDoc('QueryImage', { Series_UID_ID: s.getAttribute('series_uid_id'), AccKey: key });
      for (const im of idoc.querySelectorAll('img[imagefile]')) {
        if (im.getAttribute('prko') === '1' || images.length >= MAX_IMAGES) continue;
        images.push({ uid: im.getAttribute('imagefile') });
      }
    }
    if (!images.length) return fail('not-found');
    for (const im of images) im.small = await toDataUrl(await wado(im.uid, key, { rows: '128' })); // 小圖，給外掛比對是哪一張
    const info = studyInfo(row);
    return { ok: true, images, study: { studyDate: info.date, bodyPart: info.body_part, patientId: info.patient_id } };
  }

  async function fetchObject(uid, kind) {
    const key = accKey();
    if (!key) return fail('no-session');
    const blob = await wado(uid, key, kind === 'dicom' ? { contentType: 'application/dicom' } : {});
    if (kind !== 'dicom' && !/^image\//.test(blob.type)) return fail('error', '伺服器回的不是影像');
    return { ok: true, dataUrl: await toDataUrl(blob), bytes: blob.size };
  }

  if (window.name === 'Queryfrm') {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg || (msg.type !== 'pacs-lookup' && msg.type !== 'pacs-fetch')) return;
      const job = msg.type === 'pacs-lookup' ? lookup(String(msg.accession || ''), String(msg.patientId || '')) : fetchObject(String(msg.uid || ''), msg.kind);
      job.then(sendResponse, (e) => sendResponse(fail(e.reason || 'error', String((e && e.message) || e))));
      return true; // 非同步回覆
    });
  }

  // ---------- 角色 2：影像縮圖下面的「標註」按鈕 ----------
  const frameDoc = (name) => { try { const f = window.top.document.querySelector('frame[name="' + name + '"],iframe[name="' + name + '"]'); return f ? f.contentDocument : null; } catch (e) { return null; } };

  // 這張影像屬於哪一筆檢查：序列框架的網址帶著那筆檢查的編號，再到檢查清單找那一列
  function metaFor() {
    const meta = { accession_no: '', patient_id: '', date: '', body_part: '', empcode: '' };
    try {
      const sdoc = frameDoc('Seriesfrm'), pdoc = frameDoc('Patientfrm');
      const studyId = sdoc ? new URLSearchParams(sdoc.location.search).get('STUDY_UID_ID') : '';
      let row = pdoc && studyId ? [...pdoc.querySelectorAll('tr[study_uid_id]')].find((r) => r.getAttribute('study_uid_id') === studyId) : null;
      if (!row && pdoc) { const marked = pdoc.querySelectorAll('tr[study_uid_id][mark="1"]'); if (marked.length === 1) row = marked[0]; }
      if (row) Object.assign(meta, studyInfo(row));
      const m = /var\s+Username\s*=\s*"([^"]*)"/.exec([...window.top.document.scripts].map((s) => s.textContent).join('\n'));
      if (m) meta.empcode = m[1];
    } catch (e) { /* 讀不到就留空，標註畫面會說明 */ }
    delete meta.hasAccColumn;
    return meta;
  }

  function decorate() {
    const imgs = [...document.querySelectorAll('img[imagefile]')].filter((i) => i.getAttribute('prko') !== '1');
    if (!imgs.length || imgs.length > MAX_DECORATE) return;
    imgs.forEach((img) => {
      if (img.dataset.cxrRelabel) return;
      img.dataset.cxrRelabel = '1';
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'cxr-relabel-btn';
      b.textContent = '✏️ 標註';
      b.title = '用「CXR 重新標註」外掛標這張影像';
      b.style.cssText = 'display:block;margin:2px auto 0;padding:1px 6px;font-size:11px;line-height:1.4;border:1px solid #29b6f6;border-radius:4px;background:#0d3b5c;color:#e1f5fe;cursor:pointer;';
      // 不讓 PACS 頁面自己的滑鼠處理（選取、開 Viewer）接到這顆按鈕的事件
      for (const t of ['mousedown', 'mouseup', 'dblclick']) b.addEventListener(t, (e) => e.stopPropagation());
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        chrome.runtime.sendMessage({ type: 'pacs-open-editor', job: { uid: img.getAttribute('imagefile'), meta: metaFor() } })
          .catch((err) => alert('無法開啟標註分頁：' + String((err && err.message) || err) + '\n（外掛剛更新過的話，請重新整理 WebPACS 這一頁）'));
      });
      img.insertAdjacentElement('afterend', b);
    });
  }
  decorate();
  setTimeout(decorate, 800);
})();
