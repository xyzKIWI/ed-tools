/* CXR 重新標註：WebPACS（SoliPACS Web Server）的頁面腳本，每個框架都會載入。
 * 兩個角色：
 *   1. 查詢框架（Queryfrm）：替外掛「用檢查單號找影像」與「下載影像」。登入後的通行碼（AccKey）
 *      就在這個框架的查詢表單裡，只在這裡當場使用，不存、不外傳。
 *      0.7.0：急診清單頁裡、外掛自己的隱藏框架（名字 cxr-relabel-pacs）也做同樣的事。那個框架開的是
 *      體系病歷「檢查」頁的開圖連結（OpenImage），不用登入就有通行碼；通行碼在那一頁的程式變數裡。
 *   2. 有影像縮圖的框架：每張影像下面加一顆「標註」按鈕，按下去開外掛的標註分頁。
 * 對 PACS 唯讀：只發查詢與下載的 GET，不改任何資料。 */
(function () {
  'use strict';
  const BASE = '/DicomWeb/DicomWeb.dll/';
  const MAX_IMAGES = 8;     // 一筆檢查最多列幾張給外掛挑
  const MAX_DECORATE = 12;  // 一個框架裡超過這麼多張（CT 之類）就不加按鈕

  const text = (el) => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');
  const fail = (reason, detail) => ({ ok: false, reason, detail: detail || '' });

  // ---------- 共用：欄位位置 ----------
  // 檢查清單的欄位沒有名字，只能從表頭的排序動作認：onclick 裡有 SortPatient('AccNo') 的那一欄就是檢查單號。
  function columnIndex(row) {
    const out = {};
    const table = row && row.closest('table');
    const head = table && table.rows[0];
    if (head) [...head.cells].forEach((td, i) => { const m = /SortPatient\('(\w+)'\)/.exec(td.getAttribute('onclick') || ''); if (m) out[m[1]] = i; });
    return out;
  }
  function studyInfo(row) {
    const col = columnIndex(row);
    const cell = (name) => (col[name] != null ? text(row.cells[col[name]]) : '');
    return { accession_no: cell('AccNo'), patient_id: cell('PatientID'), date: row.getAttribute('studydate') || '', body_part: row.getAttribute('bodypart') || '', hasAccColumn: col.AccNo != null };
  }

  // ---------- 角色 1：查詢與下載（只在查詢框架） ----------
  // 外掛自己的隱藏框架（急診清單頁裡，免登入接上的那一個）
  const HIDDEN = window.name === 'cxr-relabel-pacs' && window.top !== window && /\/OpenImage$/i.test(location.pathname);
  const pageAttr = (name) => document.documentElement.getAttribute(name) || '';
  function accKey() {
    // 剛登入、還沒按過「查詢」時，通行碼只在頁面的程式變數裡：請 pacs-main.js 先把它填進表單
    try { document.dispatchEvent(new CustomEvent('cxr-relabel-acckey')); } catch (e) { /* 照舊讀表單 */ }
    // 隱藏框架沒有查詢表單：pacs-main.js 把頁面變數抄在網頁屬性上；抄不到就用網址上的那一個
    if (HIDDEN) return pageAttr('data-cxr-acckey') || new URLSearchParams(location.search).get('AccKey') || '';
    const f = document.forms['QueryPatient'];
    return (f && f.AccKey && f.AccKey.value) || '';
  }
  async function getDoc(path, params) {
    const r = await fetch(BASE + path + '?' + new URLSearchParams(params), { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { reason: 'no-session' });
    return new DOMParser().parseFromString(await r.text(), 'text/html');
  }
  async function wado(uid, key, extra) {
    const r = await fetch(BASE + 'WADO?' + new URLSearchParams(Object.assign({ requestType: 'WADO', objectUID: uid }, extra, { AccKey: key })), { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { reason: 'no-session' });
    return r.blob();
  }
  const toDataUrl = (blob) => new Promise((resolve, reject) => { const fr = new FileReader(); fr.onload = () => resolve(fr.result); fr.onerror = () => reject(fr.error); fr.readAsDataURL(blob); });

  // 病歷號比對用：只留數字、去掉開頭的 0（和 core.js 的 chartKey 同一個規則；這支腳本不載入 core.js）
  const chartKey = (v) => String(v == null ? '' : v).replace(/\D/g, '').replace(/^0+/, '');

  async function lookup(accession, patientId) {
    const key = accKey();
    if (!key) return fail('no-session');
    const sd = await getDoc('QueryPatientStudy', { AID: accession, AccKey: key });
    let rows = [...sd.querySelectorAll('tr[study_uid_id]')];
    if (!rows.length) return fail(sd.querySelector('form[name="QuerySeries"],form#QuerySeries,form[name="ViewImage"],form#ViewImage') ? 'not-found' : 'no-session');
    // 查詢可能不是完全比對：認得出檢查單號那一欄就只留完全相同的；認不出來時只接受「剛好一筆」
    if (studyInfo(rows[0]).hasAccColumn) rows = rows.filter((r) => studyInfo(r).accession_no === accession);
    else if (rows.length > 1) rows = [];
    if (!rows.length) return fail('not-found');
    // 結果頁有給病歷號、PACS 也讀得到病歷號時，兩邊要一致；不一致就不用（寧可退回，也不要標到別人的影像）
    const want = chartKey(patientId);
    if (want) {
      const known = rows.filter((r) => chartKey(studyInfo(r).patient_id));
      const same = known.filter((r) => chartKey(studyInfo(r).patient_id) === want);
      if (known.length && !same.length) return fail('patient-mismatch');
      if (same.length) rows = same;
    }
    const row = rows[0];
    const images = [];
    const ser = await getDoc('QuerySeriesImage', { STUDY_UID_ID: row.getAttribute('study_uid_id'), AccKey: key });
    for (const s of ser.querySelectorAll('tr[series_uid_id]')) {
      if (s.getAttribute('prko') === '1' || images.length >= MAX_IMAGES) continue; // prko=1 是標記／呈現狀態，不是影像
      const idoc = await getDoc('QueryImage', { Series_UID_ID: s.getAttribute('series_uid_id'), AccKey: key });
      for (const im of idoc.querySelectorAll('img[imagefile]')) {
        if (im.getAttribute('prko') === '1' || images.length >= MAX_IMAGES) continue;
        images.push({ uid: im.getAttribute('imagefile') });
      }
    }
    if (!images.length) return fail('not-found');
    for (const im of images) im.small = await toDataUrl(await wado(im.uid, key, { rows: '128' })); // 小圖，給外掛比對是哪一張
    const info = studyInfo(row);
    return { ok: true, images, study: { studyDate: info.date, bodyPart: info.body_part, patientId: info.patient_id } };
  }

  async function fetchObject(uid, kind) {
    const key = accKey();
    if (!key) return fail('no-session');
    const blob = await wado(uid, key, kind === 'dicom' ? { contentType: 'application/dicom' } : {});
    if (kind !== 'dicom' && !/^image\//.test(blob.type)) return fail('error', '伺服器回的不是影像');
    return { ok: true, dataUrl: await toDataUrl(blob), bytes: blob.size };
  }

  // ---------- PACS 回顧：用病歷號列出檢查、載縮圖、在 WebPACS 自己的畫面查這位病人 ----------
  const MAX_ROWS = 300;     // WebPACS 一頁最多回這麼多筆（2026-11-21 附院實測）
  const MAX_THUMBS = 12;    // 一筆檢查最多載幾張縮圖
  const SERIES_ALL = 4;     // 一個序列不超過這麼多張就全部列；超過（CT 之類）只列第一張

  // 查詢參數：查詢表單上每個欄位都送、而且全部清空，只填病歷號——2026-11-21 在附院真系統上用這個寫法查過，
  // 回來的每一筆病歷號都相同；病歷號前面多補 0 會查不到，所以照清單上的寫法送。
  function chartQuery(chart, key) {
    const p = new URLSearchParams();
    const f = document.forms['QueryPatient'];
    if (f) for (const e of f.elements) {
      if (!e.name || e.type === 'button' || e.type === 'submit' || e.type === 'password') continue;
      if ((e.type === 'checkbox' || e.type === 'radio') && !e.checked) continue;
      p.set(e.name, '');
    }
    p.set('CHARTID', chart);
    p.set('AccKey', key);
    return p;
  }
  function studyRow(row, col) {
    const cell = (name) => { const v = col[name] != null && row.cells[col[name]] ? text(row.cells[col[name]]) : ''; return v === '-' ? '' : v; };
    return {
      id: row.getAttribute('study_uid_id') || '',
      date: row.getAttribute('studydate') || cell('StudyDate').replace(/\D/g, ''),
      time: cell('StudyTime'), modality: cell('Modality'), desc: cell('StudyDesc'),
      bodyPart: (row.getAttribute('bodypart') || cell('BodyPart')).replace(/^-$/, ''), accession: cell('AccNo'), patientId: cell('PatientID'),
    };
  }
  function topUsername() {
    if (HIDDEN) { accKey(); return pageAttr('data-cxr-user'); }
    try { const m = /var\s+Username\s*=\s*"([^"]*)"/.exec([...window.top.document.scripts].map((s) => s.textContent).join('\n')); return m ? m[1] : ''; } catch (e) { return ''; }
  }

  async function studies(chart) {
    if (!/^\d{4,12}$/.test(chart)) return fail('bad-chart');
    const key = accKey();
    if (!key) return fail('no-session');
    const doc = await getDoc('QueryPatientStudy', chartQuery(chart, key));
    const rows = [...doc.querySelectorAll('tr[study_uid_id]')];
    if (!rows.length && !doc.querySelector('form[name="QuerySeries"],form#QuerySeries,form[name="ViewImage"],form#ViewImage')) return fail('no-session');
    const col = rows.length ? columnIndex(rows[0]) : {};
    if (rows.length && col.PatientID == null) return fail('error', '檢查清單上認不出病歷號那一欄');
    const want = chartKey(chart);
    const all = rows.map((r) => studyRow(r, col));
    // 只留病歷號完全相同的（查詢不一定是完全比對；寧可少列，也不要列到別人的檢查）
    const list = all.filter((s) => chartKey(s.patientId) === want).map((s) => { delete s.patientId; return s; });
    return { ok: true, studies: list, dropped: all.length - list.length, capped: rows.length >= MAX_ROWS, empcode: topUsername() };
  }

  async function thumbs(studyId) {
    if (!/^[\w.-]{1,64}$/.test(studyId)) return fail('error', '檢查編號不對');
    const key = accKey();
    if (!key) return fail('no-session');
    const ser = await getDoc('QuerySeriesImage', { STUDY_UID_ID: studyId, AccKey: key });
    const out = [];
    let total = 0, series = 0;
    for (const s of ser.querySelectorAll('tr[series_uid_id]')) {
      if (s.getAttribute('prko') === '1') continue;
      series++;
      const idoc = await getDoc('QueryImage', { Series_UID_ID: s.getAttribute('series_uid_id'), AccKey: key });
      const imgs = [...idoc.querySelectorAll('img[imagefile]')].filter((im) => im.getAttribute('prko') !== '1');
      total += imgs.length;
      for (const im of imgs.slice(0, imgs.length > SERIES_ALL ? 1 : imgs.length)) {
        if (out.length < MAX_THUMBS) out.push({ uid: im.getAttribute('imagefile'), seriesImages: imgs.length, modality: s.getAttribute('modality') || '' });
      }
      if (out.length >= MAX_THUMBS) break;
    }
    for (const im of out) {
      try { im.small = await toDataUrl(await wado(im.uid, key, { rows: '160' })); } catch (e) { im.small = ''; }
      if (!/^data:image\//.test(im.small)) im.small = ''; // 心電圖之類不是影像的，就不給預覽
    }
    return { ok: true, images: out, total, series };
  }

  // 在 WebPACS 自己的畫面查這位病人：清空查詢條件、填病歷號，按頁面自己的「查詢」（結果出現在檢查清單框架）
  function show(chart) {
    if (!/^\d{4,12}$/.test(chart)) return fail('bad-chart');
    const f = document.forms['QueryPatient'];
    if (!f || !f.CHARTID) return fail('no-session');
    const blank = ['OTHERPTNID', 'NAME', 'BOD', 'DATE', 'DATE2', 'EXACTDATE', 'TIME1', 'TIME2', 'AID', 'CID', 'DOCTOR', 'STUDYDESC', 'REQSERVICE', 'REQPHY', 'textPART', 'textMECHINE', 'STATION'];
    for (const n of blank) if (f[n] && f[n].type !== 'hidden') f[n].value = '';
    if (f.DATEOPTION && f.DATEOPTION.options) { const o = [...f.DATEOPTION.options].find((x) => !x.text.trim()); if (o) f.DATEOPTION.value = o.value; }
    for (const n of ['KEYIMAGE', 'UNREADSTUDYONLY', 'PATIENTLEVEL']) if (f[n] && f[n].type === 'checkbox') f[n].checked = false;
    f.CHARTID.value = chart;
    accKey();
    if (typeof f.requestSubmit === 'function') f.requestSubmit(); else f.submit();
    return { ok: true };
  }

  if (window.name === 'Queryfrm' || HIDDEN) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg) return;
      let job;
      // 急診清單問「接上了沒」：有通行碼了嗎；WebPACS 是不是明講不給（連結失效）
      if (msg.type === 'pacs-ping') { if (!HIDDEN) return; const key = accKey(); sendResponse({ ok: true, key: !!key, refused: !key && document.readyState === 'complete' && pageAttr('data-cxr-refused') === '1' }); return; }
      if (msg.type === 'pacs-show' && HIDDEN) { sendResponse(fail('no-session')); return; } // 隱藏框架沒有畫面可以給人看
      if (msg.type === 'pacs-lookup') job = lookup(String(msg.accession || ''), String(msg.patientId || ''));
      else if (msg.type === 'pacs-fetch') job = fetchObject(String(msg.uid || ''), msg.kind);
      else if (msg.type === 'pacs-studies') job = studies(String(msg.chart || ''));
      else if (msg.type === 'pacs-thumbs') job = thumbs(String(msg.studyId || ''));
      else if (msg.type === 'pacs-show') job = Promise.resolve(show(String(msg.chart || '')));
      else return;
      job.then(sendResponse, (e) => sendResponse(fail(e.reason || 'error', String((e && e.message) || e))));
      return true; // 非同步回覆
    });
  }

  // ---------- 角色 2：影像縮圖下面的「標註」按鈕 ----------
  const frameDoc = (name) => { try { const f = window.top.document.querySelector('frame[name="' + name + '"],iframe[name="' + name + '"]'); return f ? f.contentDocument : null; } catch (e) { return null; } };

  // 這張影像屬於哪一筆檢查：序列框架的網址帶著那筆檢查的編號，再到檢查清單找那一列
  function metaFor() {
    const meta = { accession_no: '', patient_id: '', date: '', body_part: '', empcode: '' };
    try {
      const sdoc = frameDoc('Seriesfrm'), pdoc = frameDoc('Patientfrm');
      const studyId = sdoc ? new URLSearchParams(sdoc.location.search).get('STUDY_UID_ID') : '';
      let row = pdoc && studyId ? [...pdoc.querySelectorAll('tr[study_uid_id]')].find((r) => r.getAttribute('study_uid_id') === studyId) : null;
      if (!row && pdoc) { const marked = pdoc.querySelectorAll('tr[study_uid_id][mark="1"]'); if (marked.length === 1) row = marked[0]; }
      if (row) Object.assign(meta, studyInfo(row));
      const m = /var\s+Username\s*=\s*"([^"]*)"/.exec([...window.top.document.scripts].map((s) => s.textContent).join('\n'));
      if (m) meta.empcode = m[1];
    } catch (e) { /* 讀不到就留空，標註畫面會說明 */ }
    delete meta.hasAccColumn;
    return meta;
  }

  function decorate() {
    const imgs = [...document.querySelectorAll('img[imagefile]')].filter((i) => i.getAttribute('prko') !== '1');
    if (!imgs.length || imgs.length > MAX_DECORATE) return;
    imgs.forEach((img) => {
      if (img.dataset.cxrRelabel) return;
      img.dataset.cxrRelabel = '1';
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'cxr-relabel-btn';
      b.textContent = '✏️ 標註';
      b.title = '用「CXR 重新標註」外掛標這張影像';
      b.style.cssText = 'display:block;margin:2px auto 0;padding:1px 6px;font-size:11px;line-height:1.4;border:1px solid #29b6f6;border-radius:4px;background:#0d3b5c;color:#e1f5fe;cursor:pointer;';
      // 不讓 PACS 頁面自己的滑鼠處理（選取、開 Viewer）接到這顆按鈕的事件
      for (const t of ['mousedown', 'mouseup', 'dblclick']) b.addEventListener(t, (e) => e.stopPropagation());
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        chrome.runtime.sendMessage({ type: 'pacs-open-editor', job: { uid: img.getAttribute('imagefile'), meta: metaFor() } })
          .catch((err) => alert('無法開啟標註分頁：' + String((err && err.message) || err) + '\n（外掛剛更新過的話，請重新整理 WebPACS 這一頁）'));
      });
      img.insertAdjacentElement('afterend', b);
    });
  }
  decorate();
  setTimeout(decorate, 800);
})();
