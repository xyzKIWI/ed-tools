/* CXR 重新標註：標一張 WebPACS 影像（從 WebPACS 的「標註」按鈕開的分頁，與 PACS 回顧小視窗共用）。
 * job = { uid, meta: { accession_no, patient_id, date, body_part, empcode }, tabId（向哪個 WebPACS 分頁取圖） }
 * hooks = { onError(text), onReady(), onClose() } */
(function (root) {
  'use strict';
  const C = root.CXRCore, E = root.CXREditor;

  async function open(job, hooks) {
    const VERSION = chrome.runtime.getManifest().version;
    const send = (m) => chrome.runtime.sendMessage(m).catch((e) => ({ ok: false, reason: 'error', detail: String((e && e.message) || e) }));
    const why = (r) => (r && r.reason === 'no-session' ? 'WebPACS 那個分頁已經關閉、登出或登入過期。請回 WebPACS 重新登入後再按「標註」。' : '向 WebPACS 取圖時出錯' + (r && r.detail ? '（' + r.detail + '）' : '') + '。');
    const stop = (t) => { if (hooks.onError) hooks.onError(t); return null; };

    const full = await send({ type: 'pacs-image', tabId: job.tabId, uid: job.uid, kind: 'jpeg' });
    if (!full || !full.ok) return stop('影像下載失敗：' + why(full));
    const im = new Image();
    im.src = full.dataUrl;
    try { await im.decode(); } catch (e) { return stop('影像無法解碼。'); }

    const meta = job.meta || {};
    const page = { caseid: '', object_uid: job.uid, accession_no: meta.accession_no || '', patient_id: meta.patient_id || '', date: meta.date || '', empcode: meta.empcode || '', detections: [] };
    const base = C.fileBase(page), ext = C.extOf(full.dataUrl, 'jpg');
    const W = im.naturalWidth, H = im.naturalHeight;
    if (hooks.onReady) hooks.onReady(page);

    return E.open({
      title: 'CXR 標註（WebPACS 影像）',
      image: im, width: W, height: H,
      boxes: [], storeKey: 'pacs:' + job.uid,
      metaLines: ['檢查單號：' + (page.accession_no || '（讀不到，檔名會以 noacc 開頭）'), '檢查日期：' + (page.date || '（讀不到）'), '影像來源：WebPACS 原圖'],
      intro: '已從 WebPACS 取得原圖，請在影像上畫框。',
      dicomOption: true,
      onClose: () => { if (hooks.onClose) hooks.onClose(); },
      makeFiles: async (s) => {
        const files = [{ filename: base + '.' + ext, url: full.dataUrl }];
        let dicomPath = '';
        if (s.wantDicom) {
          const d = await send({ type: 'pacs-image', tabId: job.tabId, uid: job.uid, kind: 'dicom' });
          if (!d || !d.ok) throw new Error('DICOM 下載失敗：' + why(d));
          dicomPath = base + '.dcm';
          files.push({ filename: dicomPath, url: d.dataUrl });
        }
        const json = C.buildLabelme({
          imagePath: base + '.' + ext, width: W, height: H, boxes: s.boxes, noFinding: s.noFinding, note: s.note,
          page, modelBoxes: [], savedAt: s.savedAt, toolVersion: VERSION,
          pacs: { object_uid: job.uid, study_date: page.date, body_part: meta.body_part || '', images_in_study: 0, similarity: null, dicomPath },
        });
        files.push({ filename: base + '.json', url: C.jsonDataUrl(json) });
        return files;
      },
    });
  }

  root.CXRPacsEditor = { open };
})(globalThis);
