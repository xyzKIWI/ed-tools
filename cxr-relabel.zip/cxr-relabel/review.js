/* CXR 重新標註：「PACS 回顧」分頁（從急診清單的「🩻 PACS」按鈕開）。
 * 這位病人是誰記在 chrome.storage.session（只在記憶體，關瀏覽器就消失），網址上只有一組隨機代號。
 * 檢查清單、縮圖、原圖都是同院區已登入的 WebPACS 分頁自己去要的（pacs.js），這裡只顯示。 */
(async function () {
  'use strict';
  const C = globalThis.CXRCore;
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  const send = (m) => chrome.runtime.sendMessage(m).catch((e) => ({ ok: false, reason: 'error', detail: String((e && e.message) || e) }));
  const msg = $('msg'), list = $('list');
  const say = (t) => { msg.textContent = t; };

  const C2 = globalThis.CXRPacsEditor;
  // 這是固定的 PACS 回顧小視窗：清單上點選別的病人時，背景程式只換網址 # 後面的代號。
  // 正在標註時先不換（不要丟掉還沒存的框），關掉標註畫面後才換。
  let editing = false, pending = false;
  addEventListener('hashchange', () => { if (editing) { pending = true; showPending(); } else location.reload(); });
  function showPending() { const s = document.getElementById('msg'); s.textContent = '清單上已點選另一位病人；關掉標註畫面後會換過去。'; }

  const key = 'review:' + location.hash.slice(1);
  const job = (await chrome.storage.session.get(key))[key];
  if (!job || !job.chart) return say('找不到這位病人的資料（瀏覽器重開過，或這個分頁是舊的）。請回急診清單重新按「🩻 PACS」。');
  const site = C.SITES.find((s) => s.id === job.site) || { name: '', pacs: '' };
  const since = C.parseErTime(job.since), until = C.parseErTime(job.until);

  $('who').textContent = [site.name, job.bed, job.name, job.chart].filter(Boolean).join('　');
  $('visit').textContent = (job.since ? '入院 ' + job.since : '入院時間讀不到') + (job.until ? '　出院 ' + job.until : job.status ? '　' + job.status : '');
  document.title = 'PACS 回顧 ' + (job.bed || '');
  if (job.aiurl) { $('ai').hidden = false; $('ai').onclick = () => chrome.tabs.create({ url: job.aiurl }); }
  if (since == null) { document.querySelector('input[name=scope][value=all]').checked = true; }

  let res = null, scope = since == null ? 'all' : 'visit', mods = new Set();
  // waiting：還沒有可用的 WebPACS 分頁（沒開、沒登入、過期）——WebPACS 分頁一載入完就自動再查一次。
  // autoShow：使用者是從這裡去登入的（或按了「在 WebPACS 開這位病人」）——接上之後順便讓 WebPACS 查這位病人。
  let waiting = false, autoShow = false, readyTimer = 0, retried = false;
  // 免登入接上（0.7.0）：autoTried＝這一輪已經試過（不成功就不再自己重試，免得一直去敲 WebPACS）；connecting＝正在接
  let autoTried = false, connecting = false;

  // ---------- 讀檢查清單 ----------
  function why(r) {
    const reason = r && r.reason;
    if (reason === 'no-tab') return '沒有開著的' + site.name + ' WebPACS 分頁。按右邊的按鈕開 WebPACS 登入頁，登入後這裡會自動接上這位病人。';
    if (reason === 'no-session') return site.name + ' WebPACS 還沒登入或登入過期（或那個分頁是外掛更新前開的）。按右邊的按鈕到 WebPACS 登入，登入後這裡會自動接上這位病人。';
    if (reason === 'bad-chart') return '病歷號的格式認不得。';
    return '向 WebPACS 查詢時出錯' + (r && r.detail ? '（' + r.detail + '）' : '') + '。';
  }
  // 免登入沒接上的原因（後面接「可以按右邊的按鈕自己登入」）
  function whyAuto(r) {
    const reason = r && r.reason;
    if (reason === 'no-link') return '這位病人在體系病歷的「檢查」頁沒有可以開 PACS 的檢查，沒有連結可以借用。';
    if (reason === 'er-login') return '急診清單那一頁的登入已經過期（請到那一頁重新登入）。';
    if (reason === 'no-er-tab') return '找不到開這個視窗的急診清單分頁（關掉了，或是外掛更新前開的：請重新整理那一頁）。';
    if (reason === 'wrong-patient') return '體系病歷開出來的不是這位病人，沒有使用它的連結。';
    if (reason === 'auth-failed') return 'WebPACS 沒有接受體系病歷給的連結。';
    if (reason === 'auth-stopped') return 'WebPACS 已經連續兩次不接受連結，為了不被記成多次登入失敗，先不再自動試（重新整理急診清單那一頁可以再試）。';
    if (reason === 'unsupported') return '這個瀏覽器沒有獨立框架的功能（需要新版 Chrome 或 Edge）。';
    if (reason === 'blocked' || reason === 'mrn-landing' || reason === 'no-record-link' || reason === 'no-user') return '讀不到體系病歷的「檢查」頁（' + reason + '）。';
    return '免登入接上 WebPACS 時出錯' + (r && r.detail ? '（' + r.detail + '）' : reason ? '（' + reason + '）' : '') + '。';
  }
  async function load() {
    clearTimeout(readyTimer);
    say('向 ' + site.name + ' WebPACS 查詢中…');
    list.textContent = '';
    $('bar').hidden = true;
    $('show').disabled = true;
    const r = await send({ type: 'review-studies', site: job.site, chart: job.chart });
    if (!r || !r.ok) {
      res = null;
      waiting = !!(r && (r.reason === 'no-tab' || r.reason === 'no-session'));
      let auto = '';
      if (waiting && r.auto && !autoTried && !connecting) {
        // 沒有可用的 WebPACS：借用體系病歷「檢查」頁替這位病人現做的 PACS 連結，不用輸入帳密
        autoTried = connecting = true;
        say('正在免登入接上 ' + site.name + ' WebPACS（借用體系病歷「檢查」頁的 PACS 連結）…');
        const c = await send({ type: 'review-connect', site: job.site, chart: job.chart });
        connecting = false;
        if (c && c.ok) return load();
        auto = whyAuto(c);
      }
      say(auto ? auto + '可以按右邊的按鈕自己登入 WebPACS，登入後這裡會自動接上這位病人。' : why(r));
      if (waiting) {
        $('show').disabled = false; // 還沒接上時按它：先去登入，登入後自動查這位病人
        const b = el('button', 'primary', '到 ' + site.name + ' WebPACS 登入');
        b.style.marginLeft = '12px';
        b.onclick = goLogin;
        msg.appendChild(b);
      }
      return;
    }
    waiting = false; retried = false; autoTried = false;
    res = r;
    res.studies = C.sortStudies(r.studies).map((s) => Object.assign(s, { inVisit: C.inVisit(C.studyMoment(s.date, s.time), since, until) }));
    $('show').disabled = false;
    $('bar').hidden = false;
    render();
    if (autoShow) { autoShow = false; showInPacs(); }
  }
  function goLogin() {
    autoShow = true;
    say(site.name + ' WebPACS 登入頁已打開。請在那邊登入，登入完成後這裡會自動接上這位病人，WebPACS 也會直接查這位病人。');
    send({ type: 'review-login', site: job.site });
  }
  // WebPACS 分頁載入完成（登入後的畫面、重新整理）：背景程式會通知；還在等的話就再查一次。
  // 剛載入完時查詢框架的外掛程式可能還沒準備好，查不到就隔一下再試一次。
  chrome.runtime.onMessage.addListener((m) => {
    if (!m || m.type !== 'pacs-tab-ready' || m.site !== job.site || !waiting || editing || connecting) return;
    clearTimeout(readyTimer);
    readyTimer = setTimeout(async () => {
      await load();
      if (waiting && !retried) { retried = true; readyTimer = setTimeout(load, 1500); }
    }, 600);
  });

  // ---------- 清單 ----------
  const fmtDate = (d) => (/^\d{8}$/.test(d) ? d.slice(0, 4) + '/' + d.slice(4, 6) + '/' + d.slice(6) : d || '日期不明');
  const fmtTime = (t) => { const m = /^(\d{2}):?(\d{2})/.exec(t || ''); return m ? m[1] + ':' + m[2] : ''; };
  let io = null;
  function render() {
    list.textContent = '';
    if (io) io.disconnect();
    const inScope = res.studies.filter((s) => scope === 'all' || s.inVisit);
    // 類別篩選鈕：用目前範圍內有的類別
    const modsHere = [...new Set(inScope.map((s) => s.modality || '其他'))].sort();
    for (const m of [...mods]) if (!modsHere.includes(m)) mods.delete(m);
    const mbox = $('mods');
    mbox.textContent = '';
    for (const m of modsHere) {
      const b = el('button', 'chip' + (mods.has(m) ? ' on' : ''), m + ' ' + inScope.filter((s) => (s.modality || '其他') === m).length);
      b.onclick = () => { mods.has(m) ? mods.delete(m) : mods.add(m); render(); };
      mbox.appendChild(b);
    }
    const shown = inScope.filter((s) => !mods.size || mods.has(s.modality || '其他'));
    $('count').textContent = '顯示 ' + shown.length + ' 筆／這次急診 ' + res.studies.filter((s) => s.inVisit).length + ' 筆／全部 ' + res.studies.length + ' 筆';
    const notes = [];
    if (!res.studies.length) notes.push(site.name + ' WebPACS 上查不到這位病人的檢查。');
    else if (scope === 'visit' && !inScope.length) notes.push('這次急診期間（' + job.since + ' 起）WebPACS 上還沒有影像。可以切到「全部」看以前的檢查。');
    if (res.capped) notes.push('WebPACS 一次最多回 300 筆，這位病人可能還有更舊的檢查沒列出來；要看更舊的請用「在 WebPACS 開這位病人」。');
    if (res.dropped) notes.push('另有 ' + res.dropped + ' 筆病歷號不同的檢查沒有列出。');
    say(notes.join('\n'));

    io = new IntersectionObserver((entries) => {
      for (const en of entries) if (en.isIntersecting) { io.unobserve(en.target); queueThumbs(en.target); }
    }, { rootMargin: '300px' });
    for (const s of shown) {
      const card = el('section', 'study' + (s.inVisit ? '' : ' old'));
      card.dataset.study = s.id;
      const h = el('h3');
      h.append(el('span', '', fmtDate(s.date) + (fmtTime(s.time) ? ' ' + fmtTime(s.time) : '')), el('span', 'mod', s.modality || '—'));
      if (s.bodyPart) h.append(el('span', '', s.bodyPart));
      if (s.desc) h.append(el('span', 'sub', s.desc));
      if (s.accession) h.append(el('span', 'sub', '單號 ' + s.accession));
      if (!s.inVisit && since != null) h.append(el('span', 'sub', '（這次急診以前）'));
      const th = el('div', 'thumbs', '縮圖載入中…');
      card.append(h, th);
      card._study = s;
      list.appendChild(card);
      // 前幾筆直接載（小視窗被別的視窗蓋住時，瀏覽器不會通知「看得到了」）；其他捲到才載
      if (list.children.length <= 6) queueThumbs(card); else io.observe(card);
    }
  }

  // 縮圖一次只載一筆檢查（WebPACS 那邊是一張一張要的），畫面看得到的先載
  const thumbCache = new Map();
  let chain = Promise.resolve();
  function queueThumbs(card) { chain = chain.then(() => fillThumbs(card)).catch(() => {}); }
  async function fillThumbs(card) {
    const s = card._study, box = card.querySelector('.thumbs');
    let r = thumbCache.get(s.id);
    if (!r) { r = await send({ type: 'review-thumbs', tabId: res.tabId, studyId: s.id }); if (r && r.ok) thumbCache.set(s.id, r); }
    box.textContent = '';
    if (!r || !r.ok) { box.textContent = '縮圖載入失敗：' + why(r); return; }
    s.images = r.images;
    if (!r.images.length) { box.textContent = '這筆檢查沒有可以預覽的影像。'; return; }
    r.images.forEach((im, i) => {
      const t = el('div', 'thumb');
      if (im.small) {
        const img = el('img');
        img.src = im.small;
        img.title = '點一下看大圖';
        img.onclick = () => openViewer(s, i);
        t.appendChild(img);
      } else t.appendChild(el('div', 'noimg', '無法預覽'));
      t.appendChild(el('span', 'cap', (im.modality ? im.modality + ' ' : '') + (im.seriesImages > 1 ? '序列共 ' + im.seriesImages + ' 張' : '')));
      box.appendChild(t);
    });
    if (r.total > r.images.length) box.appendChild(el('span', 'cap', '這筆檢查共 ' + r.total + ' 張（' + r.series + ' 個序列），這裡每個大序列只列第一張；全部請用「在 WebPACS 開這位病人」。'));
  }

  // ---------- 大圖 ----------
  const viewer = $('viewer'), vimg = $('vimg'), vstage = $('vstage'), vmsg = $('vmsg');
  let vs = null, vi = 0, view = { s: 1, x: 0, y: 0 }, loadSeq = 0;
  const apply = () => { vimg.style.transform = `translate(${view.x}px, ${view.y}px) scale(${view.s})`; };
  function fit() {
    const W = vstage.clientWidth, H = vstage.clientHeight, w = vimg.naturalWidth, h = vimg.naturalHeight;
    if (!w || !h) return;
    view.s = Math.min(W / w, H / h);
    view.x = (W - w * view.s) / 2; view.y = (H - h * view.s) / 2;
    apply();
  }
  async function openViewer(s, i) {
    vs = s; vi = i;
    viewer.classList.add('open');
    const im = s.images[i], seq = ++loadSeq;
    vimg.removeAttribute('src');
    vmsg.textContent = '原圖載入中…';
    $('vinfo').textContent = fmtDate(s.date) + ' ' + fmtTime(s.time) + '　' + (s.modality || '') + ' ' + (s.bodyPart || '') + '　第 ' + (i + 1) + '／' + s.images.length + ' 張';
    $('vprev').disabled = i <= 0; $('vnext').disabled = i >= s.images.length - 1;
    const r = await send({ type: 'pacs-image', tabId: res.tabId, uid: im.uid, kind: 'jpeg' });
    if (seq !== loadSeq) return; // 已經換到別張
    if (!r || !r.ok) { vmsg.textContent = '原圖載入失敗：' + why(r); $('vedit').disabled = true; return; }
    vimg.src = r.dataUrl;
    try { await vimg.decode(); } catch (e) { vmsg.textContent = '影像無法解碼。'; return; }
    if (seq !== loadSeq) return;
    vmsg.textContent = '';
    $('vedit').disabled = false;
    fit();
  }
  const closeViewer = () => { viewer.classList.remove('open'); loadSeq++; vimg.removeAttribute('src'); };
  $('vclose').onclick = closeViewer;
  $('vfit').onclick = fit;
  $('vprev').onclick = () => { if (vs && vi > 0) openViewer(vs, vi - 1); };
  $('vnext').onclick = () => { if (vs && vi < vs.images.length - 1) openViewer(vs, vi + 1); };
  // 標註畫面直接開在這個小視窗裡（蓋在回顧上面），關掉就回到回顧
  $('vedit').onclick = async () => {
    if (editing) return;
    const im = vs.images[vi];
    const meta = { accession_no: vs.accession || '', patient_id: job.chart, date: vs.date || '', body_part: vs.bodyPart || '', empcode: res.empcode || '' };
    editing = true;
    $('vedit').disabled = true;
    const doneEditing = () => { editing = false; $('vedit').disabled = false; if (pending) location.reload(); };
    const api = await C2.open({ uid: im.uid, meta, tabId: res.tabId }, {
      onError: (t) => { alert(t); doneEditing(); },
      onClose: doneEditing,
    });
    if (!api && editing) doneEditing();
  };
  vstage.addEventListener('wheel', (e) => {
    e.preventDefault();
    const r = vstage.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top;
    const k = Math.exp(-e.deltaY * 0.0015), s = Math.min(8, Math.max(0.05, view.s * k));
    view.x = mx - (mx - view.x) * s / view.s; view.y = my - (my - view.y) * s / view.s; view.s = s;
    apply();
  }, { passive: false });
  let drag = null;
  vstage.addEventListener('mousedown', (e) => { drag = { x: e.clientX - view.x, y: e.clientY - view.y }; vstage.style.cursor = 'grabbing'; e.preventDefault(); });
  addEventListener('mousemove', (e) => { if (drag) { view.x = e.clientX - drag.x; view.y = e.clientY - drag.y; apply(); } });
  addEventListener('mouseup', () => { drag = null; vstage.style.cursor = ''; });
  addEventListener('resize', () => { if (viewer.classList.contains('open')) fit(); });
  addEventListener('keydown', (e) => {
    if (!viewer.classList.contains('open')) return;
    if (e.key === 'Escape') closeViewer();
    else if (e.key === 'ArrowLeft') $('vprev').click();
    else if (e.key === 'ArrowRight') $('vnext').click();
    else if (e.key === 'f' || e.key === 'F') fit();
  });

  // ---------- 上方按鈕 ----------
  for (const r of document.querySelectorAll('input[name=scope]')) r.addEventListener('change', () => { scope = r.value; if (res) render(); });
  $('reload').onclick = () => { thumbCache.clear(); autoTried = false; load(); }; // 自己按的：可以再試一次免登入接上
  async function showInPacs() {
    const r = await send({ type: 'review-show', tabId: res.tabId, chart: job.chart });
    if (!r || !r.ok) say(why(r));
  }
  // 隱藏框架接上的（免登入）沒有畫面可以看：要在 WebPACS 自己的畫面查，得有一個使用者自己登入的分頁
  $('show').onclick = () => (res && !res.hidden ? showInPacs() : goLogin());
  load();
})();
