/* CXR 重新標註：AI 平台結果頁的頁面腳本。
 * 只在結果頁、而且頁面上有嵌入的胸部 X 光影像時，才在影像上方加一顆「重新標註」按鈕。
 * 按下去會先用頁面上的檢查單號向 WebPACS 要原圖（要有一個已登入的 WebPACS 分頁）；
 * 要不到就退回用結果頁的影像（把模型畫的框抹掉）。
 * 對院內系統唯讀：只讀頁面上已經顯示的內容，不代按回饋。 */
(function () {
  'use strict';
  if (!/\/web\/aiplatform(\/|$)/i.test(location.pathname)) return;
  const C = globalThis.CXRCore, E = globalThis.CXREditor;
  if (!C || !E || window.__cxrRelabelLoaded) return;
  window.__cxrRelabelLoaded = true;

  const VERSION = chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '';

  // ---------- 讀頁面 ----------
  function readPage() {
    const img = document.querySelector('#panoutputinfo img[src^="data:image"]');
    if (!img) return null;
    const q = {};
    new URLSearchParams(location.search).forEach((v, k) => { q[k.toLowerCase()] = v; });
    const cards = {};
    document.querySelectorAll('.mini-card').forEach((c) => {
      const k = c.querySelector('.mini-card__h2'), v = c.querySelector('.mini-card__text');
      if (k && v) cards[k.textContent.trim()] = v.textContent.trim();
    });
    const module = cards['運算模組'] || '';
    if (module && !/X\s*光|X-?ray|CXR/i.test(module)) return null; // 其他模組（非胸部 X 光）不處理
    const input = {};
    document.querySelectorAll('#collapseInput .accordion-body > .row').forEach((r) => {
      const k = r.querySelector('b'), v = r.querySelector('.col-md-9');
      if (k && v) input[k.textContent.trim()] = v.textContent.trim();
    });
    const pre = document.querySelector('#panoutputinfo pre');
    const mark = document.querySelector('#panoutputinfo mark');
    return {
      img,
      imageSrc: img.src,
      caseid: q.caseid || '',
      empcode: q.empcode || '',
      module,
      inferredAt: cards['運算時間'] || '',
      patient_id: input.patient_id || '',
      accession_no: input.accession_no || '',
      date: input.date || '',
      riskText: mark ? mark.textContent.trim() : '',
      detections: C.parseDetections(pre ? pre.textContent : ''),
    };
  }

  const storeKey = (page) => 'case:' + (page.caseid || page.accession_no || 'unknown');

  async function addButton(page) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.style.cssText =
      'display:block;margin:0 0 8px auto;padding:6px 14px;border:1px solid #29b6f6;border-radius:6px;' +
      'background:#0d3b5c;color:#e1f5fe;font-size:15px;cursor:pointer;';
    let savedAt = '';
    const setText = (t) => { if (t != null) savedAt = t; btn.textContent = savedAt ? '✏️ 重新標註（已存 ' + savedAt + '）' : '✏️ 重新標註'; };
    setText('');
    btn.addEventListener('click', () => start(page, btn, setText));
    const row = page.img.closest('.row') || page.img;
    row.parentElement.insertBefore(btn, row);
    try {
      const key = storeKey(page);
      const got = await chrome.storage.local.get(key);
      if (got[key] && got[key].savedAtText) setText(got[key].savedAtText);
    } catch (e) { /* 讀不到上次紀錄不影響使用 */ }
  }

  (function boot(left) {
    const page = readPage();
    if (page) return void addButton(page);
    if (left > 0) setTimeout(() => boot(left - 1), 500);
  })(10);

  // ---------- 小工具 ----------
  const send = (msg) => chrome.runtime.sendMessage(msg).catch((e) => ({ ok: false, reason: 'error', detail: String((e && e.message) || e) }));
  const loadImage = async (src) => { const im = new Image(); im.src = src; await im.decode(); return im; };
  // 縮成 n×n 的灰階值，用來比兩張影像像不像
  const grayThumb = (src, n) => {
    const c = document.createElement('canvas');
    c.width = c.height = n;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(src, 0, 0, n, n);
    const d = g.getImageData(0, 0, n, n).data;
    const out = new Float32Array(n * n);
    for (let i = 0; i < out.length; i++) out[i] = d[i * 4] * 0.299 + d[i * 4 + 1] * 0.587 + d[i * 4 + 2] * 0.114;
    return out;
  };
  const whyText = (r) => {
    const reason = r && r.reason;
    const pacs = (r && r.site ? r.site : '') + ' WebPACS';
    if (reason === 'no-site') return '外掛不認得這個院區的網址，不知道該去哪個 WebPACS 查';
    if (reason === 'no-tab') return '沒有找到開著的' + pacs + ' 分頁（只會去同一院區的 WebPACS 查）';
    if (reason === 'no-session') return pacs + ' 分頁還沒登入、登入已過期，或那一頁是外掛安裝前開的（重新整理 WebPACS 即可）';
    if (reason === 'not-found') return pacs + ' 查不到這個檢查單號的影像';
    if (reason === 'patient-mismatch') return pacs + ' 上這個檢查單號的病歷號跟結果頁不同，為了不標到別人的影像，這次不使用';
    return '向 WebPACS 取圖時出錯' + (r && r.detail ? '（' + r.detail + '）' : '');
  };

  // ---------- 開始標註 ----------
  let busy = false;
  // pick：指定要用這筆檢查的第幾張影像（「換一張」時用）；沒給就自動挑最像結果頁的那張
  async function start(page, btn, setText, pick) {
    if (busy) return;
    busy = true;
    btn.disabled = true;
    try {
      btn.textContent = '⏳ 準備影像中…';
      const ai = await loadImage(page.imageSrc);
      const aw = ai.naturalWidth, ah = ai.naturalHeight;
      const oc = document.createElement('canvas');
      oc.width = aw; oc.height = ah;
      const og = oc.getContext('2d', { willReadFrequently: true });
      og.drawImage(ai, 0, 0);
      const px = og.getImageData(0, 0, aw, ah).data;
      const aiBoxes = C.findOverlayBoxes(px, aw, ah); // 模型畫在結果頁影像上的框
      const cleaned = C.removeOverlay(px, aw, ah);
      const hasOverlay = cleaned.repaired > 0;
      if (hasOverlay) og.putImageData(new ImageData(cleaned.data, aw, ah), 0, 0); // oc＝抹掉框的版本
      const distinct = [...new Set(page.detections.map((d) => C.normalizeLabel(d.class)))];
      const modelLabel = distinct.length === 1 ? distinct[0] : ''; // 多種類別時無法判斷哪個框是哪一類，留給使用者選
      const asModel = (list) => list.map((b) => ({ label: modelLabel, source: 'model', x1: b.x1, y1: b.y1, x2: b.x2, y2: b.y2 }));
      const boxNote = (n) => (!n ? '影像上沒有模型的框，請直接畫。' : '模型的 ' + n + ' 個框已帶入' + (modelLabel ? '，可以直接拖拉修改。' : '；模型這次有多種類別，請替每個框選類別。'));
      const aiExt = C.extOf(page.imageSrc, 'png');
      const base = C.fileBase(page);
      const metaLines = [
        '檢查單號：' + (page.accession_no || '（頁面上沒有）'),
        '模型結果：' + (page.detections.map((d) => d.class + ' ' + d.score).join('、') || page.riskText || '無'),
      ];

      // 先向 WebPACS 要原圖
      let pacs = null, why = '';
      if (!page.accession_no) why = '結果頁上沒有檢查單號';
      else {
        btn.textContent = '⏳ 向 WebPACS 取原圖…';
        const r = await send({ type: 'pacs-find', accession: page.accession_no, patientId: page.patient_id });
        if (r && r.ok && r.images && r.images.length) {
          const aiThumb = grayThumb(oc, 48);
          const cands = [];
          for (const im of r.images) {
            const s = await loadImage(im.small);
            cands.push({ aspect: s.naturalWidth / s.naturalHeight, sim: C.similarity(aiThumb, grayThumb(s, 48)) });
          }
          const idx = pick == null ? C.pickCandidate(aw / ah, cands).index : pick % r.images.length;
          const full = await send({ type: 'pacs-image', tabId: r.tabId, uid: r.images[idx].uid, kind: 'jpeg' });
          if (full && full.ok) {
            const img = await loadImage(full.dataUrl);
            pacs = { r, idx, cand: cands[idx], aspectOk: Math.abs(cands[idx].aspect - aw / ah) / (aw / ah) <= 0.03, img, dataUrl: full.dataUrl };
          } else why = whyText(full);
        } else why = whyText(r);
      }

      if (pacs) {
        const W = pacs.img.naturalWidth, H = pacs.img.naturalHeight, n = pacs.r.images.length, uid = pacs.r.images[pacs.idx].uid;
        const modelBoxes = aiBoxes.map((b) => C.scaleBox(b, W / aw, H / ah));
        const ext = C.extOf(pacs.dataUrl, 'jpg');
        await E.open({
          image: pacs.img, width: W, height: H, compare: ai,
          boxes: asModel(modelBoxes), resetBoxes: () => asModel(modelBoxes), defaultLabel: modelLabel,
          storeKey: storeKey(page),
          metaLines: metaLines.concat('影像來源：WebPACS 原圖' + (n > 1 ? '（這筆檢查有 ' + n + ' 張，用的是第 ' + (pacs.idx + 1) + ' 張）' : '')),
          intro: '已從 WebPACS 取得原圖。' + boxNote(modelBoxes.length) +
            (pacs.aspectOk ? '' : '⚠ 這張的長寬比和結果頁的影像不同，可能不是同一張，模型的框位置請自行確認。'),
          dicomOption: true,
          extraButtons: n > 1 ? [{ label: '換一張（共 ' + n + ' 張）', onClick: (api) => { if (api.close(false)) start(page, btn, setText, pacs.idx + 1); } }] : [],
          onSaved: (t) => setText(t),
          makeFiles: async (s) => {
            const files = [{ filename: base + '.' + ext, url: pacs.dataUrl }, { filename: base + '_withbox.' + aiExt, url: page.imageSrc }];
            let dicomPath = '';
            if (s.wantDicom) {
              const d = await send({ type: 'pacs-image', tabId: pacs.r.tabId, uid, kind: 'dicom' });
              if (!d || !d.ok) throw new Error('DICOM 下載失敗：' + whyText(d));
              dicomPath = base + '.dcm';
              files.push({ filename: dicomPath, url: d.dataUrl });
            }
            const json = C.buildLabelme({
              imagePath: base + '.' + ext, width: W, height: H, boxes: s.boxes, noFinding: s.noFinding, note: s.note,
              page, modelBoxes, aiImageSize: [aw, ah], savedAt: s.savedAt, toolVersion: VERSION,
              overlay: { removed: false, repaired: 0, withBoxPath: base + '_withbox.' + aiExt },
              pacs: { object_uid: uid, study_date: pacs.r.study.studyDate, body_part: pacs.r.study.bodyPart, images_in_study: n, similarity: pacs.cand.sim, dicomPath },
            });
            files.push({ filename: base + '.json', url: C.jsonDataUrl(json) });
            return files;
          },
        });
      } else {
        // 退回：用結果頁的影像（模型的框抹掉）
        const mainName = hasOverlay ? base + '.png' : base + '.' + aiExt;
        const withBoxName = hasOverlay ? base + '_withbox.' + aiExt : '';
        await E.open({
          image: hasOverlay ? oc : ai, width: aw, height: ah, compare: hasOverlay ? ai : null,
          boxes: asModel(aiBoxes), resetBoxes: () => asModel(aiBoxes), defaultLabel: modelLabel,
          storeKey: storeKey(page),
          metaLines: metaLines.concat('影像來源：AI 平台結果頁' + (hasOverlay ? '（模型的框已抹掉）' : '')),
          intro: boxNote(aiBoxes.length) + '⚠ 這次沒有用到 PACS 原圖：' + why + '。開著已登入的 WebPACS 分頁，關閉這個畫面再按一次「重新標註」，就會改用原圖。',
          onSaved: (t) => setText(t),
          makeFiles: async (s) => {
            const files = [{ filename: mainName, url: hasOverlay ? oc.toDataURL('image/png') : page.imageSrc }];
            if (hasOverlay) files.push({ filename: withBoxName, url: page.imageSrc });
            const json = C.buildLabelme({
              imagePath: mainName, width: aw, height: ah, boxes: s.boxes, noFinding: s.noFinding, note: s.note,
              page, modelBoxes: aiBoxes, aiImageSize: [aw, ah], savedAt: s.savedAt, toolVersion: VERSION,
              overlay: { removed: hasOverlay, repaired: cleaned.repaired, withBoxPath: withBoxName },
            });
            files.push({ filename: base + '.json', url: C.jsonDataUrl(json) });
            return files;
          },
        });
      }
    } catch (e) {
      alert('無法開啟標註畫面：' + String((e && e.message) || e));
    } finally {
      busy = false;
      btn.disabled = false;
      setText();
    }
  }
})();
